import json,math,hashlib
from pathlib import Path
from xml.sax.saxutils import escape
import numpy as np
from PIL import Image,ImageOps
from reportlab.pdfgen import canvas
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib.pagesizes import A4
from reportlab.lib.utils import ImageReader
from reportlab.platypus import Paragraph
from reportlab.lib.styles import ParagraphStyle
from reportlab.graphics import renderPDF
from svglib.svglib import svg2rlg
BASE=Path(__file__).resolve().parents[1]
ART=BASE/'art/mechanical';ELEC=BASE/'art/electronics';OUT=BASE/'rebuilt'
OUT.mkdir(parents=True,exist_ok=True)
PDF=OUT/'A1-Byggjerettleiing-R03.pdf'
W,H=A4
pdfmetrics.registerFont(TTFont('Manual','/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'))
pdfmetrics.registerFont(TTFont('ManualBold','/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'))
C=canvas.Canvas(str(PDF),pagesize=A4,pageCompression=1)
C.setTitle('A1 · Entropi · Byggjerettleiing R03')
C.setAuthor('FormNerd / Iver Finne')
C.setSubject('Illustrert prototypebygging: ESP32-CAM, MB og A1-kamerahus')
PAGES=[];FIGURES=[]
PARTS={'01':'01_outer_shell','02':'02_native_rear_cover','03':'03_esp32_carrier','04':'04_optical_bezel','05':'05_lock_1','06':'06_lock_tool','07':'07_shutter','08':'08_shutter_retainer','09':'09_camera_keeper','T1':'test_lock_socket'}
NAMES={'01':'Ytterskal','02':'Baklokk','03':'Kamerahaldar','04':'Frontring','05':'Lås','06':'Låseverktøy','07':'Utløysar','08':'Brytarkassett','09':'Kameraklemme','T1':'Testhylse'}

def text(s,x,y,size=11,bold=False,align='left'):
    C.setFillGray(0);C.setFont('ManualBold' if bold else 'Manual',size)
    getattr(C,{'left':'drawString','right':'drawRightString','center':'drawCentredString'}[align])(x,y,s)

def paragraph(s,x,top,width,size=10,leading=None,bold=False):
    st=ParagraphStyle('p',fontName='ManualBold' if bold else 'Manual',fontSize=size,leading=leading or size*1.45,textColor='#000000')
    p=Paragraph(s,st);_,h=p.wrap(width,1000);p.drawOn(C,x,top-h);return top-h

def line(a,b,width=.8,dash=None):
    C.setStrokeGray(0);C.setLineWidth(width);C.setLineCap(1);C.setLineJoin(1);C.setDash(dash or [])
    C.line(*a,*b);C.setDash([])

def arrow(a,b,width=1.6,head=8,outline=True):
    a=np.array(a,dtype=float);b=np.array(b,dtype=float);d=b-a;length=np.linalg.norm(d)
    if length<2:return
    u=d/length;n=np.array([-u[1],u[0]]);base=b-u*head
    if outline:
        C.setStrokeGray(1);C.setLineWidth(width+3);C.line(*a,*base)
    line(a,base,width)
    C.setFillGray(0);C.setStrokeGray(0)
    p=C.beginPath();p.moveTo(*b);p.lineTo(*(base+n*head*.4));p.lineTo(*(base-n*head*.4));p.close();C.drawPath(p,fill=1,stroke=0)

def circle_label(s,x,y,r=12,size=11):
    C.setFillGray(1);C.setStrokeGray(0);C.setLineWidth(.8);C.circle(x,y,r,fill=1,stroke=1)
    text(s,x,y-size*.35,size,align='center')

def check(x,y,size=13):
    line((x,y),(x+size*.32,y-size*.32),1.4);line((x+size*.32,y-size*.32),(x+size,y+size*.5),1.4)

def cross(x,y,size=8):
    line((x-size,y-size),(x+size,y+size),1.3);line((x-size,y+size),(x+size,y-size),1.3)

def power(x,y,on=False):
    C.setStrokeGray(0);C.setLineWidth(.8);C.rect(x,y,14,8,stroke=1,fill=0)
    line((x+14,y+4),(x+25,y+4),.8);line((x-5,y+2),(x,y+2),.8);line((x-5,y+6),(x,y+6),.8)
    if not on:line((x-6,y-4),(x+19,y+13),1.4)
    text('USB PÅ' if on else 'USB FRÅ',x+32,y,8)

def header(number,title,parts=(),on=None):
    text(str(number),36,H-73,39,True)
    text(title,112,H-51,12,True)
    if on is not None:power(112,H-76,on)
    if parts:
        x=W-36-70*len(parts)
        for p,q in parts:
            circle_label(p,x+13,H-90,11,10);text('×'+str(q),x+31,H-94,12)
            if p in PARTS:geom('part-'+PARTS[p],(x+2,H-138,60,42),crop=True)
            x+=70
    C.bookmarkPage('p'+str(len(PAGES)+1));C.addOutlineEntry(f'{number} {title}','p'+str(len(PAGES)+1),level=0)

def footer(title):
    n=len(PAGES)+1
    text('A1 · R03',36,26,7.4);text(str(n),W-36,26,8,align='right')
    PAGES.append(title);C.showPage()

def caption(main,sub=''):
    paragraph(main,36,112,W-72,12,17)
    if sub:paragraph(sub,36,77,W-72,8.4,11.8)

def geom(name,box,crop=True,meta=True):
    path=ART/(name+'.png');im=Image.open(path).convert('L');a=np.asarray(im)
    if crop:
        yy,xx=np.where(a<200);margin=28
        cropbox=(max(0,int(xx.min())-margin),max(0,int(yy.min())-margin),min(im.width,int(xx.max())+margin+1),min(im.height,int(yy.max())+margin+1))
    else:cropbox=(0,0,im.width,im.height)
    im=im.crop(cropbox);x,y,w,h=box;sc=min(w/im.width,h/im.height);dw,dh=im.width*sc,im.height*sc;dx=x+(w-dw)/2;dy=y+(h-dh)/2
    C.drawImage(ImageReader(im),dx,dy,width=dw,height=dh,mask='auto')
    FIGURES.append({'page':len(PAGES)+1,'file':path.name,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    if not meta or not (ART/(name+'.json')).exists():return None
    m=json.loads((ART/(name+'.json')).read_text())
    def project(v):
        q=np.array(v)-np.array(m['centre']);factor=m['size'][1]/(2*m['scale']);xx=m['size'][0]/2+q@np.array(m['right'])*factor;yy=m['size'][1]/2-q@np.array(m['up'])*factor
        return np.array([dx+(xx-cropbox[0])*sc,dy+dh-(yy-cropbox[1])*sc])
    return project

def vector(name,box):
    p=ELEC/(name+'.svg');d=svg2rlg(str(p));x,y,w,h=box;scale=min(w/d.width,h/d.height);C.saveState();C.translate(x+(w-d.width*scale)/2,y+(h-d.height*scale)/2);C.scale(scale,scale);renderPDF.draw(d,C,0,0);C.restoreState()
    FIGURES.append({'page':len(PAGES)+1,'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})

def callout(s,target,at):
    a=np.array(at);p=np.array(target);d=p-a;dist=np.linalg.norm(d)
    if dist>14:line(a+d/dist*13,p,.65);C.setFillGray(0);C.circle(*p,1.2,fill=1,stroke=0)
    circle_label(s,*a)

def round_detail(name,cx,cy,r=73):
    C.saveState();p=C.beginPath();p.circle(cx,cy,r);C.clipPath(p,stroke=0,fill=0);C.setFillGray(1);C.circle(cx,cy,r,fill=1,stroke=0)
    mapper=geom(name,(cx-r,cy-r,2*r,2*r),crop=False)
    C.restoreState();C.setStrokeGray(0);C.setLineWidth(.9);C.circle(cx,cy,r,stroke=1,fill=0);return mapper

def turn(cx,cy,r,degrees=90,start=145,label=True):
    a=np.radians(np.linspace(start,start-degrees,40));pts=np.column_stack([cx+r*np.cos(a),cy+r*.54*np.sin(a)])
    C.setStrokeGray(1);C.setLineWidth(4.5);p=C.beginPath();p.moveTo(*pts[0]);[p.lineTo(*q) for q in pts[1:]];C.drawPath(p)
    C.setStrokeGray(0);C.setLineWidth(1.5);p=C.beginPath();p.moveTo(*pts[0]);[p.lineTo(*q) for q in pts[1:]];C.drawPath(p)
    arrow(pts[-4],pts[-1],1.4,6)
    if label:text(str(degrees)+'°',cx+r+5,cy-4,12)

def stage(name,box=(36,286,W-72,410),arrows=True,labels=True):
    proj=geom(name,box)
    rec=json.loads((ART/'stages.json').read_text()).get(name,{})
    if arrows:
        for a,b,_ in rec.get('arrows',[]):arrow(proj(a),proj(b))
    if labels:
        for s,pt,off in rec.get('labels',[]):
            if 'NOM' in s or 'FPC' in s:continue
            s=s.replace(' × 4','').replace(' + 09','')
            p=proj(pt);off=np.array(off)*.30;at=p+np.array([off[0],-off[1]])
            at=np.maximum([49,box[1]+10],np.minimum([W-49,box[1]+box[3]-5],at));callout(s,p,at)
    return proj

def screen(x,y,w=460,h=300):
    C.setStrokeGray(0);C.setLineWidth(1);C.roundRect(x,y,w,h,6,stroke=1,fill=0);line((x,y+h-32),(x+w,y+h-32),.75)
    for i in range(3):C.circle(x+13+i*11,y+h-16,2.2,stroke=1,fill=0)
    return x+20,y+20,w-40,h-60

def small_number(n,x,y):circle_label(str(n),x,y,10,10)

text('A1',36,H-112,78,True);text('ENTROPI',40,H-145,15)
geom('finished',(28,205,W-56,465))
text('Byggjerettleiing',36,130,18)
text('ESP32-CAM + MB',36,104,11)
text('Mekanisk prototype R01 · Rettleiing R03',36,56,8.5)
footer('A1 / Entropi')

text('Delane',36,H-61,25,True);text('11 produktdelar',W-36,H-57,10,align='right')
inv=['01','02','03','04','05','07','08','09']
for i,p in enumerate(inv):
    col=i%2;row=i//2;x=36+col*266;y=H-111-row*166
    circle_label(p,x+12,y,12,11);text('×4' if p=='05' else '×1',x+32,y-4,13)
    geom('part-'+PARTS[p],(x+7,y-126,225,108))
    text(NAMES[p],x+7,y-145,8.5)
    if col==1 and row<3:line((36,y-152),(W-36,y-152),.45)
footer('Deloversikt / produkt')

text('Før du byrjar',36,H-62,25,True)
for i,p in enumerate(['06','T1']):
    x=36+i*266;circle_label(p,x+13,H-111,12,11);text('×1',x+34,H-115,13);geom('part-'+PARTS[p],(x+15,H-253,205,122));text(NAMES[p],x+10,H-278,10)
line((36,H-305),(W-36,H-305),.65)
vector('e01-stack',(36,240,270,290))
paragraph('<b>E1</b> ESP32-CAM ×1<br/><br/><b>E2</b> ESP32-CAM-MB ×1<br/><br/><b>E3</b> Normalt open brytar ×1<br/><br/>USB-datakabel, to isolerte leidningar,<br/>PC, telefon og multimeter.',318,505,240,10,15)
paragraph('Arduino IDE er programmet på PC-en.<br/>Eit separat Arduino-kort trengst ikkje.',36,190,W-72,11,16)
paragraph('Elektronikken er teikna skjematisk. Kontroller kortvariant, mål og pinnemerking på delane dine. Guiden byggjer ein USB-driven prototype.',36,115,W-72,9,13)
footer('Deloversikt / elektronikk og verktøy')

text('Kor delane høyrer til',36,H-62,22,True)
p=geom('overview',(20,122,W-40,620))
for s,pt,offset in [('01',(50,0,-5),(45,15)),('02',(35,-141,0),(-35,30)),('03',(-31.7,-69,0),(-45,40)),('04',(-31.7,66,-8.4),(40,10)),('07',(45,8.4,70),(25,15)),('08',(45,-50,28),(40,15)),('09',(-59.7,-17.9,-78.4),(-30,-25))]:
    pos=p(pt);callout(s,pos,pos+offset)
text('05 ×4',37,91,11);paragraph('Delnummera følgjer dei same filnamna i print/.',36,66,W-72,8.5)
footer('Eksplodert oversikt')

header(1,'Set CAM i MB',on=False)
vector('e01-stack',(36,226,W-72,488))
caption('Match pinnemerkinga. Før begge radene rett ned i soklane.','Alle 16 pinnar skal treffe. Stopp dersom noko bøyer seg eller møter motstand.')
footer('1 / CAM i MB')

header(2,'Kople til PC-en',on=True)
vector('e02-usb',(36,222,W-72,490))
caption('Bruk ein USB-datakabel. Finn serieporten som kjem til.','Porttypen på MB-kortet avgjer kabelen. USB til MB er straum og programmering.')
footer('2 / USB til PC')

header(3,'Installer Arduino IDE')
xx,yy,ww,hh=screen(55,295,485,365)
text('Arduino IDE',xx,yy+hh-5,15,True)
text('Preferences / Settings',xx,yy+hh-40,10)
text('Additional Boards Manager URLs',xx,yy+hh-80,10,True)
C.setLineWidth(.8);C.rect(xx,yy+hh-145,ww,48)
paragraph('https://espressif.github.io/arduino-esp32/<br/>package_esp32_index.json',xx+10,yy+hh-108,ww-20,9,14)
arrow((xx+ww/2,yy+hh-163),(xx+ww/2,yy+hh-192),1.2,7)
text('Boards Manager',xx,yy+70,11,True)
text('esp32 by Espressif Systems',xx,yy+36,13)
C.rect(xx+ww-91,yy+17,90,27);text('Install',xx+ww-46,yy+25,10,align='center')
caption('Installer Arduino IDE, legg inn pakkekjelda og installer esp32.','Hent Arduino IDE frå arduino.cc/en/software. ESP32-pakka inneheld kamerabiblioteka.')
C.linkURL('https://www.arduino.cc/en/software',(36,53,260,88),relative=0)
C.linkURL('https://espressif.github.io/arduino-esp32/package_esp32_index.json',(75,489,518,548),relative=0)
footer('3 / Installering')

header(4,'Opne programmet og vel kort')
xx,yy,ww,hh=screen(55,295,485,365)
text('A1_Bench_Camera.ino',xx,yy+hh-3,14,True)
rows=[('Board','AI Thinker ESP32-CAM'),('Port','Porten frå steg 2'),('PSRAM','Enabled / standardprofil'),('Upload Speed','115200')]
for i,(a,b) in enumerate(rows):
    y=yy+hh-64-i*47;text(a,xx,y,9);text(b,xx+112,y,11,bold=i==0);line((xx,y-14),(xx+ww,y-14),.45)
text('firmware/A1_Bench_Camera/',xx,yy+22,9)
text('A1_Bench_Camera.ino',xx,yy+5,9)
caption('Opne A1-skissa. Vel AI Thinker ESP32-CAM og rett serieport.','MB er USB-adapteren. Mappa og .ino-fila skal ha same namn. Behald AI Thinker-standardane.')
footer('4 / Skisse, kort og port')

header(5,'Kontroller og last opp',on=True)
for x,s,icon in [(146,'Verify','check'),(405,'Upload','arrow')]:
    C.setLineWidth(1);C.circle(x,558,55,stroke=1,fill=0)
    if icon=='check':check(x-17,554,32)
    else:arrow((x-23,558),(x+23,558),2,11)
    text(s,x,474,15,align='center')
arrow((224,558),(326,558),1.4,9)
paragraph('Dersom opplastinga stoppar på Connecting…',65,393,465,11,bold=True)
for i,s in enumerate(['Hald IO0 / BOOT inne.','Trykk og slepp RST.','Slepp IO0 når skrivinga startar.']):
    small_number(i+1,76,342-i*42);text(s,99,338-i*42,10.5)
line((65,218),(529,218),.6)
text('Etter opplasting',65,192,11,True);text('IO0 sleppt → RST → Serial Monitor: 115200 baud',65,167,10)
caption('Verify → Upload → normal oppstart.','Kameraet skal starte utan kamerafeil. BOOT/RST-sekvensen trengst berre om tilkoplinga står fast.')
footer('5 / Last opp')

header(6,'Ta første foto',on=True)
vector('e05-bench',(36,346,W-72,350))
C.setLineWidth(1);C.roundRect(93,184,410,142,11)
text('Wi-Fi   A1-Camera',115,294,13,True);text('Passord   A1camera2026',115,267,11)
text('http://192.168.4.1/',115,233,16)
text('Ta bilete  →  Last ned siste JPEG',115,207,10)
caption('Kople til kameraet sitt Wi-Fi. Opne adressa og ta eit foto.','Bli verande på nettet utan internett. Last ned fotoet: neste foto eller straumbrot slettar det førre.')
footer('6 / Første foto')

header(7,'Finn rett brytarkontakt',on=False)
vector('e04-continuity',(36,235,W-72,445))
caption('Finn paret som er ope utan trykk og har samband ved trykk.','Bruk kontinuitetsmåling. To bein som allereie har samband utan trykk, er feil kontaktpar.')
footer('7 / Mål brytaren')

header(8,'Kople utløysaren',on=False)
vector('e03-wiring',(36,235,W-72,465))
caption('GPIO13 → normalt open brytar → GND.','Følg pinnemerkinga på CAM. Ingen 5 V til GPIO13. Ingen microSD. A1-skissa brukar INPUT_PULLUP.')
footer('8 / Elektrisk utløysar')

header(9,'Prøv knappen før innbygging',on=True)
vector('e03-wiring',(36,350,W-72,330))
for i in range(5):
    x=106+i*93;C.setStrokeGray(0);C.setLineWidth(.9);C.rect(x-17,236,34,25);C.circle(x,248,7,stroke=1,fill=0);text(str(i+1),x,209,11,align='center')
text('5 trykk  =  5 nye foto',W/2,172,15,align='center')
caption('Trykk, slepp og kontroller teljaren. Gjenta fem gonger.','Å halde knappen inne skal ikkje gi ei rekkje foto. Last ned fotoet og kople frå USB før montering.')
footer('9 / Prøv knappen')

header(10,'Prøveprint låsen',parts=[('05',1),('06',1),('T1',1)])
p=stage('m02',(36,358,W-72,330),arrows=True,labels=True)
for i,n in enumerate(['lock-seat','lock-turn','lock-held']):
    x=117+i*180;round_detail(n,x,240,67);small_number(i+1,x-52,301)
    if i<2:arrow((x+73,240),(x+99,240),1.3,6)
    if i==1:turn(x,242,31,90,160)
    if i==2:check(x+29,197,12)
caption('Før øyra inn. Drei 90°. Lås opp og prøv igjen.','Print testhylsa og éin lås med faktisk filament og P1S-profil. Prøva skal gå utan stor kraft eller sprekk.')
footer('10 / Låseprøve')

header(11,'Print og reins resten')
for i,p in enumerate(['01','02','03','04','05','07','08','09']):
    col=i%4;row=i//4;x=38+col*133;y=560-row*170
    geom('part-'+PARTS[p],(x,y,120,118));circle_label(p,x+16,y+140,10,9);text('×4' if p=='05' else '×1',x+33,y+136,10)
line((36,345),(W-36,345),.75)
text('P1S',55,287,17,True);text('PLA',178,287,17);text('0,4 mm',297,287,17);text('0,20 mm',439,287,17)
paragraph('Vel faktisk dyse og filament i Bambu Studio.<br/>Kontroller første lag, støtte og at alle delane har utskriftsbaner.',55,246,490,10.5,15)
caption('Fjern støtte og laus plast. Reins hol, spor og føringar.','Bruk separate printdelar eller printplater. Den samla assembly-visinga skal ikkje printast som eitt objekt.')
footer('11 / Print resten')

header(12,'Prøvepass innmaten',on=False)
vector('e06-flex',(35,425,290,260));geom('part-03_esp32_carrier',(330,425,220,255))
for i,(value,label) in enumerate([('28 × 48 × 22 mm','Nominelt kortrom i 03'),('6 × 6 mm','Nominelt brytarfotavtrykk'),('1,2 mm','Modellert mekanisk knappslag')]):
    y=356-i*59;text(value,50,y,17,True);text(label,293,y+2,9.5)
paragraph('Kort, USB-plugg, kamerafleks og brytar må passe utan tvang.<br/>Stopp og tilpass CAD dersom eit mål eller ei føring avvik.',50,149,490,10.5,15)
caption('Prøv dei faktiske delane før du byggjer vidare.','Kortvariant, flekslengd, brytarhøgd, fasthalding og retur er ikkje fysisk stadfesta.')
footer('12 / Prøvepass')

header(13,'Legg CAM/MB i haldaren',parts=[('03',1)],on=False)
p=stage('m03',(45,249,W-90,450),arrows=False,labels=False)
text('SNITT',43,230,8.5,True)
for label,pt,at in [('E1',(-31.7,-2,10),(W-80,450)),('E2',(-31.7,-20,-14),(W-80,363)),('03',(-43,-9,18),(85,540))]:callout(label,p(pt),at)
caption('Prøvepass CAM/MB i 03. Hald kontaktar og leidningar frie.','Snittet viser nominell plassering. Kortstakken skal sitje utan spenn; plugg og fleks skal ha fri plass.')
footer('13 / Kort i haldar')

header(14,'Kamera og klemme',parts=[('09',1)],on=False)
p=stage('m04',(36,286,W-72,404),arrows=True,labels=True)
for n,pt in [('1',(-31.7,10,-8.4)),('2',(-31.7,-8,-2.2))]:
    pos=p(pt);circle_label(n,*(pos+np.array([-22,25])),r=9,size=9)
vector('e06-flex',(67,145,225,122));paragraph('1  Før modulen fram i setet.<br/><br/>2  Set 09 bak modulen.',325,244,220,10,14)
caption('Legg kamerafleksen i ein mjuk boge. Set på klemma.','Linsa skal vere fri. Ingen strekk, skarp brett eller trykk på sensorhus og flekskontakt. Kameraet er nominelt teikna.')
footer('14 / Kamera og klemme')

header(15,'Før utløysaren ned ovanfrå',parts=[('07',1)],on=False)
p=stage('m05',(36,340,W-72,355))
round_detail('m05-detail',W/2,223,94)
text('1,2 mm',W/2+113,223,11)
caption('Før 07 ned i toppopninga. Prøv at han glir fritt.','Prøv først utan brytar og kassett. 1,2 mm er mekanisk slag, ikkje tillaten overvandring i brytaren.')
footer('15 / Utløysar')

header(16,'Set brytaren i kassetten',parts=[('08',1)],on=False)
p=stage('m06',(36,264,W-72,420),arrows=True,labels=True)
paragraph('Leidningane går bakover.',319,204,222,11)
arrow((293,225),(365,225),1.2,7)
caption('Legg den målte brytaren i 08. Prøv trykkpunkt og full retur.','Brytaren skal sleppe heilt før neste trykk. Tilpass setet dersom brytarhøgda eller returkrafta ikkje passar.')
footer('16 / Brytar i kassett')

header(17,'Skyv kassetten inn bakfrå',parts=[('08',1)],on=False)
p=stage('m07',(36,348,W-72,350))
round_detail('m07-detail',W/2,224,95)
caption('La gaffelen på 08 fange flensen på 07.','Hald utløysaren lett oppe. Leidningane går bakover, unna gaffel og styreflater. Prøv fri retur.')
footer('17 / Kassett inn')

header(18,'Skyv kamerahaldaren inn',parts=[('03',1)],on=False)
p=stage('m08',(36,330,W-72,370))
round_detail('m08-detail',W/2,225,94)
caption('Skyv 03 rett inn bakfrå. Stopp dersom linse eller fleks tek borti.','Hald GPIO13/GND-leidningane unna føringane. Kontroller sentrert linse og fri USB-tilgang.')
footer('18 / Haldar inn')

header(19,'Prøv med huset ope',on=True)
p=geom('open-test',(36,285,W-72,400))
vector('e05-bench',(40,144,260,136))
paragraph('5 foto med 07.<br/>Prøv òg nettlesarknappen.<br/><br/>Kople frå USB etter testen.',327,244,225,10.5,15)
caption('Prøv kamera, utløysar og nedlasting før du lukkar huset.','Sjå etter klemde leidningar og fleks. Innmaten skal sitje stabilt medan huset er ope.')
footer('19 / Open funksjonsprøve')

header(20,'Lås frontringen',parts=[('04',1)],on=False)
p=stage('m09',(36,331,W-72,370),arrows=True,labels=False)
callout('04',p((-31.7,52,-24.4)),(W-82,428))
round_detail('m09-detail',W/2,224,95);turn(W/2,224,56,45,180)
caption('Rett inn øyra. Før 04 heilt inn og drei 45°.','Ringen skal halde aksialt og kunne løysast att. Han skal ikkje presse mot den faktiske kameralinsa.')
footer('20 / Frontring')

header(21,'Legg på baklokket',parts=[('02',1)],on=False)
p=stage('m10',(36,258,W-72,445))
paragraph('Ingen leidning over fugekanten.',50,198,490,11)
caption('Før 02 rett inn bakfrå. Kontroller jamn fuge og fire frie låsehol.','Lokket skal liggje på setet før låsane blir sette inn. Flytt alle leidningar innanfor huset.')
footer('21 / Baklokk')

header(22,'Set inn dei fire låsane',parts=[('05',4),('06',1)],on=False)
p=stage('m11',(36,357,W-72,347),arrows=True,labels=False)
callout('05',p((-31.7,-60,30)),(89,620));callout('06',p((20,-65,27)),(W-73,492))
for i,n in enumerate(['lock-seat','lock-turn','lock-held']):
    x=117+i*180;round_detail(n,x,225,67);small_number(i+1,x-52,285)
    if i<2:arrow((x+73,225),(x+99,225),1.3,6)
    if i==1:turn(x,226,30,90,160)
    if i==2:check(x+28,184,11)
caption('Set inn 05 ×4. Drei kvar lås 90° med verktøy 06.','Rett inn øyra som i låseprøva. Kontroller at lokket held, og prøv opplåsing før du avsluttar.')
footer('22 / Baklåsar')

header(23,'Ta foto med det samla kameraet',on=True)
geom('finished',(36,313,W-72,390))
check(63,236,15);text('10 separate foto',94,234,12)
check(63,197,15);text('Full knappretur og fri biletkant',94,195,12)
check(63,158,15);text('Stabil innmat og fri kabel',94,156,12)
caption('Ta ti foto. Opne huset etter testen og sjå etter klemming.','Kople frå USB før opning. Noter kortmodell, brytarmål, filament og resultat av den fysiske prøva.')
footer('23 / Sluttprøve')

text('Dersom noko stoppar',36,H-63,23,True)
for i,(a,b,c) in enumerate([
('Ingen serieport','Prøv ein kjend USB-datakabel. Kontroller rett port og USB-UART-drivar.','2'),
('Opplasting står fast','Kontroller kortvalet. Bruk IO0/BOOT og RST-sekvensen.','4-5'),
('Ingen kamerabilete','Les Serial Monitor. Kontroller kamera/FPC utan straum.','6'),
('Knappen gir ikkje foto','Kontroller A1-skissa og det målte GPIO13/GND-paret.','7-9'),
('Knappen heng','Prøv 07 åleine, så 08. Kontroller brytarhøgd og retur.','15-17'),
('Delane passar ikkje','Mål avviket og tilpass CAD. Ikkje bruk meir kraft.','10-12')]):
    y=H-139-i*97;circle_label(str(i+1),49,y+4,11,10);text(a,76,y+7,11,True);paragraph(b,76,y-8,415,9.5,14);text('→ '+c,W-37,y+6,9,align='right')
paragraph('Gå tilbake til siste steg som fungerte.<br/>Rett feilen der før du monterer vidare.',36,120,W-72,11,16)
footer('Feilsøking')

text('Grunnlag og status',36,H-63,24,True)
y=H-112
for title,body in [
('Geometri','Mekanikkteikningane er laga frå dei faktiske A1-assembly R01-delane. Synlege konturar og kantar er rendera ortografisk. CAD- og printgeometrien er uendra.'),
('Elektronikk','Elektronikken er skjematisk og nominell. Kortmål, kontaktvolum, fleksføring og brytar er ikkje målte på det eigde settet. Namngjevne terminalar i koplingsteikninga er ikkje eit fysisk pinnekart.'),
('Prototype','Prøveprint og fysisk prøvepass må stadfeste toleransar, fasthalding, kamerafleks, retur, synsfelt og varme. Denne guiden er ikkje ei påstand om utført fysisk montering.'),
('Program','Bruk A1_Bench_Camera frå A1/cad-assembly/firmware/. Skissa er tidlegare kompilert for AI Thinker med Arduino-ESP32 3.3.12. Ho har GPIO13-utløysar og eitt siste JPEG i RAM. Batteri, lading og varig fotolagring er ikkje del av denne byggjeruta.')]:
    text(title,36,y,11,True);y=paragraph(body,36,y-12,W-72,9.3,13.5)-27
sources=[('Arduino IDE','https://www.arduino.cc/en/software'),('ESP32: installasjon','https://docs.espressif.com/projects/arduino-esp32/en/latest/installing.html'),('ESP32: oppstartsmodus','https://docs.espressif.com/projects/esptool/en/latest/esp32/advanced-topics/boot-mode-selection.html'),('GPIO og INPUT_PULLUP','https://docs.espressif.com/projects/arduino-esp32/en/latest/api/gpio.html'),('SD_MMC og GPIO13','https://docs.espressif.com/projects/arduino-esp32/en/latest/api/sdmmc.html'),('ESP32-CAM-MB-skjema','https://www.olimex.com/Products/IoT/ESP32/ESP32-CAM/resources/ESP32-CAM-MB-S001.jpg')]
text('Primærkjelder',36,y+5,11,True);y-=22
for title,url in sources:
    text(title,36,y,9);C.linkURL(url,(36,y-3,560,y+12),relative=0);y-=22
text('FormNerd · A1 · 20.10.2026',36,67,8.5)
footer('Grunnlag og status')
C.save()
(OUT/'guide-r03.json').write_text(json.dumps({'revision':'R03','pages':len(PAGES),'page_titles':PAGES,'illustrations':FIGURES,'cad_geometry_modified':False,'physical_fit_verified':False,'imagegen_used':False,'pdf_sha256':hashlib.sha256(PDF.read_bytes()).hexdigest()},ensure_ascii=False,indent=2))
print(json.dumps({'pdf':str(PDF),'pages':len(PAGES),'bytes':PDF.stat().st_size},ensure_ascii=False))
