import argparse
import json
from pathlib import Path
import struct
import subprocess
import tempfile

import numpy as np
from PIL import Image
import vtk
from vtk.util.numpy_support import vtk_to_numpy


RASTER = r'''
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <limits>
#include <vector>
int main(int argc, char** argv) {
    std::ifstream in(argv[1], std::ios::binary);
    uint32_t w, h, count;
    in.read(reinterpret_cast<char*>(&w), 4);
    in.read(reinterpret_cast<char*>(&h), 4);
    in.read(reinterpret_cast<char*>(&count), 4);
    std::vector<float> depth(size_t(w)*h, std::numeric_limits<float>::infinity());
    std::vector<uint8_t> pixels(size_t(w)*h*3, 255);
    float v[18];
    for (uint32_t t=0; t<count; ++t) {
        in.read(reinterpret_cast<char*>(v), sizeof(v));
        float x0=v[0], y0=v[1], x1=v[6], y1=v[7], x2=v[12], y2=v[13];
        float den=(y1-y2)*(x0-x2)+(x2-x1)*(y0-y2);
        if (std::abs(den)<0.000001f) continue;
        int ax=std::max(0, int(std::floor(std::min({x0,x1,x2}))));
        int bx=std::min(int(w)-1, int(std::ceil(std::max({x0,x1,x2}))));
        int ay=std::max(0, int(std::floor(std::min({y0,y1,y2}))));
        int by=std::min(int(h)-1, int(std::ceil(std::max({y0,y1,y2}))));
        for (int y=ay; y<=by; ++y) {
            for (int x=ax; x<=bx; ++x) {
                float px=x+0.5f, py=y+0.5f;
                float a=((y1-y2)*(px-x2)+(x2-x1)*(py-y2))/den;
                float b=((y2-y0)*(px-x2)+(x0-x2)*(py-y2))/den;
                float c=1.0f-a-b;
                if (a < -0.00001f || b < -0.00001f || c < -0.00001f) continue;
                float z=a*v[2]+b*v[8]+c*v[14];
                size_t i=size_t(y)*w+x;
                if (z>=depth[i]) continue;
                depth[i]=z;
                for (int k=0; k<3; ++k) {
                    float value=a*v[3+k]+b*v[9+k]+c*v[15+k];
                    pixels[i*3+k]=uint8_t(std::clamp(value*255.0f, 0.0f, 255.0f)+0.5f);
                }
            }
        }
    }
    std::ofstream out(argv[2], std::ios::binary);
    out << "P6\n" << w << " " << h << "\n255\n";
    out.write(reinterpret_cast<char*>(pixels.data()), pixels.size());
    return in.good() && out.good() ? 0 : 1;
}
'''


def unit(v):
    v = np.asarray(v, dtype=float)
    return v / np.linalg.norm(v)


def load_part(path):
    reader = vtk.vtkSTLReader()
    reader.SetFileName(str(path))
    reader.MergingOn()
    normals = vtk.vtkPolyDataNormals()
    normals.SetInputConnection(reader.GetOutputPort())
    normals.SetFeatureAngle(48)
    normals.SplittingOn()
    normals.ConsistencyOn()
    normals.AutoOrientNormalsOn()
    normals.ComputePointNormalsOn()
    normals.ComputeCellNormalsOff()
    normals.Update()
    poly = normals.GetOutput()
    if not poly.GetNumberOfPoints():
        raise ValueError(f"Empty mesh: {path}")
    points = vtk_to_numpy(poly.GetPoints().GetData()).astype(float)
    faces = vtk_to_numpy(poly.GetPolys().GetData()).reshape(-1, 4)[:, 1:]
    vectors = vtk_to_numpy(poly.GetPointData().GetNormals()).astype(float)
    return points, faces, vectors


def colors(normals, base, view):
    base = np.asarray(base[:3], dtype=float)
    if np.max(base) > 1:
        base /= 255
    key = unit((-2, -3, 5))
    fill = unit((4, -1, 2))
    rim = unit((2, 3, 4))
    diffuse = 0.43 + 0.47 * np.maximum(normals @ key, 0)
    diffuse += 0.12 * np.maximum(normals @ fill, 0)
    diffuse += 0.09 * np.maximum(normals @ rim, 0)
    half = unit(key + view)
    specular = 0.09 * np.maximum(normals @ half, 0) ** 40
    return np.clip(base[None, :] * diffuse[:, None] + specular[:, None], 0, 1)


def render(parts, eye, target, output, raster, work, width, height, exploded=False, up=(0, 0, 1)):
    forward = unit(np.asarray(target) - np.asarray(eye))
    right = unit(np.cross(forward, up))
    vertical = unit(np.cross(right, forward))
    geometry = []
    all_projected = []
    for part in parts:
        points, faces, normals = part["mesh"]
        offset = np.asarray(part.get("explode", [0, 0, 0]), dtype=float) if exploded else np.zeros(3)
        points = points + offset
        projected = np.column_stack((points @ right, points @ vertical, points @ forward))
        geometry.append((projected, faces, colors(normals, part["color"], -forward)))
        all_projected.append(projected)
    bounds = np.concatenate(all_projected)
    low = bounds[:, :2].min(axis=0)
    high = bounds[:, :2].max(axis=0)
    center = (low + high) / 2
    scale = min(width * 0.85 / (high[0] - low[0]), height * 0.85 / (high[1] - low[1]))
    count = sum(len(faces) for _, faces, _ in geometry)
    binary = work / "triangles.bin"
    ppm = work / "render.ppm"
    with binary.open("wb") as handle:
        handle.write(struct.pack("<III", width, height, count))
        for projected, faces, rgb in geometry:
            projected[:, 0] = (projected[:, 0] - center[0]) * scale + width / 2
            projected[:, 1] = height / 2 - (projected[:, 1] - center[1]) * scale
            vertices = np.concatenate((projected, rgb), axis=1)
            handle.write(vertices[faces].astype("<f4").tobytes())
    subprocess.run([str(raster), str(binary), str(ppm)], check=True)
    with Image.open(ppm) as image:
        image.resize((width // 2, height // 2), Image.Resampling.LANCZOS).save(output)
    print(output, flush=True)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--width", type=int, default=1600)
    parser.add_argument("--height", type=int, default=1200)
    parser.add_argument("--only", choices=("hero", "front", "back", "left", "right", "top", "exploded"))
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = json.loads((root / "cad" / "assembly_manifest.json").read_text())
    parts = manifest["parts"] if isinstance(manifest, dict) else manifest
    parts = [dict(p) for p in parts if p.get("preview", True)]
    for part in parts:
        part["color"] = part.get("color", part.get("colorRGB", [0.68, 0.69, 0.69]))
        part["mesh"] = load_part(root / part["file"])
    output = root / "preview"
    output.mkdir(exist_ok=True)
    views = {
        "hero": ((-210, -340, 210), (0, -5, 52), (0, 0, 1), False),
        "front": ((0, -450, 52), (0, -5, 52), (0, 0, 1), False),
        "back": ((0, 450, 52), (0, -5, 52), (0, 0, 1), False),
        "left": ((-450, -5, 52), (0, -5, 52), (0, 0, 1), False),
        "right": ((450, -5, 52), (0, -5, 52), (0, 0, 1), False),
        "top": ((0, -5, 450), (0, -5, 52), (0, 1, 0), False),
        "exploded": ((-210, -340, 210), (0, -5, 52), (0, 0, 1), True),
    }
    with tempfile.TemporaryDirectory(prefix="entropi-render-") as temp:
        work = Path(temp)
        source = work / "raster.cpp"
        raster = work / "raster"
        source.write_text(RASTER)
        subprocess.run(["g++", "-O3", "-std=c++17", str(source), "-o", str(raster)], check=True)
        for name, (eye, target, up, exploded) in views.items():
            if args.only and args.only != name:
                continue
            render(parts, eye, target, output / f"{name}.png", raster, work, args.width * 2, args.height * 2, exploded, up)


if __name__ == "__main__":
    main()
