# ENTROPI · CAD v02

Demonterbar mekanisk prototype, bygd direkte etter den valde referansen: fem ribber i lys grått, open toppboge, mørk innvendig kropp og éi sirkulær frontopning. Alle mål er i millimeter.

## Filer

- `Entropi-assembly-v02.step`: samanstilling med namngjevne, separate CAD-delar.
- `Entropi-assembly-v02.glb`: farga visningsmodell.
- `parts/`: STEP og STL av kvar prentbar del, pluss passingsprøve.
- `cad/build_assembly.py` og `cad/parameters.json`: redigerbar CadQuery-kjelde.
- `cad/verification_report.json`: faktisk geometrikontroll, kollisjonar og demonteringsprøver.
- `preview/`: separate visningar av den faktiske CAD-geometrien.
- `reference_hardware/`: nominelt PCB og førebels MB-volum, berre som referanse.

## Status

Dette er ei digital mekanisk prototype. Kortvarianten, kameraets flekskabel, kontaktmål, brytar og batteri er ikkje målte. Elektronisk funksjon, optisk yting, handkomfort og fysisk passing er ikkje frigjevne for produksjon. Sjå den genererte kontrollrapporten for resultatet av dei digitale kontrollane; eit digitalt geometripass er ikkje ein fysisk passingsprøve.

ESP32-CAM-kortet bruker nominelt 27 × 40,5 mm som utgangspunkt. PCB-tjukkleik og ESP32-CAM-MB-volum er førebelse konstruksjonsverdiar. Juster kortmål og klaringar etter det faktiske settet. Den fremre ringen er eit eige form- og monteringsgrensesnitt, ikkje ei sertifisert Canon-fatning.

Oppgåva krev ei linse på minst 30 mm. Ei frontopning eller ein pyntering på 50 mm dokumenterer ikkje at ei lita ESP32-linse oppfyller dette. Val av reell optikk står ope.

USB-C-opninga er eit mekanisk grensesnitt for ei separat kontaktløysing. ESP32-CAM-MB er eit programmeringskort; batterilading og biletoverføring via USB-C er ikkje automatisk løyste av denne samanstillinga.

## Prenting på P1S

Prent `11_fit_coupon.stl` først i det materialet og med dei innstillingane du skal bruke vidare. Prøv PCB-spora og skruehola før du prentar hovuddelane. Føreslått startpunkt: 0,4 mm dyse, 0,16 mm lag, fire veggar, fem topp- og botnlag, 15 % gyroid.

STL-filene har samanstillingskoordinatar. Bruk automatisk plassering på byggeplata i Bambu Studio; ikkje bruk dei lagra Z-koordinatane som prentposisjon. Delane må orienterast kvar for seg.

- Ribbeburet: legg den flate framringen mot byggeplata. Bruk støtte frå byggeplata under bogane. Ver varsam med synlege ribbeflater ved støttefjerning.
- Chassis: bakopning opp, front mot byggeplata. Kontroller støtte under skruebruer og innvendige utstikk.
- Baklokk: utsida ned, lokaliseringskanten opp.
- Korthaldar og klemme: største flate ned.
- Frontblende: frontskiva ned, stolpane opp.
- Knapp, pinne og hjul: vurder ei lita brim; pinnen kan krevje redusert fart.

Ingen G-kode er inkludert. Inspiser den oppskorne modellen for støtte, første lag og tynne område før prenting.

## Montering

1. Avgrad kontaktflater og prøv skruar i passingsprøva. Ikkje lim samanstillinga.
2. Monter utløysarknappen og sikringspinnen i ribbeburet. Kontroller fri rørsle. Brytar og returfjær må tilpassast den faktiske komponenten.
3. Skru ribbeburet mot chassis frå innsida med fire M2-skruar. Hald den opne toppbogen fri.
4. Før frontblenda inn gjennom frontopninga. Skru henne fast bakfrå i dei to festeøyra i den fremre kragen.
   For formmodellen: før senterpluggen gjennom blenda frå framsida, legg låseskiva på baksida og fest med M2 × 4. Desse to delane er valfrie. Fjern begge når det faktiske kameraet skal monterast; pluggen er ikkje ei linse.
5. Før det øvre hjulet ned frå utsida og fest låseskiva på akslingen med ein M2-skrue frå innsida. Hjulet er ein mekanisk formdetalj; ingen elektronisk enkodar er spesifisert.
6. Monter I/O-plata. Kontakt og kabel må prøvast fysisk, med plass til støyp og kabelbøy.
7. Før ESP32-kortet inn i spora i haldaren og skru på toppklemma. Kople kamera og flekskabel frå før innføring dersom dei er i vegen. Kople dei til att og prøv ei eiga, tilpassa kamerafesting med linsa sentrert i frontopninga. Kontroller fokus, fri sikt og slakk i kabelen. Ingen komponent skal liggje i klem.
8. Fest haldaren til dei fire innvendige skruestolpane. MB-kortet skal kunne koplast frå og fjernast gjennom bakopninga.
9. Før leidningar utanfor skruebanene og monter baklokket med fire skruar. Opne lokket igjen etter første funksjonsprøve og sjekk at ingenting er klemt.

## Skruar som må prøvast

| Grensesnitt | Tal | Førebels skrue |
|---|---:|---|
| Ribbebur til chassis | 4 | M2 × 10 |
| Baklokk | 4 | M2 × 8 |
| Korthaldar til chassis | 4 | M2 × 10 |
| Kortklemme | 2 | M2 × 6 |
| Frontblende | 2 | M2 × 8 |
| I/O-plate | 2 | M2 × 6 |
| Øvre hjul | 1 | M2 × 6 |
| Valfri senterplugg | 1 | M2 × 4 |

Pilothola er laga for utprøving av M2-skruar direkte i plast. Det er ikkje modellert gjengeinnsatsar eller metriske innvendige gjenger. Prøv diameter og inngrep i kupongen og tilpass etter skruetype og materiale. Kontroller at skruetuppane ikkje når elektronikk eller utside.

## Endring og regenerering

Krev Python, CadQuery 2.7.0, NumPy, Pillow og VTK. Visningsskriptet krev òg ein C++-kompilator. Køyr `python cad/build_assembly.py`, deretter `python cad/verify_assembly.py` og `python cad/render_preview.py`. Formkurvene ligg i kjeldefila. Referanseforma er låst for denne versjonen; endra mål krev ny geometrikontroll og fysisk passingsprøve.

Den nominelle hardwaregeometrien er eit målegrunnlag, ikkje målt maskinvare. Straumforsyning, batterifeste, lading, brytarkopling, firmware og faktisk optikk står att før kameraet kan kallast funksjonsklart.
