import json
from pathlib import Path
import struct
import sys

def normalize_glb(path):
    path = Path(path)
    data = path.read_bytes()
    size, kind = struct.unpack_from("<II",data,12)
    document = json.loads(data[20:20+size])
    for scene in document["scenes"]:
        for node in scene["nodes"]:
            document["nodes"][node]["scale"] = [0.001,0.001,0.001]
    payload = json.dumps(document,separators=(",",":")).encode()
    payload += b" "*((-len(payload))%4)
    remainder = data[20+size:]
    path.write_bytes(struct.pack("<4sII",b"glTF",2,20+len(payload)+len(remainder))+struct.pack("<II",len(payload),kind)+payload+remainder)

if __name__ == "__main__":
    normalize_glb(sys.argv[1])
