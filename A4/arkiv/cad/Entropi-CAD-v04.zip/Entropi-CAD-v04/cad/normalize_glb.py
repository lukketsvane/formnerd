import copy
import json
from pathlib import Path
import struct
import sys

def normalize_glb(path):
    path = Path(path)
    data = path.read_bytes()
    size, kind = struct.unpack_from("<II",data,12)
    document = json.loads(data[20:20+size])
    for scene in document["scenes"]:
        for node in scene["nodes"]:
            document["nodes"][node]["scale"] = [0.001,0.001,0.001]
    cmf_path = path.parent / "cad/cmf_materials.json"
    if cmf_path.exists():
        cmf = json.loads(cmf_path.read_text())
        for material in document.get("materials",[]):
            material.setdefault("pbrMetallicRoughness",{}).update(cmf["default"])
        for node in document.get("nodes",[]):
            name = node.get("name")
            if name in cmf["parts"] and "mesh" in node:
                for primitive in document["meshes"][node["mesh"]]["primitives"]:
                    material = copy.deepcopy(document["materials"][primitive["material"]])
                    material["name"] = name + "_CMF"
                    material["pbrMetallicRoughness"].update(cmf["parts"][name])
                    primitive["material"] = len(document["materials"])
                    document["materials"].append(material)
    payload = json.dumps(document,separators=(",",":")).encode()
    payload += b" "*((-len(payload))%4)
    remainder = data[20+size:]
    path.write_bytes(struct.pack("<4sII",b"glTF",2,20+len(payload)+len(remainder))+struct.pack("<II",len(payload),kind)+payload+remainder)

if __name__ == "__main__":
    normalize_glb(sys.argv[1])
