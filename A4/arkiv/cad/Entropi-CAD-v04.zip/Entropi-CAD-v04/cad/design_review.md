# Formvurdering · v04

Entropi blir i dette prosjektet tolka som avstanden mellom det utsida viser og det som finst inni. Ribbene gir avgrensa innsyn i ein mørk kropp. Dei fem ribbene, den opne ytterbogen og den eine sirkulære fronten blir førte vidare frå den valde referansen.

## Grunnlag i oppgåva

- **FormNerd - Prosjektoversikt:** Konseptordet skal vere lesbart i forma, og sluttmodellen skal ha jamn finish. Krava til linse, utløysar og USB-C må vurderast kvar for seg; ei overtydande utside dokumenterer ikkje teknisk funksjon.
- **01_FormNerd Intro:** Utviklinga går frå proporsjonar til overgangar, samanføyingar og detaljar. v04 held hovudforma fast og konsentrerer endringane om synlege feste, kameravinkel og materialuttrykk.
- **02_Semiotikk:** Forma skal både uttrykkje konseptet og gjere bruk forståeleg. Rytmen og tildekkjinga ber konseptet, medan den avgrensa kontrasten i knapp og kontaktområde markerer beteninga.
- **03_Formanalyse Rammeverk:** Negativt rom, overflatekontinuitet, samanføyingar og CMF er sentrale vurderingspunkt. Difor må bogeopninga, ribbeovergangane og møtet mellom lys ramme og mørk kropp kunne lesast utan pynt eller grov tekstur.

## Retning for v04

Ribbesnitta og den mjuke, variable avsmalninga frå v03 blir førte vidare. Materiallys og mjuke refleksjonar skal gjere dei eksisterande flatene tydelegare, utan å late som geometrien er flatare. Støttevolumet på venstre side får smalare overgangar bak ribbene, slik at festeflatene ikkje konkurrerer med ribberytmen.

Hovudkameraet blir senka for å vise meir av opninga under ytterbogen. Dette er ei endring av presentasjonsvinkel, ikkje ei ny opning i geometrien. CMF-retninga er ikkje-metallisk satin grå ramme, matt koksgrå kropp og ein jamn mørk formplugg i fronten. Grovt korn, appelsinhud og metallglans skal ikkje brukast til å skjule overgangar. CMF-bileta skal bevare den aktuelle CAD-geometrien; berre hovudvinkelen blir senka, medan dei andre rissa held kameravinklane sine.

## Attståande vurderingar

Ribbene har framleis eit røyraktig preg, og fem gjentekne bogar kan gi ei dekorativ lesing. Ei framtidig utflating av snitta krev ny validering av CAD-solid, samanføyingar og prentfiler. Overgangane ved ribbeføter og frontring må vurderast i fleire riss og med samanhengande refleksjonsband. G2-kontinuitet er ikkje dokumentert. Den mørke kroppen kan framleis fylle bogeopninga frå høge vinklar; eit godt hovudbilete løyser ikkje dette frå alle synsvinklar.

Topprisset viser framleis tre flate, lyse endeflater av dei samanhengande ribbeføtene i opninga bak ytterbogen.

CMF-rendringane viser tilsikta form- og materialuttrykk. Dei dokumenterer ikkje fysisk maskinvarepassing, optisk yting, knappkraft, fjørlevetid, lading eller biletoverføring. Frontpluggen er ein formdel og ikkje ei linse. Status for geometri og utskrift skal hentast frå dei faktiske kontrollrapportane, og fysisk funksjon må prøvast i prototypen.
