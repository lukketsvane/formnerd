KAMERA MED BOGE - DOKUMENT M03 / CAD R01

Denne kjeldepakken gjenbyggjer den femten siders PDF-layouten frå dei vedlagde ekte vektorfigurane. R01-CAD er uendra. Den fulle R01-CAD-pakken er ei eiga leveranse.

Installer source/requirements.txt i Python-miljøet, og køyr frå camera-boge:
python source/manual_v3.py --layout-only

Resultat: review/manual-v3/Kamera-boge-M03.pdf

For berre den lesne prøvesida:
python source/manual_v3.py

Alle PDF-figurar blir sette som vektor. PNG-ane er førehandsvisingar og trengst ikkje for layoutbygginga. Dei store figur-PNG-ane er utelatne frå denne pakken for å halde han under 10 MiB; SVG og kameradata er komplette. Fontefilene og lisensen ligg i source/assets/fonts. Bygginga med --layout-only importerer ikkje CAD- eller renderbiblioteka.

For ny figurbygging må den opphavlege R01-pakken leggast ved same mappe. Køyr deretter:
python source/manual_v3_scenes.py
python source/manual_v3_details.py
python source/manual_v3.py --build-assets --assets-only
python source/manual_v3.py --booklet

Køyr tunge P01/P02-renderar sekvensielt. Kjelda bruker den vedlagde m03-contour-policy.json for viewspesifikt linjeutval. Figurane er avleidde frå faktisk R01-CAD, med synlege konturar og skarpe kantar. Organiske normalryggar og uvedkomande detaljlinjer er utelatne. Dette endrar ikkje produksjonsgeometrien.

Dei tekniske knapp- og pinnesnitta er merkte illustrasjonsutskjeringar. Klekk er avleidd frå dei faktiske plana. original-CAD blir ikkje erstatta av desse utsnitta. Den illustrerte nøkkelen er nominell og avleidd frå modellens AF2,5-socket; fysisk verktøytilpassing er ikkje stadfesta. Knapp og fjør er viste utan deformasjonssimulering. Trykk- og returpilene viser handlinga som skal prøvast fysisk.

style-drafts/ er biletkreerte layoutreferansar, ikkje geometrifasit. Dei tidlegare stilutkasta er bevarte i den separate M02-kjeldepakken. Berre faktiske CAD-figurar inngår i slutt-PDF-en.

CAD, maskinvare og utskrift er framleis eit digitalt mekanisk prøvebygg. T01, slicing, fysisk passform og fjørretur må prøvast før produksjon. M02 er eit eldre arbeidsutkast som vart erstatta etter gjennomgang av forståing og strek.
