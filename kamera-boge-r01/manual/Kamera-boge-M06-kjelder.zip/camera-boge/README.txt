KAMERA MED BOGE R01

Digital mekanisk prototype, førebels breidd 145 mm. Faktisk maskinvare er ikkje målt.

print/: individuelle STL-filer i mm og tre føreslåtte 3MF-plater.
cad/: monterte meshfiler; STEP dekkjer berre P03, P04 og P05.
review/manual-v3/Kamera-boge-M03.pdf: siste monteringsrettleiing med femten sider.
review/manual-v3/: ekte vektorfigurar, tekniske utsnitt og separate sidebilete.
review/manual-v2/Kamera-boge-M02.pdf: eldre arbeidsutkast med elleve sider.
review/manual-v2/: separate sidebilete, CAD-rendringar og merkte stilutkast.
review/Kamera-boge-R01.pdf: den tidlegare monteringsmanualen.
verification/: Tripo-kvittering, skala, topologi, kollisjonar og prøvde rørsler.
reference/: urørt skisse og rå Tripo-resultat.

Bygg frå denne mappa med Python og source/requirements.txt:
python source/prepare.py
python source/inspect_segmentation.py
python source/build.py
python source/hardware.py
python source/finalize_exports.py
python source/verify.py
python source/plates.py
python source/manual_v3_scenes.py
python source/manual_v3_details.py
python source/manual_v3.py --build-assets --assets-only
python source/manual_v3.py --booklet

Bygg siste PDF-layout frå dei vedlagde figurane: python source/manual_v3.py --layout-only
M03 er dokumentrevisjonen. CAD-geometrien er framleis R01.

Masteren blir berre omorientert og skalert globalt. working-mm er ei lett visingsavleiing med topologiavvik; han blir ikkje brukt til printfiler. Framhus og bakdeksel blir bygde frå den fulle masteren.

Ingen ny Tripo-jobb trengst for å byggje denne pakken på nytt. Opphavlege jobbar: 40 + 40 = 80 kredittar.
