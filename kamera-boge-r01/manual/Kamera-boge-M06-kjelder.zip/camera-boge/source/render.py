import argparse
import json
from pathlib import Path

import numpy as np
import vtk
from PIL import Image
from vtk.util.numpy_support import numpy_to_vtk, numpy_to_vtkIdTypeArray, vtk_to_numpy


def read_mesh(path):
    path = Path(path)
    readers = {'.stl': vtk.vtkSTLReader, '.obj': vtk.vtkOBJReader, '.ply': vtk.vtkPLYReader, '.vtp': vtk.vtkXMLPolyDataReader}
    if path.suffix.lower() in readers:
        reader = readers[path.suffix.lower()]()
        reader.SetFileName(str(path))
        reader.Update()
        mesh = reader.GetOutput()
    else:
        import trimesh
        source = trimesh.load(path, force='mesh', process=False)
        mesh = vtk.vtkPolyData()
        points = vtk.vtkPoints()
        points.SetData(numpy_to_vtk(np.asarray(source.vertices, np.float64), deep=True))
        mesh.SetPoints(points)
        cells = vtk.vtkCellArray()
        indices = np.column_stack((np.full(len(source.faces), 3), source.faces)).astype(np.int64)
        cells.SetCells(len(source.faces), numpy_to_vtkIdTypeArray(indices.ravel(), deep=True))
        mesh.SetPolys(cells)
    clean = vtk.vtkCleanPolyData()
    clean.SetInputData(mesh)
    clean.SetTolerance(1e-9)
    triangles = vtk.vtkTriangleFilter()
    triangles.SetInputConnection(clean.GetOutputPort())
    normals = vtk.vtkPolyDataNormals()
    normals.SetInputConnection(triangles.GetOutputPort())
    normals.SetFeatureAngle(45)
    normals.ConsistencyOn()
    normals.SplittingOn()
    normals.ComputePointNormalsOn()
    normals.ComputeCellNormalsOff()
    normals.Update()
    poly = normals.GetOutput()
    if not poly.GetNumberOfPoints():
        raise ValueError(f'Empty mesh: {path}')
    return vtk_to_numpy(poly.GetPoints().GetData()).copy(), vtk_to_numpy(poly.GetPolys().GetData()).reshape(-1, 4)[:, 1:].copy(), vtk_to_numpy(poly.GetPointData().GetNormals()).copy()


def color_rgb(value):
    if isinstance(value, str):
        return np.array([int(value.lstrip('#')[i:i + 2], 16) for i in (0, 2, 4)], float) / 255
    value = np.array(value, float)
    return value / 255 if value.max() > 1 else value


def rasterize(vertices, faces, normals, part_id, depth, normal_buffer, ids, cull=True):
    height, width = depth.shape
    t = vertices[faces]
    ns = normals[faces]
    denominator = (t[:, 1, 1] - t[:, 2, 1]) * (t[:, 0, 0] - t[:, 2, 0]) + (t[:, 2, 0] - t[:, 1, 0]) * (t[:, 0, 1] - t[:, 2, 1])
    keep = np.abs(denominator) > 1e-10
    if cull:
        keep &= denominator < 0
    t, ns, denominator = t[keep], ns[keep], denominator[keep]
    low = np.maximum(np.ceil(t[:, :, :2].min(1)).astype(np.int32), 0)
    high = np.minimum(np.floor(t[:, :, :2].max(1)).astype(np.int32), [width - 1, height - 1])
    spans = np.maximum(high - low + 1, 0)
    counts = spans[:, 0].astype(np.int64) * spans[:, 1]
    cumulative = np.cumsum(counts)
    first = 0
    depth_flat, ids_flat = depth.ravel(), ids.ravel()
    normal_flat = normal_buffer.reshape(-1, 3)
    while first < len(t):
        base = cumulative[first - 1] if first else 0
        last = min(len(t), max(first + 1, np.searchsorted(cumulative, base + 600000, side='right')))
        n = counts[first:last]
        k = np.repeat(np.arange(first, last), n)
        local = np.arange(n.sum()) - np.repeat(np.cumsum(n) - n, n)
        x = low[k, 0] + local % np.maximum(spans[k, 0], 1)
        y = low[k, 1] + local // np.maximum(spans[k, 0], 1)
        a, b, c = t[k, 0], t[k, 1], t[k, 2]
        w0 = ((b[:, 1] - c[:, 1]) * (x - c[:, 0]) + (c[:, 0] - b[:, 0]) * (y - c[:, 1])) / denominator[k]
        w1 = ((c[:, 1] - a[:, 1]) * (x - c[:, 0]) + (a[:, 0] - c[:, 0]) * (y - c[:, 1])) / denominator[k]
        w2 = 1 - w0 - w1
        inside = (w0 >= -1e-7) & (w1 >= -1e-7) & (w2 >= -1e-7)
        k, x, y, w0, w1, w2 = (v[inside] for v in (k, x, y, w0, w1, w2))
        z = (t[k, 0, 2] * w0 + t[k, 1, 2] * w1 + t[k, 2, 2] * w2).astype(depth.dtype)
        pixel = y * width + x
        np.maximum.at(depth_flat, pixel, z)
        wins = z >= depth_flat[pixel]
        k, pixel, w0, w1, w2 = (v[wins] for v in (k, pixel, w0, w1, w2))
        normal_flat[pixel] = ns[k, 0] * w0[:, None] + ns[k, 1] * w1[:, None] + ns[k, 2] * w2[:, None]
        ids_flat[pixel] = part_id
        first = last


def render(scene, output):
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    size = scene.get('size', [1600, 1200])
    if isinstance(size, int):
        size = [size, size]
    sampling = int(scene.get('supersample', 2))
    width, height = int(size[0]) * sampling, int(size[1]) * sampling
    parts = scene.get('parts', scene.get('objects', []))
    loaded = []
    for part in parts:
        vertices, faces, normals = read_mesh(part['file'])
        matrix = np.asarray(part.get('matrix', np.eye(4)), float).reshape(4, 4)
        vertices = vertices @ matrix[:3, :3].T + matrix[:3, 3] + np.asarray(part.get('translate', [0, 0, 0]))
        normals = normals @ np.linalg.inv(matrix[:3, :3])
        loaded.append((vertices, faces, normals))
    low = np.min([v.min(0) for v, _, _ in loaded], axis=0)
    high = np.max([v.max(0) for v, _, _ in loaded], axis=0)
    camera = scene.get('camera', {})
    target = np.array(camera.get('target', (low + high) / 2), float)
    forward = np.array(camera.get('direction', [1, -1, 0.7]), float)
    forward /= np.linalg.norm(forward)
    up = np.array(camera.get('up', [0, 0, 1]), float)
    right = np.cross(up, forward)
    right /= np.linalg.norm(right)
    up = np.cross(forward, right)
    basis = np.stack((right, up, forward))
    projected = [(v - target) @ basis.T for v, _, _ in loaded]
    if 'scale' in camera:
        scale = float(camera['scale'])
    else:
        xy = np.concatenate([v[:, :2] for v in projected])
        scale = max(np.max(np.abs(xy[:, 1])) * 2, np.max(np.abs(xy[:, 0])) * 2 * height / width) * float(camera.get('padding', 1.12))
    pixels_per_unit = height / scale
    def project(points):
        p = (np.asarray(points, float) - target) @ basis.T
        return np.column_stack((width / 2 + p[:, 0] * pixels_per_unit, height / 2 - p[:, 1] * pixels_per_unit, p[:, 2]))
    depth = np.full((height, width), -np.inf, np.float32)
    normals = np.zeros((height, width, 3), np.float32)
    ids = np.zeros((height, width), np.uint16)
    for i, ((vertices, faces, ns), p) in enumerate(zip(loaded, projected), 1):
        screen = np.column_stack((width / 2 + p[:, 0] * pixels_per_unit, height / 2 - p[:, 1] * pixels_per_unit, p[:, 2]))
        rasterize(screen, faces, ns @ basis.T, i, depth, normals, ids, scene.get('cull_backfaces', True))
    normals /= np.maximum(np.linalg.norm(normals, axis=2, keepdims=True), 1e-9)
    foreground = ids > 0
    mode = scene.get('mode', 'shaded')
    canvas = np.ones((height, width, 3), np.float32)
    if mode == 'line-v2':
        from line_art import feature_lines, lines
        features = feature_lines(loaded, project, depth, sampling, pixels_per_unit, float(scene.get('feature_angle', 35)), parts)
        if scene.get('save_buffers'):
            np.savez_compressed(scene['save_buffers'], ids=ids, depth=depth, normals=normals, sampling=sampling, pixels_per_unit=pixels_per_unit, features=features)
        image, line_report = lines(ids, depth, normals, sampling, scene, pixels_per_unit, features)
        canvas = np.asarray(image, np.float32) / 255
    elif mode == 'line':
        edges = np.zeros((height, width), bool)
        normal_limit = np.cos(np.radians(float(scene.get('edge_angle', 35))))
        for axis in (0, 1):
            for shift in (-1, 1):
                other_ids = np.roll(ids, shift, axis)
                both = foreground & (other_ids > 0)
                normal_dot = np.einsum('ijk,ijk->ij', normals, np.roll(normals, shift, axis))
                other_depth = np.roll(depth, shift, axis)
                depth_delta = np.zeros_like(depth)
                np.subtract(depth, other_depth, out=depth_delta, where=both)
                facing = (np.abs(normals[:, :, 2]) > 0.4) & (np.abs(np.roll(normals[:, :, 2], shift, axis)) > 0.4)
                edges |= (ids != other_ids) | (both & ((normal_dot < normal_limit) | (facing & (np.abs(depth_delta) > float(scene.get('depth_edge', 2.5)) / pixels_per_unit))))
        canvas[edges] = 0.06
    else:
        light = np.array([-0.35, 0.55, 0.76])
        light /= np.linalg.norm(light)
        intensity = 0.55 + 0.4 * np.maximum(normals @ light, 0) + 0.05 * np.maximum(normals[:, :, 2], 0)
        for i, part in enumerate(parts, 1):
            mask = ids == i
            canvas[mask] = color_rgb(part.get('color', '#b7b9b8')) * intensity[mask, None]
    image = Image.fromarray(np.uint8(np.clip(canvas, 0, 1) * 255))
    image.resize(tuple(map(int, size)), Image.Resampling.LANCZOS).save(output)
    anchors = scene.get('anchors', {})
    if isinstance(anchors, list):
        anchors = {str(i): value for i, value in enumerate(anchors)}
    points = {name: (project([point])[0, :2] / sampling).round(3).tolist() for name, point in anchors.items()}
    result = {'image': str(output), 'size': size, 'camera': {'target': target.tolist(), 'direction': forward.tolist(), 'up': up.tolist(), 'scale': scale}, 'anchors': points, 'visible_pixels': int(foreground.sum()), 'triangles': sum(len(f) for _, f, _ in loaded)}
    output.with_suffix('.render.json').write_text(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('scene')
    parser.add_argument('output')
    args = parser.parse_args()
    print(json.dumps(render(json.loads(Path(args.scene).read_text()), args.output)))
