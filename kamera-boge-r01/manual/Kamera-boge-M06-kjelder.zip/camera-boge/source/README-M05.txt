KAMERA MED BOGE - DOKUMENT M05 / CAD R01

M05 = M04 med formlinjer på dei organiske delane (P01 framhus, P02 bakdeksel) i alle figurar.
R01-geometrien er uendra. Sidetalet er 16.

Formlinjene blir målte i biletrommet, ikkje teikna for hand:
  python source/organic_figure.py source/scenes-v3/<scene>.json review/manual-v3/figures/<scene>
Skriptet renderer dei same delane med three.js (source/strek_chrome.mjs, Chrome/Playwright) i same ortografiske
kamera som vektorfiguren, og hentar frå id-, djupne- og normalbuffera:
  - okkluderande konturar: djupnesprang inne i ein del som ikkje kan forklarast av flatehellinga
  - dalar: Hessian-ryggar i det glatta djupnefeltet (dalane mellom røyra)
Linjene blir skeletonisert, glatta, forenkla og lagde til SVG-en som tynne detaljstrøk (data-part="organic").
Parametrane står i organic_figure.py (DEFAULT) og i render.json for kvar figur. Køyringa er idempotent.
Rekkjefølgje for full gjenbygging: vector_illustration.py (eksakte kantar og silhuettar) -> organic_figure.py -> manual_v5.py --layout-only

Platefigurane og side 3 er som i M04 (sjå README-M04.txt). P01 blir teikna frå cad/P01-display.stl (400 000 trekantar, maks avvik 0,04 mm).
