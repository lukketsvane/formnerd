import argparse
import copy
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter, ImageOps
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

import manual as original


ROOT = Path(__file__).resolve().parents[1]
REVIEW = ROOT / 'review' / 'manual-v2'
FIGURES = REVIEW / 'figures'
SCENES = ROOT / 'source' / 'scenes-v2'
PAGE = (595.276, 841.89)
COUNT = 11
FONT = ROOT / 'source' / 'assets' / 'fonts'
NAMES = original.NAMES
FRONT = original.FRONT
REAR = original.REAR
part = original.part
hardware = original.hardware
scene = original.scene


def scenes():
    out = original.scenes()
    out['exploded']['anchors']['P03'] = [-38, 67.5, 64.5]
    out['back']['anchors']['pin1'] = [-20, -69.6, 12]
    out['back']['anchors']['pin2'] = [20, -69.6, 12]
    out['cover'].update({'curve_merge': 3.2, 'curve_smoothing': 5, 'crease_low': 0.012})
    for i, (x, z) in enumerate([[-48, 18], [48, 18], [-48, 62], [48, 62]], 1):
        out['nuts']['anchors'][f'n{i}-seat'] = [x, -31.7, z]
    out['open-check'] = scene([part(p) for p in ('P01', 'P03', 'P04', 'P05')] + hardware('spring-screw', 2) + hardware('lens-screw', 3) + hardware('nut', 4), REAR, {'press-start': [48, 10, 119], 'press-end': [48, 10, 102], 'contact': [46, -24, 72]}, size=(1800, 1600))
    for value in out.values():
        value['mode'] = 'line-v2'
        value['supersample'] = 2
        value['figure_width_pt'] = 480
        value['outer_width_pt'] = 0.8
        value['detail_width_pt'] = 0.45
    widths = {'cover': 497, 'coupon': 342, 'exploded': 511, 'button': 510, 'spring': 403.2, 'spring-detail': 200, 'lens': 511, 'nuts': 511, 'back': 489.375, 'open-check': 434.25, 'finished': 426.857}
    widths.update({f'inventory-{p}': 237 if p in ('P01', 'P02') else 149 for p in NAMES})
    widths.update({f'hardware-{kind}': 148 for kind in ('rear-screw', 'nut', 'lens-screw')})
    for name, width in widths.items():
        out[name]['figure_width_pt'] = width
    return out


def make_figures(force=False, selected=None):
    from render import render
    FIGURES.mkdir(parents=True, exist_ok=True)
    SCENES.mkdir(parents=True, exist_ok=True)
    records = {}
    for name, value in scenes().items():
        if selected and name not in selected:
            continue
        source = SCENES / f'{name}.json'
        payload = json.dumps(value, ensure_ascii=False, indent=2)
        changed = not source.exists() or source.read_text() != payload
        source.write_text(payload)
        output = FIGURES / f'{name}.png'
        resolved = copy.deepcopy(value)
        for p in resolved['parts']:
            p['file'] = str(ROOT / p['file'])
        mtime = max(Path(p['file']).stat().st_mtime for p in resolved['parts'])
        record = output.with_suffix('.render.json')
        if force or changed or not output.exists() or not record.exists() or output.stat().st_mtime < mtime:
            print(f'render {name}', flush=True)
            records[name] = render(resolved, output)
        else:
            records[name] = json.loads(record.read_text())
    return records


def text(c, x, y, value, size=11, align='left'):
    c.setFillColorRGB(0, 0, 0)
    c.setFont('ManualV2', size)
    if align == 'center':
        c.drawCentredString(x, y, value)
    elif align == 'right':
        c.drawRightString(x, y, value)
    else:
        c.drawString(x, y, value)


def lines(c, x, y, values, size=11, leading=17):
    for value in values:
        text(c, x, y, value, size)
        y -= leading


def frame(c, number, title=None, step=None):
    c.setFillColorRGB(1, 1, 1)
    c.rect(0, 0, *PAGE, stroke=0, fill=1)
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(0.55)
    c.setLineJoin(1)
    c.setLineCap(1)
    c.rect(28, 44, PAGE[0] - 56, PAGE[1] - 72, stroke=1, fill=0)
    if step is not None:
        text(c, 47, 754, str(step), 39)
        text(c, 97, 768, title, 14)
    elif title:
        text(c, 47, 778, title, 16)
    text(c, 29, 27, 'FORMNERD', 8)
    text(c, PAGE[0] / 2, 27, 'CAD R01  /  RETTLEIING M02', 7.5, 'center')
    text(c, PAGE[0] - 29, 27, f'{number:02d} / {COUNT:02d}', 8, 'right')


def picture(c, name, box, records):
    path = FIGURES / f'{name}.png'
    with Image.open(path) as im:
        iw, ih = im.size
    x, y, width, height = box
    factor = min(width / iw, height / ih)
    w, h = iw * factor, ih * factor
    left, bottom = x + (width - w) / 2, y + (height - h) / 2
    c.drawImage(str(path), left, bottom, w, h, mask='auto')
    return {key: (left + p[0] * factor, bottom + h - p[1] * factor) for key, p in records[name]['anchors'].items()}


def badge(c, label, center, target=None, radius=13, size=10):
    x, y = center
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(0.6)
    if target is not None:
        v = np.array(target) - np.array(center)
        v /= np.linalg.norm(v)
        c.line(x + v[0] * radius, y + v[1] * radius, *target)
        c.setFillColorRGB(0, 0, 0)
        c.circle(*target, 1.6, stroke=0, fill=1)
    c.setFillColorRGB(1, 1, 1)
    c.circle(x, y, radius, stroke=1, fill=1)
    text(c, x, y - size * 0.33, label, size, 'center')


def arrow(c, points, width=1.15, hollow=True):
    p = np.asarray(points, float)
    c.setStrokeColorRGB(0, 0, 0)
    c.setFillColorRGB(1, 1, 1)
    c.setLineWidth(width)
    path = c.beginPath()
    path.moveTo(*p[0])
    for v in p[1:]:
        path.lineTo(*v)
    c.drawPath(path)
    direction = p[-1] - p[-2]
    direction /= np.linalg.norm(direction)
    normal = np.array([-direction[1], direction[0]])
    a, b = p[-1] - direction * 10 + normal * 4, p[-1] - direction * 10 - normal * 4
    head = c.beginPath()
    head.moveTo(*p[-1])
    head.lineTo(*a)
    head.lineTo(*b)
    head.close()
    c.drawPath(head, stroke=1, fill=1)


def leader(c, start, target, dashed=False):
    c.setLineWidth(0.55)
    c.setStrokeColorRGB(0, 0, 0)
    c.setDash(3, 2) if dashed else c.setDash()
    c.line(*start, *target)
    c.setDash()


def needed(c, records, items):
    x, y, w, h = 390, 703, 158, 88
    c.setFillColorRGB(1, 1, 1)
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(0.55)
    c.rect(x, y, w, h, stroke=1, fill=1)
    each = w / len(items)
    for i, (figure, label, quantity) in enumerate(items):
        left = x + i * each
        if i:
            c.line(left, y, left, y + h)
        icon(c, figure, (left + 5, y + 23, each - 10, 42))
        text(c, left + 7, y + 72, label, 9)
        text(c, left + each - 7, y + 8, quantity, 12, 'right')


def icon(c, name, box):
    folder = REVIEW / 'needed-icons'
    folder.mkdir(exist_ok=True)
    with Image.open(FIGURES / f'{name}.png') as source:
        gray = source.convert('L')
        bounds = ImageOps.invert(gray).point(lambda v: 255 if v > 40 else 0).getbbox()
        crop = gray.crop(bounds)
    pad = max(3, round(max(crop.size) * 0.04))
    crop = ImageOps.expand(crop, border=pad, fill=255)
    x, y, w, h = box
    pixels = (round(w * 300 / 72), round(h * 300 / 72))
    crop.thumbnail(pixels, Image.Resampling.LANCZOS)
    output = Image.new('L', pixels, 255)
    output.paste(crop, ((pixels[0] - crop.width) // 2, (pixels[1] - crop.height) // 2))
    if name.startswith('inventory-'):
        output = output.filter(ImageFilter.MinFilter(3))
    path = folder / f'{name}.png'
    output.save(path)
    c.drawImage(str(path), x, y, w, h)


def inset(c, name, center, radius, records):
    c.saveState()
    p = c.beginPath()
    p.circle(*center, radius)
    c.clipPath(p, stroke=0, fill=0)
    c.setFillColorRGB(1, 1, 1)
    c.circle(*center, radius, stroke=0, fill=1)
    points = picture(c, name, (center[0] - radius + 4, center[1] - radius + 4, 2 * radius - 8, 2 * radius - 8), records)
    c.restoreState()
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(0.65)
    c.circle(*center, radius, stroke=1, fill=0)
    return points


def check(c, x, y, value):
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(0.65)
    c.rect(x, y - 1, 8, 8, stroke=1, fill=0)
    text(c, x + 18, y, value, 10)


def overview(c, records):
    frame(c, 4, 'MONTERINGSOVERSIKT')
    p = picture(c, 'exploded', (42, 119, 511, 620), records)
    for label, point in {'P01': (157, 270), 'P02': (475, 221), 'P03': (65, 503), 'P04': (359, 649), 'P05': (487, 551)}.items():
        badge(c, label, point, p[label], radius=15, size=11)
    text(c, PAGE[0] / 2, 84, 'Monter innmaten frå den opne baksida.', 11, 'center')
    c.showPage()


def build(records):
    REVIEW.mkdir(parents=True, exist_ok=True)
    pdfmetrics.registerFont(TTFont('ManualV2', str(FONT / 'DejaVuSans.ttf')))
    output = REVIEW / 'Kamera-boge-M02.pdf'
    c = canvas.Canvas(str(output), pagesize=PAGE, pageCompression=1)
    c.setTitle('Kamera med boge - Monteringsrettleiing M02')
    c.setAuthor('FormNerd')

    frame(c, 1)
    text(c, PAGE[0] / 2, 762, 'KAMERA MED BOGE', 22, 'center')
    text(c, PAGE[0] / 2, 733, 'MONTERINGSRETTLEIING', 11, 'center')
    picture(c, 'cover', (49, 221, 497, 469), records)
    text(c, PAGE[0] / 2, 160, 'Mekanisk prøvebygg', 12, 'center')
    text(c, PAGE[0] / 2, 135, 'Nominell breidd 145 mm', 10, 'center')
    text(c, PAGE[0] / 2, 92, 'Prøv T01 før hovuddelane. Sjå side 3.', 10, 'center')
    c.showPage()

    frame(c, 2, 'DELAR')
    positions = [('P01', (47, 486, 237, 227)), ('P02', (311, 486, 237, 227)), ('P03', (47, 214, 149, 188)), ('P04', (223, 214, 149, 188)), ('P05', (399, 214, 149, 188))]
    for name, box in positions:
        picture(c, f'inventory-{name}', box, records)
        badge(c, name, (box[0] + 15, box[1] + box[3] + 27))
        text(c, box[0] + box[2] - 8, box[1] + box[3] + 23, '1×', 16, 'right')
        text(c, box[0] + box[2] / 2, box[1] - 19, NAMES[name], 11, 'center')
    c.setLineWidth(0.55)
    c.line(47, 445, 548, 445)
    c.line(47, 166, 548, 166)
    lines(c, 47, 122, ['Alle fem delane er i same materiale.', 'Kontroller at hola er opne og at kantane er reine.'], 11, 19)
    c.showPage()

    frame(c, 3, 'MASKINVARE OG PRØVEBIT')
    for i, (name, label, quantity) in enumerate([('rear-screw', 'A  M3 × 12', '6×'), ('nut', 'B  M3-mutter', '4×'), ('lens-screw', 'C  M2,5 × 8', '3×')]):
        x = 47 + i * 172
        text(c, x, 731, label, 12)
        picture(c, f'hardware-{name}', (x + 3, 625, 148, 85), records)
        text(c, x + 145, 604, quantity, 18, 'right')
    c.line(47, 577, 548, 577)
    text(c, 47, 550, 'Unbrakonøklar som passar dei faktiske skruane.', 11)
    text(c, 47, 507, 'T01  Prøv passningane først', 14)
    p = picture(c, 'coupon', (48, 211, 499, 266), records)
    badge(c, '1', (88, 451), p['button'], radius=10)
    badge(c, '2', (477, 450), p['nuts'], radius=10)
    badge(c, '3', (479, 234), p['pilots'], radius=10)
    lines(c, 47, 181, ['1  Knapp: Ø16,0 / 16,4 / 16,8.', '2  Mutter: AF5,7 / 5,9 / 6,1.', '3  Pilotar: Ø2,0 / 2,5 / 3,4. Prøv dei faktiske skruane.'], 10.5, 18)
    lines(c, 47, 111, ['Print prøvebiten før huset. Juster passningar som kiler eller sprekk.', 'Maskinvara er nominell. Ikkje tving skruar eller mutrar på plass.'], 10, 18)
    c.showPage()

    overview(c, records)

    frame(c, 5, 'Før inn knappen', 1)
    needed(c, records, [('inventory-P04', 'P04', '1×')])
    p = picture(c, 'button', (43, 198, 510, 485), records)
    arrow(c, [p['start'], p['corner']])
    arrow(c, [p['corner'], p['end']])
    badge(c, 'P04', (228, 387), p['button'], radius=14)
    text(c, p['start'][0] - 17, p['start'][1] - 22, '1', 16)
    text(c, p['corner'][0] + 11, (p['corner'][1] + p['end'][1]) / 2, '2', 16)
    lines(c, 47, 142, ['1  Før P04 inn frå baksida, 46 mm lågare enn sluttstillinga.', '2  Løft knappen 46 mm rett opp. Foten skal bli verande inne i huset.'], 11, 20)
    c.showPage()

    frame(c, 6, 'Fest prøvefjøra', 2)
    needed(c, records, [('inventory-P05', 'P05', '1×'), ('hardware-rear-screw', 'A', '2×')])
    p = picture(c, 'spring', (42, 348, 511, 336), records)
    arrow(c, [p['start'], p['end']])
    d = inset(c, 'spring-detail', (426, 201), 104, records)
    leader(c, (387, 299), (p['end'][0] + 3, p['end'][1] - 7))
    lines(c, 47, 291, ['Skyv P05 inn frå baksida.', 'Legg tunga under knappefoten.'], 11, 19)
    lines(c, 47, 214, ['Fest med to M3 × 12.', 'Stram varsamt i pilotane.'], 11, 19)
    text(c, 426, 77, 'Tunga under foten', 10, 'center')
    c.showPage()

    frame(c, 7, 'Fest linseinnsatsen', 3)
    needed(c, records, [('inventory-P03', 'P03', '1×'), ('hardware-lens-screw', 'C', '3×')])
    text(c, 47, 701, 'SJÅ FRÅ FRAMSIDA', 9)
    p = picture(c, 'lens', (42, 193, 511, 483), records)
    arrow(c, [p['start'], p['end']])
    badge(c, 'P03', (478, 629), p['ring'], radius=14)
    lines(c, 47, 143, ['Før P03 inn framme. Rett dei tre hola mot pilotane.', 'Set inn tre M2,5 × 8 frå framsida. Stram jamt.'], 11, 20)
    text(c, 47, 84, 'Ø32 mm er fri mekanisk opning. Optikk er ikkje montert.', 9.5)
    c.showPage()

    frame(c, 8, 'Legg inn mutrane', 4)
    needed(c, records, [('hardware-nut', 'B', '4×')])
    text(c, 47, 701, 'SJÅ FRÅ BAKSIDA', 9)
    p = picture(c, 'nuts', (42, 239, 511, 432), records)
    for i, point in enumerate([(88, 349), (220, 365), (88, 504), (200, 405)], 1):
        badge(c, 'B', point, p[f'n{i}'], radius=11, size=11)
        arrow(c, [p[f'n{i}'], p[f'n{i}-seat']], width=0.9)
    lines(c, 47, 190, ['Set éin M3-mutter i kvar sekskantlomme frå baksida.', 'Alle fire skal liggje heilt inne før bakdekselet kjem på.'], 11, 20)
    text(c, 47, 106, 'For trongt? Prøv T01 og juster passninga. Ikkje bruk makt.', 10)
    c.showPage()

    frame(c, 9, 'Prøv mekanismen ope', 5)
    p = picture(c, 'open-check', (42, 331, 511, 386), records)
    arrow(c, [p['press-start'], p['press-end']])
    text(c, p['press-start'][0] + 13, p['press-start'][1] - 10, '1,2 mm', 11)
    inset(c, 'spring-detail', (426, 187), 95, records)
    leader(c, (397, 278), p['contact'])
    check(c, 47, 280, 'Trykk ned og slepp knappen.')
    check(c, 47, 244, 'Knappen skal gå tilbake utan å kile.')
    check(c, 47, 208, 'Fjørtunga skal bli under knappefoten.')
    lines(c, 47, 103, ['Kontroller dette før du lukkar huset.', '1,2 mm er nominell rørsle. Fjørverknaden må prøvast fysisk.'], 10, 18)
    c.showPage()

    frame(c, 10, 'Lukk bakdekselet', 6)
    needed(c, records, [('inventory-P02', 'P02', '1×'), ('hardware-rear-screw', 'A', '4×')])
    p = picture(c, 'back', (42, 241, 511, 435), records)
    arrow(c, [p['start'], p['end']])
    badge(c, '2×', (96, 292), radius=13)
    leader(c, (109, 292), p['pin1'], dashed=True)
    lines(c, 47, 194, ['Rett inn dei to styrepinnane. Før P02 rett mot huset.', 'Set inn fire M3 × 12 frå baksida. Stram litt om gongen, diagonalt.'], 11, 20)
    text(c, 47, 105, 'Fuga skal vere jamn. Stopp dersom dekselet klemmer eller huset sprekk.', 10)
    c.showPage()

    frame(c, 11, 'SLUTTKONTROLL')
    picture(c, 'finished', (49, 409, 497, 332), records)
    check(c, 47, 375, 'Knappen glir fritt og går tilbake.')
    check(c, 47, 347, 'Fjør, linseinnsats og bakdeksel sit fast utan sprekk.')
    check(c, 47, 319, 'Dekselet kan løysast og monterast på nytt.')
    c.line(47, 287, 548, 287)
    text(c, 47, 261, 'Før hovudutskrift', 12)
    lines(c, 47, 237, ['P1S og PLA: 0,4 mm dyse, 0,20 mm lag, 3 veggar og 15 % gyroid', 'er eit startgrunnlag. Vel faktisk plate/filament. Vurder støtte og brim.'], 10, 17)
    lines(c, 47, 180, ['Modellen er digitalt kontrollert. Slicing, fysisk prøvepass og fjørlevetid', 'står att. Faktisk maskinvare og veggtjukkleik må kontrollerast.'], 10, 17)
    lines(c, 47, 122, ['USB-opninga er førebels. Elektronikk, optikk og lading er ikkje prøvde.', 'Opne huset ved å løyse dei fire bakskruane og trekkje dekselet rett bakover.'], 10, 17)
    c.save()
    manifest = {'document_revision': 'M02', 'geometry_revision': 'R01', 'pdf': output.name, 'page_count': COUNT, 'figures': list(records), 'source': 'actual unchanged CAD meshes and deterministic orthographic line-v2 projection', 'style_reference': 'imagegen layout draft and supplied furniture assembly pages', 'status': 'mechanical prototype; unsliced; physically untested'}
    (REVIEW / 'manual-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    print(output, flush=True)
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--force', action='store_true')
    parser.add_argument('--layout-only', action='store_true')
    parser.add_argument('--figures-only', action='store_true')
    parser.add_argument('--select', nargs='+')
    args = parser.parse_args()
    records = {name: json.loads((FIGURES / f'{name}.render.json').read_text()) for name in scenes()} if args.layout_only else make_figures(args.force, args.select)
    if not args.figures_only:
        build(records)
