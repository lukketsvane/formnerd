import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as ndi


def components(mask, minimum):
    labels, count = ndi.label(mask, np.ones((3, 3), bool))
    if not count:
        return mask
    sizes = np.bincount(labels.ravel())
    keep = sizes >= minimum
    keep[0] = False
    return keep[labels]


def skeleton(mask):
    mask = mask.copy()
    for _ in range(80):
        changed = False
        for phase in (0, 1):
            p = np.pad(mask, 1)
            n = [p[:-2, 1:-1], p[:-2, 2:], p[1:-1, 2:], p[2:, 2:], p[2:, 1:-1], p[2:, :-2], p[1:-1, :-2], p[:-2, :-2]]
            count = np.sum(n, axis=0)
            transitions = sum((~n[i]) & n[(i + 1) % 8] for i in range(8))
            remove = mask & (count >= 2) & (count <= 6) & (transitions == 1)
            remove &= ~(n[0] & n[2] & n[4 if phase == 0 else 6])
            remove &= ~(n[2 if phase == 0 else 0] & n[4] & n[6])
            changed |= bool(remove.any())
            mask[remove] = False
        if not changed:
            break
    return mask


def smooth_curves(mask, sampling, sigma=3.0):
    yy, xx = np.nonzero(mask)
    nodes = set(zip(yy.tolist(), xx.tolist()))
    adjacency = {}
    for y, x in nodes:
        neighbours = []
        for dy, dx in ((-1, 0), (0, 1), (1, 0), (0, -1), (-1, -1), (-1, 1), (1, 1), (1, -1)):
            p = y + dy, x + dx
            if p in nodes and not (dy and dx and ((y + dy, x) in nodes or (y, x + dx) in nodes)):
                neighbours.append(p)
        adjacency[y, x] = neighbours
    visited = set()
    paths = []
    ends = [p for p in nodes if len(adjacency[p]) != 2]
    for start in ends + list(nodes):
        for nxt in adjacency[start]:
            edge = tuple(sorted((start, nxt)))
            if edge in visited:
                continue
            visited.add(edge)
            path = [start, nxt]
            while len(adjacency[nxt]) == 2 and nxt != start:
                choices = [p for p in adjacency[nxt] if p != path[-2]]
                if not choices:
                    break
                after = choices[0]
                edge = tuple(sorted((nxt, after)))
                if edge in visited:
                    break
                visited.add(edge)
                path.append(after)
                nxt = after
            if len(path) >= 6 * sampling:
                paths.append(path)
    image = Image.new('1', (mask.shape[1], mask.shape[0]))
    draw = ImageDraw.Draw(image)
    for path in paths:
        p = np.asarray(path, float)
        closed = np.linalg.norm(p[0] - p[-1]) < 2
        if closed and len(p) < 18 * sampling:
            continue
        q = ndi.gaussian_filter1d(p, sigma * sampling, axis=0, mode='wrap' if closed else 'nearest')
        if not closed:
            q += np.linspace(1, 0, len(p))[:, None] * (p[0] - q[0])
            q += np.linspace(0, 1, len(p))[:, None] * (p[-1] - q[-1])
        draw.line([(float(x), float(y)) for y, x in q], fill=1, width=1)
    return np.asarray(image, bool)


def thin_ridges(magnitude, dx, dy):
    jxx = np.sum(dx * dx, axis=2)
    jyy = np.sum(dy * dy, axis=2)
    jxy = np.sum(dx * dy, axis=2)
    angle = 0.5 * np.arctan2(2 * jxy, jxx - jyy)
    yy, xx = np.indices(magnitude.shape, dtype=np.float32)
    sx, sy = np.cos(angle), np.sin(angle)
    left = ndi.map_coordinates(magnitude, [yy - sy, xx - sx], order=1, mode='nearest')
    right = ndi.map_coordinates(magnitude, [yy + sy, xx + sx], order=1, mode='nearest')
    return (magnitude >= left) & (magnitude >= right)


def feature_lines(loaded, project, depth, sampling, pixels_per_unit, angle=35, parts=None):
    import vtk
    from vtk.util.numpy_support import numpy_to_vtk, numpy_to_vtkIdTypeArray, vtk_to_numpy
    height, width = depth.shape
    ink = np.zeros(depth.shape, bool)
    for index, (vertices, faces, _) in enumerate(loaded):
        mesh = vtk.vtkPolyData()
        points = vtk.vtkPoints()
        points.SetData(numpy_to_vtk(np.asarray(vertices, np.float64), deep=True))
        mesh.SetPoints(points)
        cells = vtk.vtkCellArray()
        indices = np.column_stack((np.full(len(faces), 3), faces)).astype(np.int64)
        cells.SetCells(len(faces), numpy_to_vtkIdTypeArray(indices.ravel(), deep=True))
        mesh.SetPolys(cells)
        clean = vtk.vtkCleanPolyData()
        clean.SetInputData(mesh)
        clean.SetTolerance(1e-9)
        edges = vtk.vtkFeatureEdges()
        edges.SetInputConnection(clean.GetOutputPort())
        organic = parts is not None and Path(parts[index]['file']).stem in ('P01', 'P02')
        edges.SetFeatureAngle(max(angle, 70) if organic else angle)
        edges.BoundaryEdgesOn()
        edges.FeatureEdgesOn()
        edges.ManifoldEdgesOff()
        edges.NonManifoldEdgesOff()
        edges.Update()
        output = edges.GetOutput()
        if not output.GetNumberOfLines():
            continue
        points = project(vtk_to_numpy(output.GetPoints().GetData()))
        segments = vtk_to_numpy(output.GetLines().GetData()).reshape(-1, 3)[:, 1:]
        a, b = points[segments[:, 0]], points[segments[:, 1]]
        counts = np.ceil(np.linalg.norm(b[:, :2] - a[:, :2], axis=1) * 2).astype(int) + 1
        cumulative = np.cumsum(counts)
        first = 0
        while first < len(a):
            base = cumulative[first - 1] if first else 0
            last = min(len(a), max(first + 1, np.searchsorted(cumulative, base + 600000, side='right')))
            n = counts[first:last]
            k = np.repeat(np.arange(first, last), n)
            local = np.arange(n.sum()) - np.repeat(np.cumsum(n) - n, n)
            t = local / np.maximum(counts[k] - 1, 1)
            p = a[k] + (b[k] - a[k]) * t[:, None]
            xy = np.round(p[:, :2]).astype(int)
            valid = (xy[:, 0] >= 0) & (xy[:, 0] < width) & (xy[:, 1] >= 0) & (xy[:, 1] < height)
            xy, z = xy[valid], p[valid, 2]
            visible = z >= depth[xy[:, 1], xy[:, 0]] - 1.15 / pixels_per_unit
            xy = xy[visible]
            ink[xy[:, 1], xy[:, 0]] = True
            first = last
    return ink


def lines(ids, depth, normals, sampling, scene, pixels_per_unit, features=None):
    ids = ids.copy()
    foreground = ids > 0
    empty, _ = ndi.label(~foreground)
    areas = np.bincount(empty.ravel())
    tiny = (areas <= 4 * sampling * sampling)
    tiny[0] = False
    tiny[empty[0, 0]] = False
    repair = tiny[empty]
    if repair.any():
        near = ndi.distance_transform_edt(~foreground, return_distances=False, return_indices=True)
        ids[repair] = ids[tuple(near[:, repair])]
        depth[repair] = depth[tuple(near[:, repair])]
        normals[repair] = normals[tuple(near[:, repair])]
    foreground = ids > 0
    soft = ndi.gaussian_filter(foreground.astype(np.float32), 0.5 * sampling)
    foreground = soft >= 0.5
    exterior = ndi.binary_propagation(np.pad(np.zeros(ids.shape, bool), 1, constant_values=True), mask=np.pad(~foreground, 1, constant_values=True))[1:-1, 1:-1]
    inside_distance = ndi.distance_transform_edt(foreground)
    contour = (inside_distance <= 1.01) & foreground
    outside = ndi.maximum_filter(exterior, size=3) & contour
    holes = contour & ~outside
    seams = np.zeros(ids.shape, bool)
    crease = np.zeros(ids.shape, bool)
    for axis in (0, 1):
        for shift in (-1, 1):
            other = np.roll(ids, shift, axis)
            seams |= (ids > 0) & (other > 0) & (ids < other)
    sharp = np.zeros(ids.shape, bool) if features is None else components(features & (inside_distance > 1.2 * sampling), 4 * sampling)
    sigma = float(scene.get('normal_smoothing', 2.2)) * sampling
    for ident in np.unique(ids):
        if not ident:
            continue
        mask = ids == ident
        yy, xx = np.nonzero(mask)
        margin = max(8, int(4 * sigma))
        y0, y1 = max(0, yy.min() - margin), min(ids.shape[0], yy.max() + margin + 1)
        x0, x1 = max(0, xx.min() - margin), min(ids.shape[1], xx.max() + margin + 1)
        crop = mask[y0:y1, x0:x1]
        weight = ndi.gaussian_filter(crop.astype(np.float32), sigma)
        n = normals[y0:y1, x0:x1]
        n = np.stack([ndi.gaussian_filter(n[:, :, i] * crop, sigma) / np.maximum(weight, 1e-6) for i in range(3)], axis=2)
        n /= np.maximum(np.linalg.norm(n, axis=2, keepdims=True), 1e-6)
        dx = np.stack([ndi.gaussian_filter(n[:, :, i], 0.6 * sampling, order=(0, 1)) for i in range(3)], axis=2)
        dy = np.stack([ndi.gaussian_filter(n[:, :, i], 0.6 * sampling, order=(1, 0)) for i in range(3)], axis=2)
        jxx, jyy, jxy = np.sum(dx * dx, axis=2), np.sum(dy * dy, axis=2), np.sum(dx * dy, axis=2)
        magnitude = np.sqrt(np.maximum(0, (jxx + jyy + np.sqrt((jxx - jyy) ** 2 + 4 * jxy * jxy)) / 2)) * sampling
        interior = ndi.distance_transform_edt(crop) > 2 * sampling
        ridges = thin_ridges(magnitude, dx, dy) & interior
        strong = ridges & (magnitude >= float(scene.get('crease_high', 0.072)))
        weak = ridges & (magnitude >= float(scene.get('crease_low', 0.025)))
        joined = ndi.binary_propagation(strong, structure=np.ones((3, 3), bool), mask=weak)
        joined = components(joined, int(float(scene.get('minimum_curve', 11)) * sampling))
        crease[y0:y1, x0:x1] |= joined
    crease &= ndi.distance_transform_edt(~sharp) > 2.5 * sampling
    for index, part in enumerate(scene.get('parts', []), 1):
        if Path(part['file']).stem not in ('P01', 'P02'):
            continue
        raw = crease & (ids == index)
        if not raw.any():
            continue
        yy, xx = np.nonzero(raw)
        margin = 5 * sampling
        y0, y1 = max(0, yy.min() - margin), min(ids.shape[0], yy.max() + margin + 1)
        x0, x1 = max(0, xx.min() - margin), min(ids.shape[1], xx.max() + margin + 1)
        crop = raw[y0:y1, x0:x1]
        radius = max(1, int(float(scene.get('curve_merge', 1.4)) * sampling))
        gy, gx = np.mgrid[-radius:radius + 1, -radius:radius + 1]
        disk = gx * gx + gy * gy <= radius * radius
        joined = ndi.binary_closing(ndi.binary_dilation(crop, disk), disk)
        cleaned = smooth_curves(skeleton(joined), sampling, float(scene.get('curve_smoothing', 3)))
        crease[ids == index] = False
        crease[y0:y1, x0:x1] |= components(cleaned, 11 * sampling)
    details = components(seams | holes | sharp | crease, 3 * sampling)
    outer_width = float(scene.get('outer_width_pt', 0.8)) * scene.get('size', [1800, 1600])[0] / float(scene.get('figure_width_pt', 480))
    detail_width = float(scene.get('detail_width_pt', 0.45)) * scene.get('size', [1800, 1600])[0] / float(scene.get('figure_width_pt', 480))
    outer_stroke = ndi.distance_transform_edt(~outside) <= outer_width * sampling / 2
    detail_stroke = ndi.distance_transform_edt(~details) <= detail_width * sampling / 2
    ink = outer_stroke | detail_stroke
    image = Image.fromarray(np.where(ink, 16, 255).astype(np.uint8)).convert('RGB')
    return image, {'outer_width_pt': scene.get('outer_width_pt', 0.8), 'detail_width_pt': scene.get('detail_width_pt', 0.45), 'repaired_raster_pixels': int(repair.sum()), 'outer_pixels': int(outside.sum()), 'crease_pixels': int(crease.sum()), 'sharp_pixels': int(sharp.sum()), 'detail_pixels': int(details.sum())}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('buffers')
    parser.add_argument('scene')
    parser.add_argument('output')
    args = parser.parse_args()
    b = np.load(args.buffers)
    scene = json.loads(Path(args.scene).read_text())
    image, report = lines(b['ids'], b['depth'], b['normals'], int(b['sampling']), scene, float(b['pixels_per_unit']), b['features'] if 'features' in b else None)
    image.resize(tuple(scene['size']), Image.Resampling.LANCZOS).save(args.output)
    print(json.dumps(report))
