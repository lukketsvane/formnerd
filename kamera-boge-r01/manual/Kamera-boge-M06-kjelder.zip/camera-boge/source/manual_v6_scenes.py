"""Extra scenes for M06: the T01 fit test with P04 and hardware above the graded holes, and the hex key."""
import json
from pathlib import Path

import numpy as np
import trimesh

from vector_illustration import illustrate

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / 'review' / 'manual-v3' / 'figures'
FIX = ROOT / 'review' / 'manual-v3' / 'fixtures'
GAP_Z = 4.0


def rot_x(deg):
    return trimesh.transformations.rotation_matrix(np.radians(deg), [1, 0, 0])


def placed(src, rotation, xy, low_z, name):
    m = trimesh.load(ROOT / src, force='mesh')
    m.apply_transform(rotation)
    b = m.bounds
    m.apply_translation([xy[0] - (b[0][0] + b[1][0]) / 2, xy[1] - (b[0][1] + b[1][1]) / 2, low_z - b[0][2]])
    out = FIX / f'{name}.stl'
    m.export(out)
    return {'file': str(out.relative_to(ROOT))}


def coupon_test():
    FIX.mkdir(parents=True, exist_ok=True)
    holes = {'h16.0': [12, 17.5, 4], 'h16.4': [35, 17.5, 4], 'h16.8': [58, 17.5, 4],
             'n5.7': [10, 30, 4], 'n5.9': [30, 30, 4], 'n6.1': [50, 30, 4],
             'p2.0': [7, 5, 4], 'p2.5': [23, 5, 4], 'p3.4': [39, 5, 4]}
    variants = {
        'coupon-test-a': ([placed('print/P04.stl', rot_x(180), (35, 17.5), GAP_Z + 16, 'test-P04')],
                          {'P04-low': [35, 17.5, GAP_Z + 16], 'P04-top': [35, 17.5, GAP_Z + 16 + 26.6]}),
        'coupon-test-b': ([placed('cad/hardware/nut-01.stl', rot_x(90), (30, 30), GAP_Z + 6, 'test-nut'),
                           placed('cad/hardware/lens-screw-01.stl', rot_x(90), (7, 5), GAP_Z + 9, 'test-lens-screw'),
                           placed('cad/hardware/rear-screw-01.stl', rot_x(-90), (23, 5), GAP_Z + 9, 'test-rear-screw'),
                           placed('cad/hardware/rear-screw-01.stl', rot_x(-90), (39, 5), GAP_Z + 9, 'test-rear-screw-2')],
                          {'nut-low': [30, 30, GAP_Z + 6], 'C-low': [7, 5, GAP_Z + 9], 'A-low': [23, 5, GAP_Z + 9], 'A2-low': [39, 5, GAP_Z + 9],
                           'C-top': [7, 5, GAP_Z + 9 + 10.5], 'A-top': [23, 5, GAP_Z + 9 + 15], 'A2-top': [39, 5, GAP_Z + 9 + 15]}),
    }
    target = [35, 17.5, 14]
    for name, (extra, anchors) in variants.items():
        scene = {'size': [1600, 1100], 'figure_width_pt': 499, 'outer_width_pt': .8, 'detail_width_pt': .4, 'simplify_tolerance_pt': .08,
                 'parts': [{'file': 'print/T01.stl'}] + extra,
                 'camera': {'direction': [.3, -.62, 1.35], 'up': [0, 0, 1], 'target': target, 'scale': 70},
                 'anchors': {**holes, **anchors},
                 'illustration_notes': ['T01 with P04 or hardware placed above the graded holes for the fit test; offsets along each hole axis are illustrative.']}
        (ROOT / 'source' / 'scenes-v3' / f'{name}.json').write_text(json.dumps(scene, indent=1))
        illustrate(scene, FIG / name)


def hex_key():
    key = ROOT / 'review' / 'manual-v3' / 'fixtures' / 'illustrated-key-AF2.5.stl'
    scene = {'size': [700, 500], 'figure_width_pt': 135, 'outer_width_pt': .8, 'detail_width_pt': .4, 'simplify_tolerance_pt': .06,
             'parts': [{'file': str(key.relative_to(ROOT))}], 'camera': {'direction': [1, -1.6, .8], 'up': [0, 0, 1], 'padding': 1.1}}
    (ROOT / 'source' / 'scenes-v3' / 'tool-hex-key.json').write_text(json.dumps(scene, indent=1))
    illustrate(scene, FIG / 'tool-hex-key')


def button_scenes():
    common = {'figure_width_pt': 499, 'outer_width_pt': .8, 'detail_width_pt': .4, 'simplify_tolerance_pt': .08, 'projection_sampling': 2}
    context = {**common, 'size': [1400, 1200],
               'parts': [{'file': 'cad/P01.stl'}, {'file': 'cad/P04.stl', 'translate': [0, -55, -46]}],
               'camera': {'direction': [1, -1, .65], 'up': [0, 0, 1], 'padding': 1.08},
               'anchors': {'route-start': [48, -45, 41.7], 'route-corner': [48, 10, 41.7], 'route-end': [48, 10, 88.5], 'top-hole': [48, 10, 101]}}
    test = {**common, 'size': [1400, 1200],
            'parts': [{'file': 'cad/P01.stl'}, {'file': 'cad/P04.stl'}, {'file': 'cad/P05.stl'},
                      {'file': 'cad/hardware/spring-screw-01.stl'}, {'file': 'cad/hardware/spring-screw-02.stl'}],
            'camera': {'direction': [.85, -1, .95], 'up': [0, 0, 1], 'padding': 1.08},
            'anchors': {'top': [48, 10, 101], 'foot': [48, 10, 74.4], 'spring': [45, -8, 71.4], 'screws': [45, -27, 71.4]}}
    for name, scene in (('button-context', context), ('button-test', test)):
        (ROOT / 'source' / 'scenes-v3' / f'{name}.json').write_text(json.dumps(scene, indent=1))
        illustrate(scene, FIG / name)


if __name__ == '__main__':
    coupon_test()
    hex_key()
    button_scenes()
