import argparse
import json
from pathlib import Path

import numpy as np
from reportlab.graphics import renderPDF
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.lib.colors import black
from svglib.svglib import svg2rlg


ROOT = Path(__file__).resolve().parents[1]
REVIEW = ROOT / 'review' / 'manual-v3'
PAGE = (595.276, 841.89)
PAGES = 16
PRINT = json.loads((ROOT / 'source' / 'print-m04.json').read_text(encoding='utf-8'))


def text(c, x, y, value, size=11, align='left'):
    c.setFillColorRGB(0, 0, 0)
    c.setFont('ManualV3', size)
    if align == 'center':
        c.drawCentredString(x, y, value)
    elif align == 'right':
        c.drawRightString(x, y, value)
    else:
        c.drawString(x, y, value)


def svg(c, asset, box, config_directory):
    path = (config_directory / asset['svg']).resolve()
    record = json.loads((config_directory / asset['record']).resolve().read_text())
    drawing = svg2rlg(str(path))
    if drawing is None or not drawing.width or not drawing.height:
        raise ValueError(f'Invalid vector figure: {path}')
    x, y, w, h = box
    factor = min(w / drawing.width, h / drawing.height)
    scale_strokes(drawing, asset.get('stroke_scale', 1) / factor if asset.get('preserve_strokes') else asset.get('stroke_scale', 1))
    width, height = drawing.width * factor, drawing.height * factor
    left, bottom = x + (w - width) / 2, y + (h - height) / 2
    c.saveState()
    c.translate(left, bottom)
    c.scale(factor, factor)
    clip = c.beginPath()
    clip.rect(0, 0, drawing.width, drawing.height)
    c.clipPath(clip, stroke=0, fill=0)
    renderPDF.draw(drawing, c, 0, 0)
    c.restoreState()
    iw, ih = record['size']
    points = {name: (left + p[0] / iw * width, bottom + height - p[1] / ih * height) for name, p in record.get('anchors', {}).items()}
    return record, points, (left, bottom, width, height)


def scale_strokes(node, factor):
    if getattr(node, 'strokeWidth', None) is not None:
        node.strokeWidth *= factor
    if getattr(node, 'strokeColor', None) is not None:
        node.strokeColor = black
    for child in getattr(node, 'contents', []):
        scale_strokes(child, factor)


def project(record, points, placement):
    cam = record['camera']
    forward = np.array(cam['direction'], float)
    forward /= np.linalg.norm(forward)
    up = np.array(cam['up'], float)
    right = np.cross(up, forward)
    right /= np.linalg.norm(right)
    up = np.cross(forward, right)
    p = (np.asarray(points, float) - cam['target']) @ np.stack((right, up, forward)).T
    iw, ih = record['size']
    screen = np.column_stack((iw / 2 + p[:, 0] * ih / cam['scale'], ih / 2 - p[:, 1] * ih / cam['scale']))
    x, y, w, h = placement
    return np.column_stack((x + screen[:, 0] / iw * w, y + h - screen[:, 1] / ih * h))


def line(c, points, width=0.7, dashed=False):
    p = np.asarray(points, float)
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(width)
    c.setDash(3, 2) if dashed else c.setDash()
    path = c.beginPath()
    path.moveTo(*p[0])
    for v in p[1:]:
        path.lineTo(*v)
    c.drawPath(path)
    c.setDash()


def arrow(c, points, width=1):
    p = np.asarray(points, float)
    line(c, p, width)
    v = p[-1] - p[-2]
    v /= np.linalg.norm(v)
    n = np.array([-v[1], v[0]])
    a = p[-1] - v * 8 + n * 3.3
    b = p[-1] - v * 8 - n * 3.3
    c.setFillColorRGB(1, 1, 1)
    path = c.beginPath()
    path.moveTo(*p[-1])
    path.lineTo(*a)
    path.lineTo(*b)
    path.close()
    c.drawPath(path, stroke=1, fill=1)


def rotation(c, record, placement, x, y, z):
    a = np.linspace(0.6, -4.1, 45)
    points = [[x + 6 * np.cos(v), y, z + 6 * np.sin(v)] for v in a]
    arrow(c, project(record, points, placement), 0.9)


def make_assets():
    import cadquery as cq
    import trimesh
    from vtk.util.numpy_support import vtk_to_numpy
    from vector_illustration import illustrate, mesh

    folder = REVIEW / 'proofs'
    fixtures = REVIEW / 'fixtures'
    folder.mkdir(parents=True, exist_ok=True)
    fixtures.mkdir(parents=True, exist_ok=True)
    af = 2.45
    shaft = cq.Workplane('XY').polygon(6, af / np.cos(np.pi / 6)).extrude(32.45).val().rotate((0, 0, 0), (1, 0, 0), -90).translate(cq.Vector(36, -58, 71.4))
    handle = cq.Workplane('XY').polygon(6, af / np.cos(np.pi / 6)).extrude(18).val().translate(cq.Vector(36, -58, 71.4))
    key = shaft.fuse(handle)
    vertices, faces = key.tessellate(.025, .15)
    key_path = fixtures / 'illustrated-key-AF2.5.stl'
    trimesh.Trimesh(np.array([p.toTuple() for p in vertices]), np.array(faces), process=True).export(key_path)
    scenes = {}
    for name, offset in [('before', -47), ('after', 0)]:
        parts = [{'file': 'cad/P04.stl'}, {'file': 'cad/P05.stl'}] + [{'file': f'cad/hardware/spring-screw-{i:02d}.stl', 'translate': [0, offset, 0]} for i in (1, 2)]
        if name == 'after':
            parts.append({'file': str(key_path.relative_to(ROOT))})
        scenes[name] = {'size': [1200, 900], 'figure_width_pt': 238, 'outer_width_pt': .8, 'detail_width_pt': .4, 'simplify_tolerance_pt': .08, 'parts': parts, 'camera': {'direction': [1, -1, .4], 'up': [0, 0, 1], 'target': [45, -30, 82], 'scale': 80}, 'anchors': {'head-left': [36, -27.1 + offset, 71.4], 'head-right': [54, -27.1 + offset, 71.4], 'spring-left': [36, -24, 71.4], 'spring-right': [54, -24, 71.4], 'tip': [48, 10, 74.4]}}
    direction = np.array([1, -1, .4], float)
    direction /= np.linalg.norm(direction)
    right = np.cross([0, 0, 1], direction)
    right /= np.linalg.norm(right)
    up = np.cross(direction, right)
    basis = np.stack((right, up, direction))
    target = np.array([45, -30, 82], float)
    points = np.concatenate([vtk_to_numpy(mesh(p)[0].GetPoints().GetData()) for s in scenes.values() for p in s['parts']])
    projected = (points - target) @ basis.T
    lo = projected[:, :2].min(0) - 3
    hi = projected[:, :2].max(0) + 3
    center = (lo + hi) / 2
    fixed_target = target + right * center[0] + up * center[1]
    span = hi - lo
    dimensions = np.ceil(span * 14).astype(int)
    width_pt = min(425, 245 * dimensions[0] / dimensions[1])
    for name, value in scenes.items():
        value['size'] = dimensions.tolist()
        value['figure_width_pt'] = float(width_pt)
        value['camera'].update({'target': fixed_target.tolist(), 'scale': float(span[1])})
        path = folder / f'spring-fastening-{name}'
        path.with_suffix('.scene.json').write_text(json.dumps(value, ensure_ascii=False, indent=2))
        illustrate(value, path)
    screw = {'size': [600, 400], 'figure_width_pt': 60, 'outer_width_pt': .7, 'detail_width_pt': .4, 'simplify_tolerance_pt': .06, 'parts': [{'file': 'cad/hardware/spring-screw-01.stl'}], 'camera': {'direction': [1, -1, .4], 'up': [0, 0, 1], 'target': [36, -21, 71.4], 'scale': 18}}
    (folder / 'spring-screw-icon.scene.json').write_text(json.dumps(screw, ensure_ascii=False, indent=2))
    illustrate(screw, folder / 'spring-screw-icon')
    config = {name: {'svg': f'spring-fastening-{name}.svg', 'record': f'spring-fastening-{name}.render.json'} for name in scenes}
    config['overview'] = {'svg': 'spring-vector-proof.svg', 'record': 'spring-vector-proof.render.json', 'stroke_scale': 3.15}
    config['screw'] = {'svg': 'spring-screw-icon.svg', 'record': 'spring-screw-icon.render.json'}
    config['illustration_tool'] = {'status': 'nominal illustration only; actual tool fit unverified', 'model_socket_af_mm': 2.5, 'illustrated_key_af_mm': af, 'axis': [0, 1, 0], 'tip_y_mm': -25.55, 'socket_floor_y_mm': -25.4, 'stl': str(key_path.relative_to(ROOT))}
    (folder / 'proof-config.json').write_text(json.dumps(config, ensure_ascii=False, indent=2))
    print(folder / 'proof-config.json', flush=True)


def draw_spring_page(c, spec, config_directory, number=8):
    c.setLineCap(1)
    c.setLineJoin(1)
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(0.55)
    c.setFont('ManualV3Bold', 52)
    c.drawString(41, 756, '4')
    text(c, 111, 772, 'Fest fjøra', 16)
    c.rect(390, 710, 158, 80, stroke=1, fill=0)
    text(c, 402, 773, 'A', 11)
    if 'screw' in spec:
        svg(c, spec['screw'], (425, 733, 90, 40), config_directory)
    text(c, 402, 719, 'M3 × 12', 10)
    text(c, 535, 719, '2×', 17, 'right')
    context, anchors, _ = svg(c, spec['overview'], (252, 663, 128, 118), config_directory)
    if 'spring-left' in anchors and 'spring-right' in anchors:
        center = (np.asarray(anchors['spring-left']) + anchors['spring-right']) / 2
        c.setLineWidth(0.6)
        c.circle(*center, 10, stroke=1, fill=0)
    for label, y in [('1', 602), ('2', 327)]:
        c.setLineWidth(1)
        c.circle(65, y, 19, stroke=1, fill=0)
        text(c, 65, y - 8, label, 25, 'center')
    before, before_points, before_box = svg(c, spec['before'], (120, 377, 425, 245), config_directory)
    after, after_points, after_box = svg(c, spec['after'], (120, 102, 425, 245), config_directory)
    for x in (36, 54):
        start = project(before, [[x, -59, 71.4]], before_box)[0]
        end = project(before, [[x, -24, 71.4]], before_box)[0]
        line(c, [start, end], 0.5, True)
        arrow(c, [start + (end - start) * 0.35, end], 0.95)
        rotation(c, after, after_box, x, -32, 71.4)
    text(c, 47, 78, 'Skru inn. Stram varsamt.', 11)
    text(c, 47, 54, 'Detalj: huset er utelate.', 8.5)
    text(c, 29, 27, 'FORMNERD', 8)
    text(c, PAGE[0] / 2, 27, 'CAD R01  /  RETTLEIING M04', 7.5, 'center')
    text(c, PAGE[0] - 29, 27, f'{number:02d} / {PAGES}', 8, 'right')


def register_fonts():
    pdfmetrics.registerFont(TTFont('ManualV3', str(ROOT / 'source' / 'assets' / 'fonts' / 'DejaVuSans.ttf')))
    pdfmetrics.registerFont(TTFont('ManualV3Bold', str(ROOT / 'source' / 'assets' / 'fonts' / 'DejaVuSans-Bold.ttf')))


def proof(config_file):
    config_file = Path(config_file).resolve()
    spec = json.loads(config_file.read_text())
    for name in ('overview', 'before', 'after'):
        for key in ('svg', 'record'):
            if not (config_file.parent / spec[name][key]).is_file():
                raise FileNotFoundError(spec[name][key])
    register_fonts()
    REVIEW.mkdir(parents=True, exist_ok=True)
    output = REVIEW / 'Kamera-boge-M03-proof-fjor.pdf'
    c = canvas.Canvas(str(output), pagesize=PAGE, pageCompression=1)
    c.setTitle('Kamera med boge - M03 proof: fest fjøra')
    c.setAuthor('FormNerd')
    draw_spring_page(c, spec, config_file.parent)
    c.save()
    manifest = {'document_revision': 'M03', 'geometry_revision': 'R01', 'status': 'proof only; not production approved', 'page': 8, 'planned_page_count': 15, 'pdf': output.name, 'source_figures': spec}
    (REVIEW / 'proof-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    print(output, flush=True)


def asset(path, preserve=False):
    path = Path(path)
    return {'svg': str(path.with_suffix('.svg').relative_to(REVIEW)), 'record': str(path.with_suffix('.render.json').relative_to(REVIEW)), 'preserve_strokes': preserve}


def figure(c, name, box, folder='figures', preserve=False, missing=None):
    path = REVIEW / folder / name
    if not path.with_suffix('.svg').is_file():
        if missing is None:
            raise FileNotFoundError(path.with_suffix('.svg'))
        missing.append(str(path.with_suffix('.svg').relative_to(REVIEW)))
        x, y, w, h = box
        c.setLineWidth(.4)
        c.setDash(4, 4)
        c.rect(x, y, w, h, stroke=1, fill=0)
        c.setDash()
        text(c, x + w / 2, y + h / 2, f'Ventar på figur: {name}', 9, 'center')
        return None, {}, (x, y, w, h)
    return svg(c, asset(path, preserve), box, REVIEW)


def page(c, number, title, step=None):
    c.setLineCap(1)
    c.setLineJoin(1)
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(.55)
    if step is None:
        text(c, 47, 772, title, 20)
    else:
        c.setFont('ManualV3Bold', 52)
        c.drawString(41, 756, str(step))
        text(c, 111 if step < 10 else 133, 772, title, 16)
    text(c, 29, 27, 'FORMNERD', 8)
    text(c, PAGE[0] / 2, 27, 'CAD R01  /  RETTLEIING M04', 7.5, 'center')
    text(c, PAGE[0] - 29, 27, f'{number:02d} / {PAGES}', 8, 'right')


def badge(c, value, center, target=None, radius=13, size=10):
    c.setLineWidth(.6)
    c.setStrokeColorRGB(0, 0, 0)
    if target is not None:
        delta = np.asarray(target) - center
        length = np.linalg.norm(delta)
        if length > radius:
            start = np.asarray(center) + delta / length * radius
            line(c, [start, target], .55)
            c.setFillColorRGB(0, 0, 0)
            c.circle(*target, 1.5, stroke=0, fill=1)
    c.setFillColorRGB(1, 1, 1)
    c.circle(*center, radius, stroke=1, fill=1)
    text(c, center[0], center[1] - size * .34, value, size, 'center')


def needed(c, entries, missing):
    x, y, w, h = 390, 710, 158, 80
    c.setFillColorRGB(1, 1, 1)
    c.setLineWidth(.55)
    c.rect(x, y, w, h, stroke=1, fill=1)
    width = w / len(entries)
    for index, (name, code, quantity, label) in enumerate(entries):
        left = x + width * index
        if index:
            line(c, [[left, y], [left, y + h]], .4)
        text(c, left + 10, y + 63, code, 10)
        figure(c, name, (left + 26, y + 25, width - 35, 40), preserve=True, missing=missing)
        if label:
            text(c, left + 10, y + 9, label, 9)
        text(c, left + width - 10, y + 9, quantity, 15, 'right')


def locator(c, missing, contact=True, bare=False, focus='button'):
    if bare:
        record, anchors, placement = figure(c, 'inventory-P01', (252, 646, 128, 105), preserve=True, missing=missing)
        if record:
            center = project(record, [[48, 10, 90] if focus == 'button' else [45, -24, 71.4]], placement)[0]
            c.setLineWidth(.6)
            c.circle(*center, 8, stroke=1, fill=0)
        return record, anchors, placement
    spec = json.loads((REVIEW / 'proofs' / 'proof-config.json').read_text())['overview']
    record, anchors, placement = svg(c, spec, (252, 646, 128, 105), REVIEW / 'proofs')
    if contact:
        center = (np.asarray(anchors['spring-left']) + anchors['spring-right']) / 2
        c.setLineWidth(.6)
        c.circle(*center, 10, stroke=1, fill=0)
    return record, anchors, placement


def panel_numbers(c, values=(1, 2)):
    for label, y in zip(values, (602, 327)):
        badge(c, str(label), (65, y), radius=19, size=25)


def caption(c, values, y=78):
    for value in values:
        text(c, 47, y, value, 11)
        y -= 16


def model_arrow(c, record, placement, first, last, width=.95, dashed=True):
    if record is None:
        return
    points = project(record, [first, last], placement)
    if dashed:
        line(c, points, .5, True)
    arrow(c, [points[0] + (points[1] - points[0]) * .25, points[1]], width)


def contents_page(c, number, missing):
    names = {'P01': 'Framhus', 'P02': 'Bakdeksel', 'P03': 'Linseinnsats', 'P04': 'Utløysarknapp', 'P05': 'Prøvefjør'}
    page(c, number, 'Delar og verktøy')
    positions = [(47, 500, 237, 211), (311, 500, 237, 211), (47, 284, 149, 174), (223, 284, 149, 174), (399, 284, 149, 174)]
    for (code, label), box in zip(names.items(), positions):
        figure(c, f'inventory-{code}', box, missing=missing)
        badge(c, code, (box[0] + 18, box[1] - 7), radius=15)
        text(c, box[0] + 42, box[1] - 11, '1×', 13)
        text(c, box[0], box[1] - 33, label, 10)
    line(c, [[47, 222], [548, 222]], .5)
    for code, name, x, label, quantity in [('A', 'rear-screw', 47, 'M3 × 12', '6×'), ('B', 'nut', 230, 'M3-mutter', '4×'), ('C', 'lens-screw', 413, 'M2,5 × 8', '3×')]:
        figure(c, f'hardware-{name}', (x, 132, 135, 70), missing=missing)
        text(c, x, 207, code, 11)
        text(c, x, 116, label, 10)
        text(c, x + 135, 116, quantity, 13, 'right')
    caption(c, ['Verktøy: unbrakonøklar som passar dei faktiske skruane.'], 75)


def prep_page(c, number, missing):
    page(c, number, 'Prøv T01 først')
    record, anchors, _ = figure(c, 'coupon', (47, 386, 499, 330), missing=missing)
    if record:
        for code, pos, target in [('1', (86, 694), 'button'), ('2', (505, 694), 'nuts'), ('3', (505, 408), 'pilots')]:
            badge(c, code, pos, anchors[target])
    checks = [('1', 'Knappen skal gli i Ø16,4 utan å kile.'), ('2', 'M3-mutteren skal passe i AF5,9 utan sprekk.'), ('3', 'Prøv M2,5 i Ø2,0 og M3 i Ø2,5 med dei faktiske skruane.')]
    for i, (code, value) in enumerate(checks):
        badge(c, code, (60, 355 - 32 * i), radius=11)
        text(c, 82, 351 - 32 * i, value, 10)
    for y, values in [(236, ['Nominell maskinvare. Skruar, mutrar og verktøy er ikkje målte.', 'Gjenger er utelatne i illustrasjonane. Prøv passningane før hovudutskrift.']), (181, ['T01 og P04 ligg saman på prøveplata (side 3).', 'Prent henne først, så dei to andre platene.']), (126, ['Nominell knappereise: 1,2 mm. Fjørretur må prøvast fysisk.', 'R01 er slica for P1S, men ikkje fysisk prøvd.', 'M04 er eit arbeidsutkast. Funksjon og utskrift er ikkje produksjonsgodkjende.'])]:
        for line_index, value in enumerate(values):
            text(c, 47, y - 16 * line_index, value, 10)


def print_page(c, number, missing):
    page(c, number, 'Prent for P1S')
    boxes = [(47, 548, 237, 165), (311, 548, 237, 165), (47, 328, 237, 165)]
    for plate, box in zip(PRINT['plater'], boxes):
        record, anchors, placement = figure(c, plate['figur'], box, missing=missing)
        if record:
            for code, point in anchors.items():
                badge(c, code, (point[0] - 26, point[1] + 24), point, radius=11, size=8)
        text(c, box[0], box[1] - 13, plate['namn'], 10)
        text(c, box[0], box[1] - 27, f"{plate['tid']}  ·  {plate['vekt']}", 9)
    x, y, w, h = 311, 302, 237, 191
    c.setLineWidth(.55)
    c.rect(x, y, w, h, stroke=1, fill=0)
    text(c, x + 12, y + h - 22, 'Rekkjefølgje', 10)
    for i, value in enumerate(PRINT['rekkjefolgje']):
        badge(c, str(i + 1), (x + 22, y + h - 50 - 32 * i), radius=9, size=8)
        text(c, x + 38, y + h - 53 - 32 * i, value, 8.5)
    line(c, [[47, 282], [548, 282]], .5)
    y = 264
    for value in PRINT['innstillingar']:
        text(c, 47, y, value, 9.5)
        y -= 14
    y -= 8
    for value in PRINT['stotte']:
        text(c, 47, y, value, 9.5)
        y -= 14
    text(c, 47, 60, PRINT['merknad'], 8.5)


def build_booklet(selected=None, allow_missing=False):
    register_fonts()
    REVIEW.mkdir(parents=True, exist_ok=True)
    target = REVIEW / 'qa-drafts' if selected else REVIEW
    target.mkdir(parents=True, exist_ok=True)
    tag = '-'.join(f'{p:02d}' for p in sorted(selected)) if selected else ''
    name = ('Kamera-boge-M04-layout' + ('-' + tag if selected else '') + '.pdf') if allow_missing else ('Kamera-boge-M04-leseprove-' + tag + '.pdf' if selected else 'Kamera-boge-M04.pdf')
    output = target / name
    c = canvas.Canvas(str(output), pagesize=PAGE, pageCompression=1)
    c.setTitle('Kamera med boge - Monteringsrettleiing M04')
    c.setAuthor('FormNerd')
    missing = [] if allow_missing else None
    proof_config = REVIEW / 'proofs' / 'proof-config.json'
    for number in range(1, PAGES + 1):
        if selected and number not in selected:
            continue
        old = number if number < 3 else number - 1
        if number == 1:
            page(c, 1, 'Kamera med boge')
            text(c, 47, 742, 'Monteringsrettleiing', 13)
            figure(c, 'cover', (47, 179, 499, 505), missing=missing)
            text(c, 47, 119, 'CAD R01  /  RETTLEIING M04', 11)
            text(c, 47, 94, 'Mekanisk prøvebygg', 11)
        elif number == 2:
            contents_page(c, number, missing)
        elif number == 3:
            print_page(c, number, missing)
        elif number == 4:
            prep_page(c, number, missing)
        elif number == 5:
            page(c, 5, 'Monteringsoversikt')
            record, anchors, box = figure(c, 'exploded', (42, 159, 511, 542), missing=missing)
            if record:
                positions = {'P01': (263, 610), 'P02': (478, 219), 'P03': (77, 575), 'P05': (497, 610)}
                for code, center in positions.items():
                    badge(c, code, center, anchors[code], radius=15)
            c.setLineWidth(.55)
            c.rect(378, 652, 170, 103, stroke=1, fill=0)
            badge(c, 'P04', (396, 738), radius=14, size=9)
            text(c, 418, 735, 'steg 1 og 2', 10)
            figure(c, 'inventory-P04', (480, 673, 57, 52), preserve=True, missing=missing)
            arrow(c, [[394, 683], [449, 683], [449, 718]], .95)
            text(c, 389, 662, 'Bakfrå, så opp.', 8.5)
            caption(c, ['P04 går inn lågt frå baksida, så opp.', 'Monter knappen og fjøra før bakdekselet.'], 118)
        elif old in (5, 6):
            page(c, number, 'Før inn knappen' if old == 5 else 'Løft knappen', old - 4)
            needed(c, [('inventory-P04', 'P04', '1×', '')], missing)
            locator(c, missing, bare=True)
            panel_numbers(c)
            names = ('button-start', 'button-middle') if old == 5 else ('button-middle', 'button-final')
            placements = []
            for name, box in zip(names, [(120, 377, 425, 245), (120, 102, 425, 245)]):
                placements.append(figure(c, name, box, folder='details', missing=missing))
            first = [48, -45, 42.5] if old == 5 else [48, 10, 42.5]
            last = [48, 10, 42.5] if old == 5 else [48, 10, 88.5]
            model_arrow(c, placements[0][0], placements[0][2], first, last)
            caption(c, ['Før P04 rett inn frå den opne baksida.'] if old == 5 else ['Løft P04 til han går gjennom toppholet.'])
            text(c, 47, 54, 'Teknisk utsnitt av huset. Same kamera og skala i begge bileta.', 8.5)
        elif old == 7:
            page(c, number, 'Før inn fjøra', 3)
            needed(c, [('inventory-P05', 'P05', '1×', '')], missing)
            locator(c, missing, bare=True, focus='spring')
            panel_numbers(c)
            first, _, box = figure(c, 'spring-insert-before', (120, 377, 425, 245), missing=missing)
            figure(c, 'spring-insert-after', (120, 102, 425, 245), missing=missing)
            model_arrow(c, first, box, [52, -16, 73.4], [52, 10, 73.4])
            caption(c, ['Skyv P05 under knappefoten.'])
            text(c, 47, 54, 'Detalj: huset er utelate.', 8.5)
        elif old == 8:
            spec = json.loads(proof_config.read_text())
            draw_spring_page(c, spec, proof_config.parent, number)
        elif old == 9:
            page(c, number, 'Prøv ope', 5)
            locator(c, missing, bare=True, focus='spring')
            record, anchors, box = figure(c, 'spring-contact', (120, 200, 425, 421), folder='details', missing=missing)
            if record:
                points = project(record, [[48, 10, 105], [48, 10, 101]], box)
                delta = np.array([-42., 0.])
                arrow(c, points + delta, 1.15)
                arrow(c, (points + np.array([42., 0.]))[::-1], 1.15)
                text(c, points[0][0] - 62, points[0][1] + 9, '1 Trykk', 10, 'center')
                text(c, points[0][0] + 62, points[0][1] + 9, '2 Slepp', 10, 'center')
            caption(c, ['Knappen skal gå lett og kome tilbake.', 'Stopp om han bind.'], 132)
            text(c, 47, 60, 'Detalj: huset er utelate.', 8.5)
        elif old == 10:
            page(c, number, 'Før inn linseinnsatsen', 6)
            needed(c, [('inventory-P03', 'P03', '1×', '')], missing)
            record, anchors, box = figure(c, 'lens-insert', (43, 192, 510, 478), missing=missing)
            model_arrow(c, record, box, [-38, 69, 41.5], [-38, 40, 41.5])
            caption(c, ['Snu huset. Før P03 rett inn frå framsida.'], 119)
        elif old == 11:
            page(c, number, 'Fest linseinnsatsen', 7)
            needed(c, [('hardware-lens-screw', 'C', '3×', 'M2,5 × 8')], missing)
            figure(c, 'cover', (252, 646, 128, 105), preserve=True, missing=missing)
            panel_numbers(c)
            first, _, before_box = figure(c, 'lens-fasten-before', (120, 377, 425, 245), missing=missing)
            after, _, after_box = figure(c, 'lens-fasten-after', (120, 102, 425, 245), missing=missing)
            if first:
                for a in (90, 210, 330):
                    x, z = -38 + 22 * np.cos(np.radians(a)), 41.5 + 22 * np.sin(np.radians(a))
                    model_arrow(c, first, before_box, [x, 61.5, z], [x, 40.5, z])
                    angles = np.linspace(-.6, 4.1, 45)
                    arrow(c, project(after, [[x + 5 * np.cos(a), 47, z + 5 * np.sin(a)] for a in angles], after_box), .9)
            caption(c, ['Fest tre skruar. Stram varsamt.'])
            text(c, 47, 54, 'Detalj: huset er utelate.', 8.5)
        elif old == 12:
            page(c, number, 'Set inn mutrane', 8)
            needed(c, [('hardware-nut', 'B', '4×', 'M3')], missing)
            record, anchors, box = figure(c, 'nuts-insert', (43, 173, 510, 496), missing=missing)
            if record:
                for x, z in [(-48, 18), (48, 18), (-48, 62), (48, 62)]:
                    model_arrow(c, record, box, [x, -41.2, z], [x, -27.2, z])
            caption(c, ['Trykk fire mutrar inn i dei sekskanta lommene.'], 119)
        elif old == 13:
            page(c, number, 'Set på bakdekselet', 9)
            needed(c, [('inventory-P02', 'P02', '1×', '')], missing)
            record, anchors, box = figure(c, 'lid-insert', (43, 347, 510, 323), missing=missing)
            model_arrow(c, record, box, [0, -72, 42], [0, -37, 42])
            detail, detail_anchors, detail_box = figure(c, 'pin-before', (47, 136, 237, 186), folder='details', preserve=True, missing=missing)
            figure(c, 'pin-after', (311, 136, 237, 186), folder='details', preserve=True, missing=missing)
            badge(c, '1', (60, 320), radius=12, size=12)
            badge(c, '2', (324, 320), radius=12, size=12)
            text(c, 548, 320, '2×', 15, 'right')
            if detail and 'axis-start' in detail_anchors and 'axis-end' in detail_anchors:
                arrow(c, [detail_anchors['axis-start'], detail_anchors['axis-end']], .95)
            if record and detail:
                for name in ('hole1', 'hole2'):
                    if name in anchors:
                        badge(c, '', (anchors[name][0] - 28, anchors[name][1] - 18), anchors[name], radius=7)
            caption(c, ['Rett begge hola inn på styrepinnane.', 'Skyv dekselet rett på.'], 101)
        elif old == 14:
            page(c, number, 'Fest bakdekselet', 10)
            needed(c, [('hardware-rear-screw', 'A', '4×', 'M3 × 12')], missing)
            record, anchors, box = figure(c, 'lid-fasten', (43, 302, 510, 373), missing=missing)
            if record:
                for index, x, z in [(1, -48, 18), (2, 48, 62), (3, -48, 62), (4, 48, 18)]:
                    point = project(record, [[x, -70.7, z]], box)[0]
                    badge(c, str(index), point + [-18, 22], radius=10, size=9)
                    model_arrow(c, record, box, [x, -55.6, z], [x, -37.6, z])
                    rotation(c, record, box, x, -73, z)
            figure(c, 'finished-rear', (270, 111, 242, 175), missing=missing)
            caption(c, ['Set inn alle fire. Stram varsamt i rekkjefølgja 1 til 4.'], 86)
        elif old == 15:
            page(c, number, 'Sluttprøve og opning')
            figure(c, 'cover', (112, 356, 371, 350), missing=missing)
            for index, value in enumerate(['Knappen glir og kjem tilbake når du slepper.', 'Fjøra ligg under knappefoten.', 'Linseinnsatsen og bakdekselet sit jamt.', 'Opning: løys dei fire bakskruane og trekk dekselet rett av.']):
                y = 297 - index * 36
                c.setLineWidth(.7)
                c.rect(47, y - 2, 10, 10, stroke=1, fill=0)
                text(c, 69, y - 1, value, 10)
            text(c, 47, 152, 'Feilsøking', 11)
            for index, value in enumerate(['Knappen bind: fjern støtterestar i Ø16,4-holet og slip stammen lett.', 'Dekselet sit ikkje: kontroller at mutrane ligg i botnen av lommene og at styrepinnane er reine.', 'Støtte sit fast i holrommet: trekk ut gjennom bakopninga med tang. Ikkje bøy fjøra.', 'Linseinnsatsen kilar: avgrad kanten av Ø38-holet før ny prøve.']):
                text(c, 47, 132 - index * 14, value, 9.5)
            text(c, 47, 62, 'Mekanisk prøvebygg. Prøv med faktisk utskrift og maskinvare. M04 er eit arbeidsutkast før fysisk kontroll.', 9)
        c.showPage()
    c.save()
    manifest = {'document_revision': 'M04', 'geometry_revision': 'R01', 'status': 'layout draft with pending assets' if missing else 'working assembly manual; physical verification pending', 'pages': sorted(selected) if selected else list(range(1, PAGES + 1)), 'missing_assets': sorted(set(missing or [])), 'pdf': str(output.relative_to(REVIEW))}
    (target / 'layout-manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    print(output, flush=True)
    return output


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default=str(REVIEW / 'proofs' / 'proof-config.json'))
    parser.add_argument('--build-assets', action='store_true')
    parser.add_argument('--assets-only', action='store_true')
    parser.add_argument('--booklet', action='store_true')
    parser.add_argument('--layout-only', action='store_true')
    parser.add_argument('--allow-missing', action='store_true')
    parser.add_argument('--pages', type=int, nargs='*')
    args = parser.parse_args()
    if args.build_assets:
        make_assets()
    if not args.assets_only:
        if args.booklet or args.layout_only:
            build_booklet(set(args.pages) if args.pages else None, args.allow_missing)
        else:
            proof(args.config)
