"""Add image-space feature lines for organic parts (P01, P02) to a vector figure made by vector_illustration.py.

Usage: python source/organic_figure.py source/scenes-v3/<scene>.json review/manual-v3/figures/<name> [--supersample 2]

The vector figure (SVG + render.json) must already exist. The same parts are rendered with three.js at the same
orthographic camera (target, direction, up, scale) to id/depth/normal buffers. From those buffers two kinds of
lines are extracted for the organic parts only, vectorised and appended to the SVG as thin detail strokes:
  contour - occluding contours inside a part (depth discontinuities not explained by the surface slope)
  valley  - concave ridges of the depth field (valleys between the tubes)
Lines are measured against the buffers, never drawn by hand. Geometry is not modified.
"""
import argparse, hashlib, json, os, subprocess, sys, tempfile
from pathlib import Path
from xml.sax.saxutils import escape

import numpy as np
import trimesh
from PIL import Image
from scipy import ndimage as ndi
from skimage.morphology import skeletonize

ROOT = Path(__file__).resolve().parents[1]
HERE = Path(__file__).resolve().parent
THREE = os.environ.get('THREE_DIR', '/home/claude/formnerd/verktoy/node_modules/three')
ORGANIC = ('P01', 'P02')
DEFAULT = {'contour_jump_mm': 0.8, 'valley_sigma_mm': 1.8, 'valley_high': 0.14, 'valley_low': 0.06,
           'min_len_mm': 8.0, 'valley_min_len_mm': 12.0, 'valley_edge_clear_mm': 1.2, 'valley_contour_clear_mm': 2.0, 'valley_min_nz': 0.25, 'smooth_sigma_mm': 0.5, 'simplify_mm': 0.08}


def part_path(part):
    p = Path(part['file'])
    return p if p.is_absolute() else ROOT / p


def render_buffers(scene, record, supersample, folder):
    W, H = record['size']
    S = int(max(W, H) * supersample)
    cam = record['camera']
    r = (S / supersample / H) * cam['scale'] / 2
    objekt = []
    for i, part in enumerate(scene['parts']):
        src = part_path(part)
        display = src.with_name(src.stem + '-display.stl')
        m = trimesh.load(display if display.is_file() else src, force='mesh', process=False)
        if part.get('matrix'):
            m.apply_transform(np.asarray(part['matrix'], float).reshape(4, 4))
        if part.get('translate'):
            m.apply_translation(part['translate'])
        glb = folder / f'part_{i:02d}.glb'
        m.export(glb)
        objekt.append({'fil': str(glb), 'farge': '#c8cac8'})
    sc = {'storleik': S, 'retning': cam['direction'], 'opp': cam['up'], 'senter': cam['target'], 'radius': r, 'objekt': objekt}
    sf = folder / 'scene.json'
    sf.write_text(json.dumps(sc))
    subprocess.run(['node', str(HERE / 'strek_chrome.mjs'), str(sf), str(folder)], check=True, env={**os.environ, 'THREE_DIR': THREE})
    ids = np.asarray(Image.open(folder / 'id.png').convert('RGBA'))[..., 0].astype(int)
    dj = np.asarray(Image.open(folder / 'djupn.png').convert('RGBA')).astype(np.float64)
    t = dj[..., 0] / 255 + dj[..., 1] / 255 / 255
    depth = r + t * (7 * r - r)
    nrm = np.asarray(Image.open(folder / 'normal.png').convert('RGBA')).astype(np.float64)[..., :3] / 127.5 - 1
    nrm /= np.linalg.norm(nrm, axis=-1, keepdims=True) + 1e-9
    mm_per_px = 2 * r / S
    return ids, depth, nrm, mm_per_px, S


def nonmax_ridge(strength, ex, ey):
    h, w = strength.shape
    yy, xx = np.mgrid[0:h, 0:w]
    s1 = ndi.map_coordinates(strength, [yy + ey, xx + ex], order=1, mode='nearest')
    s2 = ndi.map_coordinates(strength, [yy - ey, xx - ex], order=1, mode='nearest')
    return (strength >= s1) & (strength >= s2)


def hysteresis(strong, weak):
    lab, n = ndi.label(weak, np.ones((3, 3), bool))
    keep = np.zeros(n + 1, bool)
    keep[np.unique(lab[strong])] = True
    keep[0] = False
    return keep[lab]


def clean(mask, min_px):
    lab, n = ndi.label(mask, np.ones((3, 3), bool))
    sizes = np.bincount(lab.ravel())
    keep = sizes >= min_px
    keep[0] = False
    return keep[lab]


def extract(ids, depth, nrm, mm_per_px, organic_ids, cfg):
    fg = ids > 0
    outline = np.zeros(fg.shape, bool)
    for ax in (0, 1):
        for s in (1, -1):
            outline |= ids != np.roll(ids, s, ax)
    outline &= fg
    nz = np.clip(np.abs(nrm[..., 2]), 0.05, 1)
    slope = np.sqrt(np.maximum(1 - nz ** 2, 0)) / nz * mm_per_px
    contour = np.zeros(fg.shape, bool)
    for ax in (0, 1):
        for s in (1, -1):
            dz = np.roll(depth, s, ax) - depth
            same = (ids == np.roll(ids, s, ax)) & fg
            contour |= same & (dz - np.maximum(slope, np.roll(slope, s, ax)) * 1.5 > cfg['contour_jump_mm'])
    contour &= np.isin(ids, organic_ids)
    contour = ndi.binary_closing(contour, np.ones((3, 3), bool))
    sig = cfg['valley_sigma_mm'] / mm_per_px
    w = ndi.gaussian_filter(fg.astype(float), sig)
    ds = ndi.gaussian_filter(np.where(fg, depth, 0), sig) / np.maximum(w, 1e-6)
    dxx = ndi.gaussian_filter(ds, sig, order=(0, 2))
    dyy = ndi.gaussian_filter(ds, sig, order=(2, 0))
    dxy = ndi.gaussian_filter(ds, sig, order=(1, 1))
    tr, det = dxx + dyy, dxx * dyy - dxy ** 2
    disc = np.sqrt(np.maximum((tr / 2) ** 2 - det, 0))
    lam_min = tr / 2 - disc
    ex, ey = dxy, lam_min - dxx
    nv = np.hypot(ex, ey) + 1e-12
    ex, ey = ex / nv, ey / nv
    strength = -lam_min / (mm_per_px ** 2)
    clear = int(round(cfg['valley_edge_clear_mm'] / mm_per_px))
    clear_c = int(round(cfg.get('valley_contour_clear_mm', 1.6) / mm_per_px))
    near_edge = ndi.binary_dilation(outline | ~fg, iterations=max(1, clear)) | ndi.binary_dilation(contour, iterations=max(1, clear_c))
    cand = fg & (nz >= cfg['valley_min_nz']) & ~near_edge & np.isin(ids, organic_ids)
    nm = nonmax_ridge(strength, ex, ey)
    valley = hysteresis(cand & nm & (strength > cfg['valley_high']), cand & nm & (strength > cfg['valley_low']))
    valley = ndi.binary_closing(valley, np.ones((3, 3), bool)) & ~near_edge
    min_px = int(cfg['min_len_mm'] / mm_per_px)
    return clean(contour, min_px), clean(valley, int(cfg.get('valley_min_len_mm', cfg['min_len_mm']) / mm_per_px))


def chains(mask):
    """Trace a skeleton into polylines (lists of (y, x))."""
    sk = skeletonize(mask)
    yy, xx = np.nonzero(sk)
    nodes = set(zip(yy.tolist(), xx.tolist()))
    adj = {}
    for y, x in nodes:
        nb = []
        for dy, dx in ((-1, 0), (0, 1), (1, 0), (0, -1), (-1, -1), (-1, 1), (1, 1), (1, -1)):
            p = (y + dy, x + dx)
            if p in nodes and not (dy and dx and ((y + dy, x) in nodes or (y, x + dx) in nodes)):
                nb.append(p)
        adj[(y, x)] = nb
    visited, paths = set(), []
    ends = [p for p in nodes if len(adj[p]) != 2]
    for start in ends + list(nodes):
        for nxt in adj[start]:
            edge = tuple(sorted((start, nxt)))
            if edge in visited:
                continue
            visited.add(edge)
            path = [start, nxt]
            while len(adj[nxt]) == 2 and nxt != start:
                choices = [p for p in adj[nxt] if p != path[-2]]
                if not choices:
                    break
                after = choices[0]
                edge = tuple(sorted((nxt, after)))
                if edge in visited:
                    break
                visited.add(edge)
                path.append(after)
                nxt = after
            paths.append(np.asarray(path, float))
    return paths


def simplify(points, tolerance):
    keep = {0, len(points) - 1}
    stack = [(0, len(points) - 1)]
    while stack:
        a, b = stack.pop()
        if b <= a + 1:
            continue
        delta = points[b] - points[a]
        factor = np.clip((points[a + 1:b] - points[a]) @ delta / max(np.dot(delta, delta), 1e-20), 0, 1)
        distance = np.linalg.norm(points[a + 1:b] - points[a] - factor[:, None] * delta, axis=1)
        i = int(np.argmax(distance))
        if distance[i] > tolerance:
            pivot = a + i + 1
            keep.add(pivot)
            stack.extend(((a, pivot), (pivot, b)))
    return points[sorted(keep)]


def vectorise(mask, mm_per_px, cfg, min_mm):
    out = []
    for p in chains(mask):
        length = np.linalg.norm(np.diff(p, axis=0), axis=1).sum() * mm_per_px
        if length < min_mm:
            continue
        closed = np.linalg.norm(p[0] - p[-1]) < 2
        q = ndi.gaussian_filter1d(p, cfg['smooth_sigma_mm'] / mm_per_px, axis=0, mode='wrap' if closed else 'nearest')
        if not closed:
            q += np.linspace(1, 0, len(p))[:, None] * (p[0] - q[0])
            q += np.linspace(0, 1, len(p))[:, None] * (p[-1] - q[-1])
        out.append(simplify(q, cfg['simplify_mm'] / mm_per_px))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('scene')
    ap.add_argument('output')
    ap.add_argument('--supersample', type=int, default=2)
    ap.add_argument('--config', default=None)
    args = ap.parse_args()
    scene = json.loads(Path(args.scene).read_text())
    cfg = {**DEFAULT, **(scene.get('organic_lines') or {}), **(json.loads(Path(args.config).read_text()) if args.config else {})}
    output = Path(args.output)
    svg_path, rec_path = output.with_suffix('.svg'), output.with_suffix('.render.json')
    record = json.loads(rec_path.read_text())
    W, H = record['size']
    organic_ids = [i + 1 for i, part in enumerate(scene['parts']) if part_path(part).stem in ORGANIC]
    if not organic_ids:
        print('no organic parts; nothing added')
        return
    with tempfile.TemporaryDirectory() as tmp:
        ids, depth, nrm, mm_per_px, S = render_buffers(scene, record, args.supersample, Path(tmp))
    contour, valley = extract(ids, depth, nrm, mm_per_px, organic_ids, cfg)
    ss = args.supersample
    def to_figure(poly):
        yx = poly / ss
        return np.column_stack((yx[:, 1] - S / ss / 2 + W / 2, yx[:, 0] - S / ss / 2 + H / 2))
    figure_width = float(scene.get('figure_width_pt', 499))
    detail = float(scene.get('organic_width_pt', scene.get('detail_width_pt', .4))) * W / figure_width
    import re
    svg = svg_path.read_text()
    svg = re.sub(r'\n<path data-part="organic"[^\n]*', '', svg)
    svg = svg.replace('\n</g>\n</svg>', '')
    added = {'organic-contour': 0, 'organic-valley': 0}
    paths = []
    for kind, mask in (('organic-contour', contour), ('organic-valley', valley)):
        for poly in vectorise(mask, mm_per_px, cfg, cfg['min_len_mm'] if kind == 'organic-contour' else cfg.get('valley_min_len_mm', cfg['min_len_mm'])):
            pts = to_figure(poly)
            data = 'M ' + ' L '.join(f'{x:.3f},{y:.3f}' for x, y in pts)
            paths.append(f'<path data-part="organic" data-kind="{kind}" stroke-width="{detail:.4f}" d="{data}"/>')
            added[kind] += 1
    svg = svg + '\n' + '\n'.join(paths) + '\n</g>\n</svg>'
    svg_path.write_text(svg)
    record['organic_lines'] = {'method': 'three.js id/depth/normal buffers at the same orthographic camera; occluding contours = depth jumps not explained by surface slope; valleys = Hessian ridges of the smoothed depth field; skeletonised, Gaussian smoothed and simplified',
                               'supersample': ss, 'buffer_px': S, 'mm_per_px': mm_per_px, 'config': cfg, 'paths': added, 'geometry_modified': False,
                               'organic_parts': [part_path(p).stem for p in scene['parts'] if part_path(p).stem in ORGANIC]}
    record['normal_ridges'] = True
    rec_path.write_text(json.dumps(record, indent=2))
    print(json.dumps(added))


if __name__ == '__main__':
    main()
