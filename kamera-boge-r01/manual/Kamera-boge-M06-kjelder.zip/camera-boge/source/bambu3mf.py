import re, zipfile, numpy as np
from lxml import etree

NS = '{http://schemas.microsoft.com/3dmanufacturing/core/2015/02}'


def _mat(text):
    m = np.asarray([float(x) for x in text.split()], np.float64).reshape(4, 3)
    return m


def _mesh_from_file(z, path, want_id):
    with z.open(path.lstrip('/')) as f:
        verts, faces, cur = [], [], None
        for ev, el in etree.iterparse(f, events=('start', 'end')):
            if ev == 'start' and el.tag == NS + 'object':
                cur = el.get('id'); verts, faces = [], []
                continue
            if ev != 'end':
                continue
            if el.tag == NS + 'vertex':
                verts.append((float(el.get('x')), float(el.get('y')), float(el.get('z'))))
            elif el.tag == NS + 'triangle':
                faces.append((int(el.get('v1')), int(el.get('v2')), int(el.get('v3'))))
            elif el.tag == NS + 'object':
                if cur == want_id:
                    return np.asarray(verts), np.asarray(faces)
            if el.tag in (NS + 'vertex', NS + 'triangle'):
                el.clear()
                while el.getprevious() is not None:
                    del el.getparent()[0]
    raise KeyError(want_id)


def placed_meshes(path):
    """Return [(name, vertices_on_plate, faces)] from a Bambu Studio 3MF (project or .gcode.3mf)."""
    z = zipfile.ZipFile(path)
    root = etree.fromstring(z.read('3D/3dmodel.model'))
    names = {}
    try:
        ms = etree.fromstring(z.read('Metadata/model_settings.config'))
        for o in ms.findall('object'):
            n = [m.get('value') for m in o.findall('metadata') if m.get('key') == 'name']
            names[o.get('id')] = n[0] if n else o.get('id')
    except KeyError:
        pass
    objects = {o.get('id'): o for o in root.iter(NS + 'object')}
    out = []
    for item in root.iter(NS + 'item'):
        oid = item.get('objectid')
        T = _mat(item.get('transform')) if item.get('transform') else np.vstack([np.eye(3), np.zeros(3)])
        obj = objects[oid]
        comps = list(obj.iter(NS + 'component'))
        parts = []
        if comps:
            for c in comps:
                p = c.get('{http://schemas.microsoft.com/3dmanufacturing/production/2015/06}path') or c.get('path')
                C = _mat(c.get('transform')) if c.get('transform') else np.vstack([np.eye(3), np.zeros(3)])
                v, f = _mesh_from_file(z, p, c.get('objectid'))
                v = v @ C[:3] + C[3]
                parts.append((v, f))
        else:
            v, f = _mesh_from_file(z, '3D/3dmodel.model', oid)
            parts.append((v, f))
        vs, fs, off = [], [], 0
        for v, f in parts:
            vs.append(v); fs.append(f + off); off += len(v)
        v = np.vstack(vs) @ T[:3] + T[3]
        out.append((names.get(oid, oid), v, np.vstack(fs)))
    return out


if __name__ == '__main__':
    import sys
    for name, v, f in placed_meshes(sys.argv[1]):
        print(name, len(f), np.round(v.min(0), 2), np.round(v.max(0), 2))
