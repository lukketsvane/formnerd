import argparse
import hashlib
import json
import shutil
from pathlib import Path

import manifold3d as mf
import numpy as np
import trimesh
from PIL import Image, ImageDraw

from vector_illustration import illustrate

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'review' / 'manual-v3' / 'details'
FIXTURES = ROOT / 'review' / 'manual-v3' / 'fixtures' / 'sections'


def section(name, part, bounds):
    source = ROOT / 'cad' / f'{part}.stl'
    target = FIXTURES / name / f'{part}.stl'
    record = target.with_suffix('.section.json')
    spec = {'source': str(source.relative_to(ROOT)), 'sha256': hashlib.sha256(source.read_bytes()).hexdigest(), 'bounds_mm': bounds, 'status': 'illustration section only; source CAD unchanged'}
    if target.exists() and record.exists() and json.loads(record.read_text()) == spec:
        return str(target.relative_to(ROOT))
    shape = trimesh.load(source, process=True)
    body = mf.Manifold(mf.Mesh(np.asarray(shape.vertices, np.float32), np.asarray(shape.faces, np.uint32)))
    if str(body.status()) != 'Error.NoError':
        raise ValueError(body.status())
    for axis in range(3):
        for side in (0, 1):
            value = bounds[side][axis]
            if value is None:
                continue
            normal = np.zeros(3)
            normal[axis] = 1 if side == 0 else -1
            body = body.trim_by_plane(normal, value if side == 0 else -value)
    mesh = body.to_mesh()
    target.parent.mkdir(parents=True, exist_ok=True)
    trimesh.Trimesh(np.asarray(mesh.vert_properties)[:, :3], np.asarray(mesh.tri_verts), process=True).export(target)
    record.write_text(json.dumps(spec, indent=2))
    print('section', target, body.num_tri(), flush=True)
    return str(target.relative_to(ROOT))


def scene(parts, direction, target, scale, size, width, anchors):
    return {'parts': parts, 'camera': {'direction': direction, 'up': [0, 0, 1], 'target': target, 'scale': scale}, 'size': size, 'figure_width_pt': width, 'outer_width_pt': .8, 'detail_width_pt': .4, 'simplify_tolerance_pt': .08, 'projection_sampling': 2, 'anchors': anchors}


def section_hatch(output, spec):
    record_path = output.with_suffix('.render.json')
    record = json.loads(record_path.read_text())
    if record.get('section_hatch'):
        return
    shape = trimesh.load(ROOT / spec['parts'][0]['file'], process=False)
    triangles = shape.vertices[shape.faces]
    triangles = triangles[np.all(np.abs(triangles[:, :, 0] - 48) < 1e-4, axis=1)]
    values = triangles[:, :, 2] - triangles[:, :, 1]
    bands = np.arange(np.floor(values.min() / 3) * 3, values.max(), 3)
    segments = []
    for band in bands:
        intervals = []
        for tri, vals in zip(triangles, values):
            if band < vals.min() or band > vals.max():
                continue
            intersections = []
            for i, j in [(0, 1), (1, 2), (2, 0)]:
                if abs(vals[i] - vals[j]) < 1e-9:
                    continue
                t = (band - vals[i]) / (vals[j] - vals[i])
                if -1e-8 <= t <= 1 + 1e-8:
                    intersections.append(tri[i, 1] + t * (tri[j, 1] - tri[i, 1]))
            if len(intersections) >= 2:
                intervals.append([min(intersections), max(intersections)])
        merged = []
        for a, b in sorted(intervals):
            if merged and a <= merged[-1][1] + 1e-4:
                merged[-1][1] = max(merged[-1][1], b)
            else:
                merged.append([a, b])
        segments.extend(np.array([[48, a, a + band], [48, b, b + band]]) for a, b in merged if b - a > .1)
    cam = record['camera']
    direction = np.asarray(cam['direction'], float)
    direction /= np.linalg.norm(direction)
    right = np.cross(cam['up'], direction)
    right /= np.linalg.norm(right)
    up = np.cross(direction, right)
    width, height = record['size']
    def project(points):
        p = (points - cam['target']) @ np.stack((right, up, direction)).T
        return np.column_stack((width / 2 + p[:, 0] * height / cam['scale'], height / 2 - p[:, 1] * height / cam['scale']))
    projected = [project(segment) for segment in segments]
    weight = .35 * width / spec['figure_width_pt']
    group = ['<g id="section-hatch" fill="none" stroke="#111" stroke-width="%.4f">' % weight]
    for p in projected:
        group.append('<path d="M %.4f,%.4f L %.4f,%.4f"/>' % tuple(p.ravel()))
    group.append('</g>')
    svg_path = output.with_suffix('.svg')
    svg_path.write_text(svg_path.read_text().replace('</svg>', '\n'.join(group) + '\n</svg>'))
    image = Image.open(output.with_suffix('.png')).convert('RGB').resize((width * 4, height * 4), Image.Resampling.LANCZOS)
    draw = ImageDraw.Draw(image)
    for p in projected:
        draw.line([tuple(v * 4) for v in p], fill='#111', width=max(1, round(weight * 4)))
    image.resize((width, height), Image.Resampling.LANCZOS).save(output.with_suffix('.png'))
    record['section_hatch'] = {'plane_x_mm': 48, 'spacing_mm': 3, 'width_pt': .35, 'segments': len(segments), 'derivation': 'intersection of diagonal lines with actual planar cut triangles; diagram overlay excluded from model-contour error measurement'}
    record['illustration_section'] = spec.get('illustration_section')
    record_path.write_text(json.dumps(record, indent=2))


def all_scenes():
    housing = section('button', 'P01', [[42, None, None], [48, None, None]])
    out = {}
    for name, offset in [('button-start', [0, -55, -46]), ('button-middle', [0, 0, -46]), ('button-final', [0, 0, 0])]:
        out[name] = scene([{'file': housing}, {'file': 'cad/P04.stl', 'translate': offset}], [1, 0, 0], [48, -13, 55], 116, [1200, 1120], 425, {'button-center': [48, 10 + offset[1], 88.5 + offset[2]], 'foot': [48, 10 + offset[1], 75.2 + offset[2]], 'insert-start': [48, -45, 42.5], 'insert-end': [48, 10, 42.5], 'lift-end': [48, 10, 88.5]})
        out[name]['illustration_section'] = {'part': 'P01', 'bounds': [[42, None, None], [48, None, None]], 'source_geometry_unchanged': True}
    out['spring-contact'] = scene([{'file': 'cad/P04.stl'}, {'file': 'cad/P05.stl'}], [1, -.2, .15], [48, 6, 85], 37, [1000, 1000], 250, {'contact': [48, 10, 74.4], 'press': [48, 10, 101], 'press-end': [48, 10, 99.8], 'spring-tip': [48, 13, 74.4]})
    front = section('pin', 'P01', [[-26, -38, 6], [-14, -21, 19]])
    back = section('pin', 'P02', [[-26, None, 6], [-14, None, 19]])
    pin_front = str(Path(front).with_name('P01-pin.stl'))
    pin_back = str(Path(back).with_name('P02-pin.stl'))
    for source, target in [(front, pin_front), (back, pin_back)]:
        shutil.copyfile(ROOT / source, ROOT / target)
    front, back = pin_front, pin_back
    for name, distance in [('pin-before', -35), ('pin-after', 0)]:
        out[name] = scene([{'file': front}, {'file': back, 'translate': [0, distance, 0]}], [1, -1, .7], [-20, -49, 13], 45, [1300, 800], 425, {'pin-tip': [-20, -34.6, 12], 'pin-root': [-20, -29.6, 12], 'hole-near': [-20, -32 + distance, 12], 'hole-back': [-20, -42 + distance, 12], 'axis-start': [-20, -67, 12], 'axis-end': [-20, -32, 12]})
        out[name]['illustration_section'] = {'parts': ['P01', 'P02'], 'status': 'local actual CAD crop; source geometry unchanged'}
    return out


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--only', nargs='*')
    parser.add_argument('--force', action='store_true')
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    manifest = {}
    for name, spec in all_scenes().items():
        if args.only and name not in args.only:
            continue
        output = OUT / name
        path = output.with_suffix('.scene.json')
        payload = json.dumps(spec, ensure_ascii=False, indent=2)
        changed = not path.exists() or path.read_text() != payload
        path.write_text(payload)
        if args.force or changed or not output.with_suffix('.svg').exists():
            print('render', name, flush=True)
            illustrate(spec, output)
        if name.startswith('button-'):
            section_hatch(output, spec)
        record_path = output.with_suffix('.render.json')
        record = json.loads(record_path.read_text())
        record['illustration_section'] = spec.get('illustration_section')
        record['illustration_notes'] = ['Actual R01 source meshes. Explicit local crops and section hatching are illustration operations only. No manufactured part geometry is replaced.'] if spec.get('illustration_section') else ['Actual undeformed R01 button and cantilever. Contact is nominal. Press/release arrows belong to the document overlay; no spring deformation is simulated.']
        for report, part in zip(record['parts'], spec['parts']):
            source = Path(part['file'])
            sidecar = ROOT / source.parent / f'{source.stem.split("-")[0]}.section.json'
            if sidecar.exists():
                report['source_reference'] = json.loads(sidecar.read_text())
        record_path.write_text(json.dumps(record, indent=2))
        manifest[name] = {'svg': str(output.with_suffix('.svg').relative_to(OUT)), 'record': str(output.with_suffix('.render.json').relative_to(OUT)), 'section': spec.get('illustration_section')}
    existing = OUT / 'detail-manifest.json'
    previous = json.loads(existing.read_text()) if existing.exists() else {}
    previous.update(manifest)
    existing.write_text(json.dumps(previous, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
