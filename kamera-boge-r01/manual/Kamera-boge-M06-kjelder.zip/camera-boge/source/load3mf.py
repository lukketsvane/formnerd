import sys, zipfile, numpy as np
from lxml import etree

NS = '{http://schemas.microsoft.com/3dmanufacturing/core/2015/02}'


def load_3mf(path):
    """Return dict name->(vertices, faces, transform) for every object in a plain 3MF."""
    z = zipfile.ZipFile(path)
    objects = {}
    builds = []
    with z.open('3D/3dmodel.model') as f:
        verts, faces, name, oid = [], [], None, None
        for ev, el in etree.iterparse(f, events=('start', 'end')):
            tag = el.tag
            if ev == 'start':
                if tag == NS + 'object':
                    oid = el.get('id'); name = el.get('name') or oid
                    verts, faces = [], []
                continue
            if tag == NS + 'vertex':
                verts.append((float(el.get('x')), float(el.get('y')), float(el.get('z'))))
            elif tag == NS + 'triangle':
                faces.append((int(el.get('v1')), int(el.get('v2')), int(el.get('v3'))))
            elif tag == NS + 'object':
                objects[oid] = (name, np.asarray(verts, np.float64), np.asarray(faces, np.int64))
                verts, faces = [], []
            elif tag == NS + 'item':
                builds.append((el.get('objectid'), el.get('transform')))
            if tag in (NS + 'vertex', NS + 'triangle'):
                el.clear()
                while el.getprevious() is not None:
                    del el.getparent()[0]
    out = {}
    for oid, tr in builds:
        name, v, fcs = objects[oid]
        if tr:
            m = np.asarray([float(x) for x in tr.split()], np.float64).reshape(4, 3)
            v = v @ m[:3] + m[3]
        out[name] = (v, fcs)
    return out


if __name__ == '__main__':
    for name, (v, f) in load_3mf(sys.argv[1]).items():
        print(name, len(v), len(f), v.min(0), v.max(0))
