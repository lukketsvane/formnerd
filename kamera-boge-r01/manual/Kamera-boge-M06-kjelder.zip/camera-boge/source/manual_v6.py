"""Kamera med boge - monteringsrettleiing M06 (CAD R01).

Layout i referansen sin grammatikk: sideramme, nummer i sirkel med mengd, beslagkolonne, hole piler mellom tilstandar,
forstørringsbobler og nesten ordlause stegsider. Figurane er dei same modellavleidde vektorfigurane som i M05; strekvekta
blir sett per linjetype i pt ved teikning.

    python source/manual_v6.py            -> review/manual-v3/Kamera-boge-M06.pdf
"""
import json
import re
import sys
from pathlib import Path

import numpy as np
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[1]
REVIEW = ROOT / 'review' / 'manual-v3'
FONTS = ROOT / 'source' / 'assets' / 'fonts'
PRINT = json.loads((ROOT / 'source' / 'print-m06.json').read_text(encoding='utf-8'))
REV = 'M06'
PAGE = (595.276, 841.89)
L, B, R, T = 24.0, 40.0, PAGE[0] - 24.0, PAGE[1] - 24.0
W_FRAME = 1.4

WEIGHTS = {
    'main': {'contour': 1.45, 'detail': .62, 'organic-contour': .72, 'organic-valley': .5, 'hw-contour': 1.0, 'hw-detail': .45, 'hatch': .28, 'plate': .6},
    'small': {'contour': 1.15, 'detail': .5, 'organic-contour': .55, 'organic-valley': .4, 'hw-contour': .9, 'hw-detail': .42, 'hatch': .25, 'plate': .5},
    'icon': {'contour': 1.0, 'detail': .45, 'organic-contour': .45, 'organic-valley': .32, 'hw-contour': 1.0, 'hw-detail': .45, 'hatch': .25, 'plate': .4},
}


# ---------------------------------------------------------------- figures

class Fig:
    def __init__(self, name, folder='figures'):
        base = REVIEW / folder / name
        s = base.with_suffix('.svg').read_text()
        self.name = name
        self.vb = [float(v) for v in re.search(r'viewBox="([^"]+)"', s).group(1).split()]
        self.paths = []
        for m in re.finditer(r'<path([^>]*?)\sd="([^"]+)"', s):
            attrs = m.group(1)
            part = re.search(r'data-part="([^"]+)"', attrs)
            kind = re.search(r'data-kind="([^"]+)"', attrs)
            pts = np.array(re.findall(r'(-?\d+\.?\d*),(-?\d+\.?\d*)', m.group(2)), float)
            if len(pts) >= 2:
                self.paths.append((part.group(1) if part else '', kind.group(1) if kind else 'detail', pts))
        self.rec = json.loads(base.with_suffix('.render.json').read_text())
        self.hatch = folder == 'details' and name.startswith('button')
        allp = np.vstack([p for _, _, p in self.paths])
        lo = np.maximum(allp.min(0), self.vb[:2])
        hi = np.minimum(allp.max(0), [self.vb[0] + self.vb[2], self.vb[1] + self.vb[3]])
        self.bbox = (lo[0], lo[1], hi[0], hi[1])
        self.anchors = {k: np.asarray(v, float) for k, v in self.rec.get('anchors', {}).items()}

    def project(self, pts):
        cam = self.rec['camera']
        f = np.array(cam['direction'], float)
        f /= np.linalg.norm(f)
        up = np.array(cam['up'], float)
        r = np.cross(up, f)
        r /= np.linalg.norm(r)
        up = np.cross(f, r)
        p = (np.asarray(pts, float).reshape(-1, 3) - cam['target']) @ np.stack((r, up, f)).T
        iw, ih = self.rec['size']
        return np.column_stack((iw / 2 + p[:, 0] * ih / cam['scale'], ih / 2 - p[:, 1] * ih / cam['scale']))

    def mm_per_px(self):
        return self.rec['camera']['scale'] / self.rec['size'][1]


class Place:
    """Maps figure pixels (y down) to page points (y up)."""

    def __init__(self, fig, box, crop=None, pad=0.0, align='cc', scale=None):
        x0, y0, x1, y1 = crop or fig.bbox
        bx, by, bw, bh = box
        s = scale or min((bw - 2 * pad) / (x1 - x0), (bh - 2 * pad) / (y1 - y0))
        w, h = (x1 - x0) * s, (y1 - y0) * s
        ax = {'l': bx + pad, 'c': bx + (bw - w) / 2, 'r': bx + bw - pad - w}[align[0]]
        ay = {'b': by + pad, 'c': by + (bh - h) / 2, 't': by + bh - pad - h}[align[1]]
        self.fig, self.s, self.x0, self.y0, self.ox, self.top = fig, s, x0, y0, ax, ay + h
        self.rect = (ax, ay, w, h)
        self.crop = (x0, y0, x1, y1)

    def pt(self, fpx):
        f = np.atleast_2d(np.asarray(fpx, float))
        return np.column_stack((self.ox + (f[:, 0] - self.x0) * self.s, self.top - (f[:, 1] - self.y0) * self.s))

    def p3(self, xyz):
        return self.pt(self.fig.project(xyz))

    def a(self, name):
        return self.pt(self.fig.anchors[name])[0]

    def pt_per_mm(self):
        return self.s / self.fig.mm_per_px()


def is_hw(part):
    return bool(part) and not part.startswith(('P0', 'T0', 'plate', 'organic', 'test-P04'))


def draw(c, place, style='main', clip=None, clip_view=True):
    fig, W = place.fig, WEIGHTS[style]
    c.saveState()
    if clip is not None:
        p = c.beginPath()
        if clip[0] == 'circle':
            p.circle(clip[1], clip[2], clip[3])
        else:
            p.rect(*clip[1:])
        c.clipPath(p, stroke=0, fill=0)
    elif clip_view:
        vb = fig.vb
        corners = place.pt([[vb[0], vb[1]], [vb[0] + vb[2], vb[1] + vb[3]]])
        p = c.beginPath()
        p.rect(corners[0][0], corners[1][1], corners[1][0] - corners[0][0], corners[0][1] - corners[1][1])
        c.clipPath(p, stroke=0, fill=0)
    c.setLineCap(1)
    c.setLineJoin(1)
    c.setStrokeColorRGB(0, 0, 0)
    for part, kind, pts in sorted(fig.paths, key=lambda q: q[1] == 'contour'):
        hw = is_hw(part)
        if part == 'plate':
            w = W['plate']
        elif kind == 'contour':
            w = W['hw-contour'] if hw else W['contour']
        elif kind.startswith('organic'):
            w = W[kind]
        else:
            d = pts[-1] - pts[0]
            if fig.hatch and len(pts) == 2 and abs(abs(d[0]) - abs(d[1])) < .12 * max(abs(d[0]), abs(d[1]), 1e-9):
                w = W['hatch']
            else:
                w = W['hw-detail'] if hw else W['detail']
        q = place.pt(pts)
        path = c.beginPath()
        path.moveTo(*q[0])
        for v in q[1:]:
            path.lineTo(*v)
        c.setLineWidth(w)
        c.drawPath(path, stroke=1, fill=0)
    c.restoreState()


def fig(c, name, box, folder='figures', style='main', **kw):
    f = Fig(name, folder)
    p = Place(f, box, **kw)
    draw(c, p, style)
    return p


# ---------------------------------------------------------------- page grammar

def fonts():
    pdfmetrics.registerFont(TTFont('LS', str(FONTS / 'LiberationSans-Regular.ttf')))
    pdfmetrics.registerFont(TTFont('LSB', str(FONTS / 'LiberationSans-Bold.ttf')))


def text(c, x, y, s, size=12, align='l', font='LS', space=0):
    c.setFillColorRGB(0, 0, 0)
    c.setFont(font, size)
    if align == 'c':
        c.drawCentredString(x, y, s, charSpace=space)
    elif align == 'r':
        c.drawRightString(x, y, s, charSpace=space)
    else:
        c.drawString(x, y, s, charSpace=space)


def page(c, n, step=None, frame=W_FRAME):
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(frame)
    c.setLineJoin(0)
    c.rect(L, B, R - L, T - B, stroke=1, fill=0)
    text(c, PAGE[0] / 2, 22, str(n), 9, 'c')
    text(c, R, 22, f'KAMERA MED BOGE  ·  R01  ·  {REV}', 6.5, 'r')
    if step is not None:
        text(c, L + 16, T - 54, str(step), 46, font='LSB')


def poly(c, pts, w=1.0, dash=None, close=False, fill=None):
    p = np.asarray(pts, float)
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(w)
    c.setLineCap(1)
    c.setLineJoin(1)
    c.setDash(*dash) if dash else c.setDash()
    path = c.beginPath()
    path.moveTo(*p[0])
    for v in p[1:]:
        path.lineTo(*v)
    if close:
        path.close()
    if fill is not None:
        c.setFillColorRGB(*fill)
    c.drawPath(path, stroke=1, fill=1 if fill is not None else 0)
    c.setDash()


def dashed(c, pts, w=.6):
    poly(c, pts, w, dash=(3.2, 2.2))


def head(c, tip, d, size=7.5):
    d = np.asarray(d, float)
    d /= np.linalg.norm(d)
    n = np.array([-d[1], d[0]])
    a = tip - d * size + n * size * .38
    b = tip - d * size - n * size * .38
    poly(c, [tip, a, b], .6, close=True, fill=(0, 0, 0))


def arrow(c, pts, w=1.1, size=7.5, back=False):
    p = np.asarray(pts, float)
    d = p[-1] - p[-2]
    poly(c, np.vstack((p[:-1], p[-1] - d / np.linalg.norm(d) * size * .6)), w)
    head(c, p[-1], d, size)
    if back:
        head(c, p[0], p[0] - p[1], size)


def hollow(c, x, y, d='r', length=30, width=17, w=1.0):
    sw, hl = width * .42, length * .48
    shape = np.array([[-length / 2, -sw / 2], [length / 2 - hl, -sw / 2], [length / 2 - hl, -width / 2], [length / 2, 0],
                      [length / 2 - hl, width / 2], [length / 2 - hl, sw / 2], [-length / 2, sw / 2]])
    rot = {'r': 0, 'u': 90, 'l': 180, 'd': 270}[d] if isinstance(d, str) else d
    a = np.radians(rot)
    m = np.array([[np.cos(a), -np.sin(a)], [np.sin(a), np.cos(a)]])
    poly(c, shape @ m.T + [x, y], w, close=True, fill=(1, 1, 1))


def circled(c, x, y, label, r=12.5, size=None, w=1.0):
    c.setLineWidth(w)
    c.setStrokeColorRGB(0, 0, 0)
    c.setFillColorRGB(1, 1, 1)
    c.circle(x, y, r, stroke=1, fill=1)
    size = size or (15 if len(label) == 1 else 12 if len(label) == 2 else 9.5)
    text(c, x, y - size * .36, label, size, 'c')


def part_label(c, x, y, n, qty=1, r=12.5):
    circled(c, x, y, str(n), r)
    text(c, x + r + 3, y - 5.6, f'x{qty}', 16)


def leader_label(c, at, pos, n, r=12.5, qty=None, w=.6):
    at, pos = np.asarray(at, float), np.asarray(pos, float)
    d = at - pos
    dist = np.linalg.norm(d)
    if dist > r + 2:
        poly(c, [pos + d / dist * r, at], w)
        c.setFillColorRGB(0, 0, 0)
        c.circle(at[0], at[1], 1.4, stroke=0, fill=1)
    if qty is None:
        circled(c, pos[0], pos[1], str(n), r)
    else:
        part_label(c, pos[0], pos[1], n, qty, r)


def hw_column(c, items, w=112, h=92):
    """Beslagboksar i øvre høgre hjørne: bokstav, teikning, mengd."""
    y = T
    for letter, name, count in items:
        c.setLineWidth(W_FRAME)
        c.setStrokeColorRGB(0, 0, 0)
        c.setFillColorRGB(1, 1, 1)
        c.rect(R - w, y - h, w, h, stroke=1, fill=1)
        text(c, R - w + 8, y - 21, letter, 18)
        fig(c, name, (R - w + 22, y - h + 24, w - 36, h - 44), style='icon')
        text(c, R - 9, y - h + 9, f'x{count}', 18, 'r')
        y -= h
    return y


def label(c, x, y, s, size=14, align='l'):
    text(c, x, y, s, size, align)


def check(c, x, y, ok=True, r=11, w=1.4):
    c.setLineWidth(1.0)
    c.setStrokeColorRGB(0, 0, 0)
    c.setFillColorRGB(1, 1, 1)
    c.circle(x, y, r, stroke=1, fill=1)
    if ok:
        poly(c, [[x - r * .45, y], [x - r * .1, y - r * .4], [x + r * .5, y + r * .42]], w)
    else:
        poly(c, [[x - r * .4, y - r * .4], [x + r * .4, y + r * .4]], w)
        poly(c, [[x - r * .4, y + r * .4], [x + r * .4, y - r * .4]], w)


def rotation(c, place, centre, axis, radius, a0=.5, a1=-4.3, w=1.0, size=6.5):
    axis = np.asarray(axis, float)
    axis /= np.linalg.norm(axis)
    u = np.cross(axis, [0, 0, 1] if abs(axis[2]) < .9 else [1, 0, 0])
    u /= np.linalg.norm(u)
    v = np.cross(axis, u)
    t = np.linspace(a0, a1, 60)
    pts = np.asarray(centre, float) + radius * (np.cos(t)[:, None] * u + np.sin(t)[:, None] * v)
    arrow(c, place.p3(pts), w, size)


def bubble(c, place_src_fig, centre_fpx, scale, cx, cy, r, src_at=None, style='main', w=1.3, ring=9):
    """Forstørringsboble: teiknar figuren rundt centre_fpx med gitt skala inne i ein sirkel, med leiar frå src_at."""
    f = place_src_fig
    if src_at is not None:
        src_at = np.asarray(src_at, float)
        d = np.array([cx, cy]) - src_at
        dist = np.linalg.norm(d)
        c.setLineWidth(.8)
        c.setStrokeColorRGB(0, 0, 0)
        c.circle(src_at[0], src_at[1], ring, stroke=1, fill=0)
        poly(c, [src_at + d / dist * ring, np.array([cx, cy]) - d / dist * r], .7)
    c.setFillColorRGB(1, 1, 1)
    c.setLineWidth(w)
    c.circle(cx, cy, r, stroke=0, fill=1)
    half = r / scale
    crop = (centre_fpx[0] - half, centre_fpx[1] - half, centre_fpx[0] + half, centre_fpx[1] + half)
    p = Place(f, (cx - r, cy - r, 2 * r, 2 * r), crop=crop, scale=scale)
    draw(c, p, style, clip=('circle', cx, cy, r - .3))
    c.setStrokeColorRGB(0, 0, 0)
    c.setLineWidth(w)
    c.circle(cx, cy, r, stroke=1, fill=0)
    return p


def clock(c, x, y, r=8):
    c.setLineWidth(1.0)
    c.circle(x, y, r, stroke=1, fill=0)
    poly(c, [[x, y + r * .62], [x, y], [x + r * .5, y]], 1.0)


def spool(c, x, y, r=8):
    c.setLineWidth(1.0)
    c.circle(x, y, r, stroke=1, fill=0)
    c.circle(x, y, r * .35, stroke=1, fill=0)


def warn(c, x, y, s=16):
    h = s * .87
    poly(c, [[x - s / 2, y], [x + s / 2, y], [x, y + h]], 1.0, close=True)
    poly(c, [[x, y + h * .3], [x, y + h * .66]], 1.4)
    c.circle(x, y + h * .17, .9, stroke=0, fill=1)


# ---------------------------------------------------------------- pages

def p_cover(c, n):
    page(c, n, frame=.9)
    text(c, PAGE[0] / 2, T - 66, 'KAMERA MED BOGE', 26, 'c', space=1.5)
    text(c, PAGE[0] / 2, T - 90, 'MONTERINGSRETTLEIING', 11, 'c', space=2.5)
    fig(c, 'cover', (L + 26, B + 56, R - L - 52, T - B - 190))
    text(c, L + 16, B + 16, 'FORMNERD', 8)
    text(c, R - 16, B + 16, f'CAD R01  ·  RETTLEIING {REV}', 8, 'r')


PARTS = {1: 'P01', 2: 'P02', 3: 'P03', 4: 'P04', 5: 'P05'}


def p_parts(c, n):
    page(c, n)
    cells = {1: (L + 10, T - 332, 336, 322), 2: (L + 350, T - 332, 187, 322),
             3: (L + 10, B + 222, 176, 222), 4: (L + 186, B + 222, 176, 222), 5: (L + 362, B + 222, 175, 222)}
    for k, (x, y, w, h) in cells.items():
        part_label(c, x + 18, y + h - 18, k)
        text(c, x + 18, y + h - 42, PARTS[k], 7.5, 'c')
        fig(c, f'inventory-{PARTS[k]}', (x + 4, y + 2, w - 8, h - 34), style='main')
    poly(c, [[L, B + 214], [R, B + 214]], .6)
    part_label(c, L + 28, B + 190, 'T')
    text(c, L + 28, B + 166, 'T01', 7.5, 'c')
    fig(c, 'coupon', (L + 70, B + 8, R - L - 90, 200), style='main')


def p_hardware(c, n):
    page(c, n)
    rows = [('A', 'hardware-rear-screw', 6, 'M3 x 12', 12), ('B', 'hardware-nut', 4, 'M3', None), ('C', 'hardware-lens-screw', 3, 'M2,5 x 8', 8)]
    k = 14.17
    y = T
    h = 172
    for letter, name, count, size, length in rows:
        text(c, L + 22, y - 38, letter, 28)
        f = Fig(name)
        p = Place(f, (L + 70, y - h + 10, 290, h - 20), scale=k * f.mm_per_px())
        draw(c, p, 'main')
        text(c, R - 24, y - h + 24, f'x{count}', 30, 'r')
        text(c, R - 24, y - 36, size, 12, 'r')
        if length:
            x0, yy = R - 170, y - h + 70
            bar = length * 72 / 25.4
            poly(c, [[x0, yy], [x0 + bar, yy]], 1.0)
            poly(c, [[x0, yy - 5], [x0, yy + 5]], 1.0)
            poly(c, [[x0 + bar, yy - 5], [x0 + bar, yy + 5]], 1.0)
            text(c, x0 + bar / 2, yy + 8, str(length), 10, 'c')
            text(c, x0 - 8, yy - 3.5, '1:1', 8, 'r')
        y -= h
        poly(c, [[L, y], [R, y]], .6)
    text(c, L + 22, T - h + 12, '5 : 1', 8)
    for i, (af, letter) in enumerate((('2,5', 'A'), ('2', 'C'))):
        x0 = L + 34 + i * 262
        f = Fig('tool-hex-key')
        p = Place(f, (x0, B + 18, 150 * (1 if i == 0 else .85), y - B - 34), align='cb')
        draw(c, p, 'main')
        text(c, x0 + 172, B + 96, af, 26)
        c.setLineWidth(1.0)
        c.rect(x0 + 173, B + 52, 26, 26, stroke=1, fill=0)
        text(c, x0 + 186, B + 58, letter, 17, 'c')


def p_print(c, n):
    page(c, n)
    text(c, L + 16, T - 48, 'P1S', 34, font='LSB')
    rows = [(PRINT['plater'][0], 'plate-00', '00'), (PRINT['plater'][1], 'plate-01', '01'), (PRINT['plater'][2], 'plate-02', '02')]
    nums = {'T01': 'T', 'P04': '4', 'P01': '1', 'P02': '2', 'P03': '3', 'P05': '5'}
    y = T - 70
    hrow = 205
    for i, (info, name, code) in enumerate(rows):
        box = (L + 14, y - hrow, 352, hrow)
        p = fig(c, name, box)
        for part, at in p.fig.anchors.items():
            pos = p.pt(at)[0]
            circled(c, pos[0], pos[1] + 2, nums[part], 11)
        x = L + 384
        c.setLineWidth(1.4)
        c.roundRect(x, y - 62, 72, 44, 6, stroke=1, fill=0)
        text(c, x + 36, y - 50, code, 26, 'c', font='LSB')
        clock(c, x + 10, y - 96)
        text(c, x + 26, y - 101, info['tid'], 14)
        spool(c, x + 10, y - 126)
        text(c, x + 26, y - 131, info['vekt'].replace(' PLA', ''), 14)
        if i < 2:
            hollow(c, L + 190, y - hrow - 4, 'd', 26, 16)
        y -= hrow + 12
    text(c, L + 16, B + 30, '0,4 mm  ·  Textured PEI  ·  Bambu PLA Basic  ·  0,20 mm  ·  3 veggar  ·  15 % gyroid  ·  trestøtte', 8.5)
    text(c, L + 16, B + 16, '01: støtte inne i huset, i linseholet og knappeholet. Trekk ut gjennom bakopninga.', 8.5)


def p_test(c, n):
    page(c, n)
    text(c, L + 16, T - 54, 'T', 46, font='LSB')
    part_label(c, L + 72, T - 36, 4)
    pa = fig(c, 'coupon-test-a', (L + 10, T - 410, R - L - 20, 340))
    for h, ok in (('h16.0', None), ('h16.4', True), ('h16.8', None)):
        at = pa.a(h)
        text(c, at[0] + 4, at[1] - 36, h[1:].replace('.', ','), 13, 'c')
        if ok:
            check(c, at[0] + 34, at[1] - 31, True, 9)
    top = pa.a('P04-top')
    x = top[0] + 70
    arrow(c, [[x, top[1] - 6], [x, top[1] - 62]], 1.3, 9, back=True)
    hollow(c, PAGE[0] / 2, T - 420, 'd', 26, 16)
    pb = fig(c, 'coupon-test-b', (L + 10, B + 20, R - L - 20, 330))
    for h, ok in (('n5.7', None), ('n5.9', True), ('n6.1', None)):
        at = pb.a(h)
        if ok:
            text(c, at[0] + 46, at[1] + 4, '5,9', 12, 'c')
            check(c, at[0] + 72, at[1] + 8, True, 8)
        else:
            text(c, at[0], at[1] + 20, h[1:].replace('.', ','), 12, 'c')
    for h in ('p2.0', 'p2.5', 'p3.4'):
        at = pb.a(h)
        text(c, at[0], at[1] - 24, h[1:].replace('.', ','), 12, 'c')
    for item, hole in (('C-low', 'p2.0'), ('A-low', 'p2.5'), ('A2-low', 'p3.4')):
        dashed(c, [pb.a(item), pb.a(hole)])
    for item, lab in (('C-top', 'C'), ('A-top', 'A'), ('A2-top', 'A')):
        at = pb.a(item)
        text(c, at[0], at[1] + 14, lab, 15, 'c')
    nt = pb.a('nut-low')
    text(c, nt[0] - 30, nt[1] + 4, 'B', 15, 'c')


def p_exploded(c, n):
    page(c, n)
    p = fig(c, 'exploded', (L + 10, T - 470, R - L - 20, 450))
    for part, off in {'P01': None, 'P02': None, 'P03': (-4, 34), 'P05': (28, 34)}.items():
        at = p.a(part)
        if off is None:
            circled(c, at[0], at[1], part[-1], 14)
        else:
            leader_label(c, at, at + off, part[-1], 12.5)
    for letter, pt3, off in (('C', [-38, 91, 63.5], (-4, 18)), ('A', [48, -105, 62], (-26, 10)), ('B', [-48, -46, 18], (-30, -22))):
        at = p.p3(pt3)[0]
        if letter == 'B':
            poly(c, [at, at + np.array(off) * .62], .6)
        text(c, at[0] + off[0], at[1] + off[1] - 5, letter, 15, 'c')
    x0, y0, w, h = L + 120, B + 24, R - L - 240, T - 500 - B - 24
    c.setLineWidth(1.0)
    c.rect(x0, y0, w, h, stroke=1, fill=0)
    q = fig(c, 'spring-fastening-before', (x0 + 10, y0 + 30, w - 20, h - 40), folder='proofs')
    for side in ('left', 'right'):
        dashed(c, [q.a(f'head-{side}'), q.a(f'spring-{side}')])
    tip = q.a('tip')
    circled(c, tip[0] + 6, tip[1] + 40, '4', 12.5)
    sl = q.a('spring-right')
    leader_label(c, sl + [24, 4], sl + [60, -24], '5', 12.5)
    hl = q.a('head-left')
    text(c, hl[0] - 8, hl[1] + 16, 'A', 15, 'c')
    text(c, x0 + 10, y0 + 10, '1 - 3', 11, font='LSB')


def p_step_button(c, n, step):
    page(c, n, step)
    part_label(c, L + 92, T - 36, 4)
    ctx = fig(c, 'button-context', (L + 20, T - 470, R - L - 40, 390))
    rs, rc, re_ = ctx.a('route-start'), ctx.a('route-corner'), ctx.a('route-end')
    dashed(c, [rs, rc, re_], .9)
    head(c, re_, re_ - rc, 9)
    top = ctx.a('top-hole')
    c.setLineWidth(1.0)
    c.circle(top[0], top[1], 13, stroke=1, fill=0)
    h = 228
    y = B + 22
    a = fig(c, 'button-start', (L + 10, y, 200, h), folder='details')
    arrow(c, [a.a('insert-start'), a.a('insert-end')], 1.3, 9)
    hollow(c, L + 226, y + h / 2, 'r', 26, 15)
    b = fig(c, 'button-middle', (L + 242, y, 150, h), folder='details')
    arrow(c, [b.a('insert-end'), b.a('lift-end')], 1.3, 9)
    hollow(c, L + 404, y + h / 2, 'r', 26, 15)
    f = fig(c, 'button-final', (L + 418, y, 120, h), folder='details')
    check(c, R - 26, y + h - 10, True, 11)
    poly(c, [[L, T - 486], [R, T - 486]], .6)


def p_step_spring(c, n, step):
    page(c, n, step)
    hw_column(c, [('A', 'hardware-rear-screw', 2)])
    part_label(c, L + 92, T - 36, 5)
    h1 = 190
    a = fig(c, 'spring-insert-before', (L + 12, T - 104 - h1, 270, h1))
    st, en = a.a('start'), a.a('end')
    d = (en - st) / np.linalg.norm(en - st)
    nrm = np.array([-d[1], d[0]])
    arrow(c, [st + nrm * 26 - d * 30, en + nrm * 26], 1.3, 9)
    hollow(c, L + 300, T - 104 - h1 / 2, 'r')
    fig(c, 'spring-insert-after', (L + 320, T - 104 - h1, 214, h1))
    hollow(c, PAGE[0] / 2, T - 112 - h1 - 6, 'd', 26, 16)
    h2 = 200
    y2 = T - 140 - h1 - h2
    b = fig(c, 'spring-fastening-before', (L + 12, y2, R - L - 24, h2), folder='proofs')
    for side in ('left', 'right'):
        dashed(c, [b.a(f'head-{side}'), b.a(f'spring-{side}')])
    hl = b.a('head-left')
    text(c, hl[0] - 10, hl[1] + 18, 'Ax2', 15, 'c')
    hollow(c, PAGE[0] / 2, y2 - 14, 'd', 26, 16)
    d2 = fig(c, 'spring-fastening-after', (L + 40, B + 26, R - L - 80, y2 - 32 - B - 26), folder='proofs')
    rotation(c, d2, [36, -52, 71.4], [0, 1, 0], 4.5)


def p_step_test(c, n, step):
    page(c, n, step)
    p = fig(c, 'button-test', (L + 20, T - 440, R - L - 40, 380))
    top = p.a('top')
    for dx, up, lab in ((-34, False, '1'), (34, True, '2')):
        x = top[0] + dx
        pts = [[x, top[1] + 64], [x, top[1] + 18]]
        arrow(c, pts[::-1] if up else pts, 1.6, 11)
        text(c, x + (-12 if dx < 0 else 12), top[1] + 54, lab, 18, 'r' if dx < 0 else 'l')
    foot = p.a('foot')
    q = Fig('spring-contact', 'details')
    cx, cy, r = L + 200, B + 175, 140
    centre = q.anchors['contact'] + [-90, -140]
    bubble(c, q, centre, 2 * r * .78 / (q.bbox[3] - q.bbox[1]), cx, cy, r, src_at=foot)
    check(c, R - 70, B + 80, True, 18, 2.0)


def p_step_lens(c, n, step):
    page(c, n, step)
    hw_column(c, [('C', 'hardware-lens-screw', 3)])
    part_label(c, L + 92, T - 36, 3)
    p = fig(c, 'lens-insert', (L + 12, T - 470, R - L - 140, 380))
    arrow(c, p.p3([[-38, 92, 41.5 - 30], [-38, 50, 41.5 - 30]]), 1.3, 9)
    hollow(c, PAGE[0] / 2, T - 484, 'd', 26, 16)
    a = fig(c, 'lens-fasten-before', (L + 12, B + 16, 240, 240))
    for ang in (90, 210, 330):
        x, z = -38 + 22 * np.cos(np.radians(ang)), 41.5 + 22 * np.sin(np.radians(ang))
        dashed(c, a.p3([[x, 61.5, z], [x, 40.5, z]]))
    text(c, L + 40, B + 236, 'Cx3', 15)
    hollow(c, L + 268, B + 130, 'r')
    b = fig(c, 'lens-fasten-after', (L + 290, B + 16, 240, 240))
    for ang in (90, 210, 330):
        x, z = -38 + 22 * np.cos(np.radians(ang)), 41.5 + 22 * np.sin(np.radians(ang))
        rotation(c, b, [x, 46, z], [0, 1, 0], 4.5)


def p_step_nuts(c, n, step):
    page(c, n, step)
    hw_column(c, [('B', 'hardware-nut', 4)])
    p = fig(c, 'nuts-insert', (L + 30, B + 170, R - L - 60, T - B - 270))
    for i in (1, 2, 3, 4):
        dashed(c, [p.a(f'n{i}'), p.a(f'n{i}-seat')])
    pts = {i: p.a(f'n{i}') for i in (1, 2, 3, 4)}
    left = min(pts.values(), key=lambda v: v[0] - v[1] * 0.01)
    text(c, left[0] - 40, left[1] + 30, 'Bx4', 15, 'c')
    poly(c, [left + [-30, 22], left + [-6, 6]], .6)
    cx, cy, r = R - 120, B + 100, 76
    seats = {i: p.a(f'n{i}-seat') for i in (1, 2, 3, 4)}
    k = min(seats, key=lambda i: np.hypot(seats[i][0] - cx, seats[i][1] - cy))
    bubble(c, p.fig, p.fig.anchors[f'n{k}-seat'] + [0, -10], p.s * 3.0, cx, cy, r, src_at=seats[k])


def p_step_lid(c, n, step):
    page(c, n, step)
    part_label(c, L + 92, T - 36, 2)
    p = fig(c, 'lid-insert', (L + 12, T - 470, R - L - 24, 400))
    arrow(c, [p.a('start'), p.a('end')], 1.3, 9)
    pin = p.a('pin1')
    a = Fig('pin-before', 'details')
    b = Fig('pin-after', 'details')
    r = 98
    ca = (L + 140, B + 128)
    cb = (R - 140, B + 128)
    pa = bubble(c, a, [(a.bbox[0] + a.bbox[2]) / 2, (a.bbox[1] + a.bbox[3]) / 2], 1.7 * r / (a.bbox[2] - a.bbox[0]), ca[0], ca[1], r, src_at=pin)
    dashed(c, [pa.a('axis-start'), pa.a('axis-end')])
    head(c, pa.a('axis-end'), pa.a('axis-end') - pa.a('axis-start'), 8)
    hollow(c, PAGE[0] / 2, B + 128, 'r')
    bubble(c, b, [(b.bbox[0] + b.bbox[2]) / 2, (b.bbox[1] + b.bbox[3]) / 2], 1.7 * r / (b.bbox[2] - b.bbox[0]), cb[0], cb[1], r)
    text(c, R - 22, B + 232, 'x2', 30, 'r')


def p_step_lid_screws(c, n, step):
    page(c, n, step)
    hw_column(c, [('A', 'hardware-rear-screw', 4)])
    p = fig(c, 'lid-fasten', (L + 30, B + 190, R - L - 60, T - B - 290))
    for idx, (x, z) in enumerate([(-48, 18), (48, 62), (-48, 62), (48, 18)], 1):
        dashed(c, p.p3([[x, -55.6, z], [x, -37.6, z]]))
        rotation(c, p, [x, -73, z], [0, 1, 0], 6)
        at = p.p3([[x, -70.7, z]])[0]
        circled(c, at[0] - 22, at[1] + 26, str(idx), 9, 11)
    s1 = p.a('s1')
    text(c, s1[0] + 6, s1[1] - 40, 'Ax4', 15, 'c')
    fig(c, 'finished-rear', (R - 220, B + 14, 200, 170), style='small')
    check(c, R - 240, B + 60, True, 14)


def p_final(c, n):
    page(c, n)
    fig(c, 'cover', (L + 70, T - 380, R - L - 140, 340))
    checks = [('4', 'glir ned og kjem tilbake'), ('5', 'ligg under knappefoten'), ('3', 'sit jamt i framsida'), ('2', 'sit jamt, fire skruar')]
    y = T - 420
    for k, s in checks:
        c.setLineWidth(1.0)
        c.rect(L + 26, y - 4, 13, 13, stroke=1, fill=0)
        circled(c, L + 64, y + 2.5, k, 10)
        text(c, L + 84, y - 2, s, 12)
        y -= 30
    poly(c, [[L, y + 6], [R, y + 6]], .6)
    warn(c, L + 34, y - 26)
    text(c, L + 52, y - 22, 'Stopp om noko kilar. Ikkje bruk kraft.', 12)
    y -= 56
    rows = [('4', 'kilar', 'fjern støtterestar i Ø16,4-holet og slip stammen lett'),
            ('2', 'sit ikkje', 'B i botnen av lommene, reine styrepinnar'),
            ('3', 'kilar', 'avgrad kanten av Ø38-holet'),
            ('1', 'støtte sit fast', 'trekk ut gjennom bakopninga med tang')]
    for k, a, b in rows:
        circled(c, L + 33, y + 4, k, 9.5)
        text(c, L + 50, y, a, 11, font='LSB')
        text(c, L + 150, y, b, 11)
        y -= 24
    text(c, L + 26, B + 22, 'Mekanisk prøvebygg. Fysisk passform, fjørretur og maskinvare er ikkje prøvde.', 8.5)


PAGES = [p_cover, p_parts, p_hardware, p_print, p_test, p_exploded,
         lambda c, n: p_step_button(c, n, 1), lambda c, n: p_step_spring(c, n, 2), lambda c, n: p_step_test(c, n, 3),
         lambda c, n: p_step_lens(c, n, 4), lambda c, n: p_step_nuts(c, n, 5), lambda c, n: p_step_lid(c, n, 6),
         lambda c, n: p_step_lid_screws(c, n, 7), p_final]


def build(out=None, only=None):
    fonts()
    out = Path(out or REVIEW / f'Kamera-boge-{REV}.pdf')
    c = canvas.Canvas(str(out), pagesize=PAGE, pageCompression=1)
    c.setTitle(f'Kamera med boge - monteringsrettleiing {REV}')
    c.setAuthor('FormNerd')
    for i, fn in enumerate(PAGES, 1):
        if only and i not in only:
            continue
        fn(c, i)
        c.showPage()
    c.save()
    print(out)
    return out


if __name__ == '__main__':
    build(only=[int(a) for a in sys.argv[1:]] or None)
