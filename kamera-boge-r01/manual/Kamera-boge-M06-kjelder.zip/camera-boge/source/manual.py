import argparse
import copy
import json
from pathlib import Path

import numpy as np
from PIL import Image
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

ROOT = Path(__file__).resolve().parents[1]
REVIEW = ROOT / 'review'
FIGURES = REVIEW / 'figures'
SCENES = ROOT / 'source' / 'scenes'
PAGE = (595.276, 841.89)
FONT = ROOT / 'source' / 'assets' / 'fonts'
FRONT = [1, 2, 1.1]
REAR = [1, -1, 0.65]
NAMES = {'P01': 'Framhus', 'P02': 'Bakdeksel', 'P03': 'Linseinnsats', 'P04': 'Utløysarknapp', 'P05': 'Prøvefjør'}


def part(name, move=None, color='#a8aaa9'):
    result = {'file': f'cad/{name}.stl', 'color': color}
    if move:
        result['translate'] = move
    return result


def hardware(kind, count, move=None):
    result = []
    for i in range(1, count + 1):
        value = {'file': f'cad/hardware/{kind}-{i:02d}.stl', 'color': '#737573'}
        if move:
            value['translate'] = move
        result.append(value)
    return result


def scene(parts, direction=REAR, anchors=None, mode='line', size=(1800, 1400), target=None, scale=None):
    camera = {'direction': direction, 'up': [0, 0, 1], 'padding': 1.14}
    if target is not None:
        camera['target'] = target
    if scale is not None:
        camera['scale'] = scale
    return {'size': list(size), 'supersample': 1, 'parts': parts, 'camera': camera, 'anchors': anchors or {}, 'mode': mode}


def scenes():
    product = [part(p) for p in NAMES]
    all_hardware = hardware('rear-screw', 4) + hardware('nut', 4) + hardware('spring-screw', 2) + hardware('lens-screw', 3)
    out = {'cover': scene(product + all_hardware, FRONT, mode='shaded', size=(2000, 1600))}
    out['coupon'] = scene([{'file': 'print/T01.stl', 'color': '#aaa'}], [0.4, -0.7, 1.3], {'button': [35, 17.5, 4], 'nuts': [30, 30, 4], 'pilots': [23, 5, 4]})
    for p in NAMES:
        out[f'inventory-{p}'] = scene([part(p)], REAR if p in ('P02', 'P05') else FRONT, size=(1000, 800))
    for kind in ('rear-screw', 'nut', 'lens-screw'):
        out[f'hardware-{kind}'] = scene(hardware(kind, 1), [1, -2, 1], size=(700, 400))
    out['exploded'] = scene([part('P01'), part('P02', [0, -55, 0]), part('P03', [0, 35, 0]), part('P04', [0, 0, 30]), part('P05', [0, -27, 0])] + hardware('rear-screw', 4, [0, -65, 0]) + hardware('nut', 4, [0, -18, 0]) + hardware('spring-screw', 2, [0, -45, 0]) + hardware('lens-screw', 3, [0, 48, 0]), [-1, -1, 0.7], {'P01': [0, 15, 50], 'P02': [0, -94, 44], 'P03': [-38, 75, 41.5], 'P04': [48, 10, 120], 'P05': [46, -48, 73]}, size=(1800, 1600))
    out['button'] = scene([part('P01'), part('P04', [0, -55, -46])], REAR, {'start': [48, -45, 42.5], 'corner': [48, 10, 42.5], 'end': [48, 10, 88.5], 'button': [48, -45, 50]}, size=(1800, 1600))
    out['spring'] = scene([part('P01'), part('P04'), part('P05', [0, -30, 0])] + hardware('spring-screw', 2, [0, -47, 0]), REAR, {'start': [46, -49, 72], 'end': [46, -19, 72], 'left': [36, -24, 71.4], 'right': [54, -24, 71.4]}, size=(1800, 1500))
    out['spring-detail'] = scene([part('P04'), part('P05')] + hardware('spring-screw', 2), REAR, {'s1': [36, -24, 71.4], 's2': [54, -24, 71.4], 'tip': [48, 10, 74.4]}, target=[47, -6, 81], scale=68, size=(1000, 1000))
    out['lens'] = scene([part('P01'), part('P03', [0, 29, 0]), part('P04'), part('P05')] + hardware('spring-screw', 2) + hardware('lens-screw', 3, [0, 43, 0]), FRONT, {'start': [-38, 69, 41.5], 'end': [-38, 40, 41.5], 'ring': [-38, 69, 64]}, size=(1800, 1500))
    out['nuts'] = scene([part('P01'), part('P03'), part('P04'), part('P05')] + hardware('spring-screw', 2) + hardware('lens-screw', 3) + hardware('nut', 4, [0, -14, 0]), REAR, {f'n{i}': [x, -45.7, z] for i, (x, z) in enumerate([[-48, 18], [48, 18], [-48, 62], [48, 62]], 1)}, size=(1800, 1500))
    out['back'] = scene([part('P01'), part('P02', [0, -35, 0]), part('P03'), part('P04'), part('P05')] + hardware('spring-screw', 2) + hardware('lens-screw', 3) + hardware('nut', 4) + hardware('rear-screw', 4, [0, -43, 0]), REAR, {'start': [0, -75, 43], 'end': [0, -40, 43], 'pin1': [-20, -34.6, 12], 'pin2': [20, -34.6, 12]}, size=(1800, 1600))
    out['finished'] = scene(product + all_hardware, FRONT, {'press-start': [48, 10, 117], 'press-end': [48, 10, 102], 'button': [48, 10, 102]}, size=(1800, 1400))
    return out


def make_figures(force=False):
    from render import render
    FIGURES.mkdir(parents=True, exist_ok=True)
    SCENES.mkdir(parents=True, exist_ok=True)
    records = {}
    for name, value in scenes().items():
        source = SCENES / f'manual-{name}.json'
        payload = json.dumps(value, ensure_ascii=False, indent=2)
        changed = not source.exists() or source.read_text() != payload
        source.write_text(payload)
        output = FIGURES / f'{name}.png'
        resolved = copy.deepcopy(value)
        for p in resolved['parts']:
            p['file'] = str(ROOT / p['file'])
        mtime = max(Path(p['file']).stat().st_mtime for p in resolved['parts'])
        record = output.with_suffix('.render.json')
        if force or changed or not output.exists() or not record.exists() or output.stat().st_mtime < mtime:
            print(f'render {name}', flush=True)
            records[name] = render(resolved, output)
        else:
            records[name] = json.loads(record.read_text())
    return records


def text(c, x, y, value, size=12, bold=False):
    c.setFillColorRGB(0.08, 0.08, 0.08)
    c.setFont('ManualBold' if bold else 'Manual', size)
    c.drawString(x, y, value)


def paragraph(c, x, y, value, width=495, size=12, leading=18):
    words, line = value.split(), ''
    for word in words:
        test = f'{line} {word}'.strip()
        if pdfmetrics.stringWidth(test, 'Manual', size) > width and line:
            text(c, x, y, line, size)
            y -= leading
            line = word
        else:
            line = test
    if line:
        text(c, x, y, line, size)
    return y - leading


def page(c, number, title=None, step=None):
    c.setFillColorRGB(1, 1, 1)
    c.rect(0, 0, *PAGE, stroke=0, fill=1)
    if step is not None:
        text(c, 42, 757, str(step), 48, True)
        text(c, 105, 768, title, 20)
    elif title:
        text(c, 42, 767, title, 25, True)
    text(c, 42, 30, 'FORMNERD  /  R01', 8)
    c.setFont('Manual', 8)
    c.drawRightString(PAGE[0] - 42, 30, f'{number} / 10')


def picture(c, name, box, records):
    path = FIGURES / f'{name}.png'
    im = Image.open(path)
    x, y, width, height = box
    factor = min(width / im.width, height / im.height)
    w, h = im.width * factor, im.height * factor
    left, bottom = x + (width - w) / 2, y + (height - h) / 2
    c.drawImage(str(path), left, bottom, w, h, mask='auto')
    return {key: (left + p[0] * factor, bottom + h - p[1] * factor) for key, p in records[name]['anchors'].items()}


def arrow(c, points, width=1.3):
    p = np.asarray(points, float)
    c.setStrokeColorRGB(0.05, 0.05, 0.05)
    c.setFillColorRGB(0.05, 0.05, 0.05)
    c.setLineWidth(width)
    path = c.beginPath()
    path.moveTo(*p[0])
    for v in p[1:]:
        path.lineTo(*v)
    c.drawPath(path)
    direction = p[-1] - p[-2]
    direction /= np.linalg.norm(direction)
    normal = np.array([-direction[1], direction[0]])
    a, b = p[-1] - direction * 9 + normal * 3.8, p[-1] - direction * 9 - normal * 3.8
    head = c.beginPath()
    head.moveTo(*p[-1])
    head.lineTo(*a)
    head.lineTo(*b)
    head.close()
    c.drawPath(head, stroke=0, fill=1)


def callout(c, label, point, target, size=11, dashed=False):
    x, y = point
    c.setStrokeColorRGB(0.15, 0.15, 0.15)
    c.setLineWidth(0.6)
    c.setDash(3, 3) if dashed else c.setDash()
    c.line(x, y - 3, *target)
    c.setDash()
    width = pdfmetrics.stringWidth(label, 'ManualBold', size)
    c.setFillColorRGB(1, 1, 1)
    c.rect(x - 3, y - 3, width + 6, size + 6, stroke=0, fill=1)
    text(c, x, y, label, size, True)


def check(c, x, y, value, width=478):
    c.setLineWidth(0.75)
    c.rect(x, y - 1, 9, 9, stroke=1, fill=0)
    return paragraph(c, x + 19, y, value, width - 19, 11, 16)


def build(records):
    REVIEW.mkdir(parents=True, exist_ok=True)
    pdfmetrics.registerFont(TTFont('Manual', str(FONT / 'DejaVuSans.ttf')))
    pdfmetrics.registerFont(TTFont('ManualBold', str(FONT / 'DejaVuSans-Bold.ttf')))
    output = REVIEW / 'Kamera-boge-R01.pdf'
    c = canvas.Canvas(str(output), pagesize=PAGE)
    c.setTitle('Kamera med boge - Monteringsrettleiing R01')
    c.setAuthor('FormNerd')
    page(c, 1)
    text(c, 42, 757, 'KAMERA', 38, True)
    text(c, 42, 710, 'MED BOGE', 38, True)
    text(c, 44, 672, 'Monteringsrettleiing', 15)
    picture(c, 'cover', (18, 168, 559, 462), records)
    text(c, 44, 124, 'R01  ·  Mekanisk prøvebygg', 13, True)
    paragraph(c, 44, 99, 'Nominell breidd 145 mm. Maskinvare og passform må prøvast før hovudutskrift.', 500, 10, 15)
    c.showPage()

    page(c, 2, 'Prøv passningane først', 1)
    text(c, 44, 713, 'T01  ·  Prøvebit', 13, True)
    p = picture(c, 'coupon', (35, 321, 525, 355), records)
    callout(c, 'Ø16,0 / 16,4 / 16,8', (62, 651), p['button'])
    callout(c, 'AF5,7 / 5,9 / 6,1', (350, 651), p['nuts'])
    callout(c, 'Ø2,0 / 2,5 / 3,4', (355, 350), p['pilots'])
    y = 286
    for value in ['Print T01 før kameradelane. Prøv knappen, mutrane og dei faktiske skruane.', 'Knappen skal gli i Ø16,4 utan å kile. Mutteren skal gå i AF5,9 utan sprekk.', 'Prøv M2,5 i Ø2,0 og M3 i Ø2,5. Juster måla dersom pilotane sprekk eller ikkje held.']:
        y = check(c, 46, y, value) - 12
    paragraph(c, 46, 105, 'P1S og PLA, 0,4 mm dyse: 0,20 mm lag, 3 veggar og 15 % gyroid er eit startgrunnlag. Vel faktisk plate og filament. Delane er ikkje slica eller fysisk prøvde.', 503, 10, 15)
    c.showPage()

    page(c, 3, 'Delar og verktøy')
    positions = [(40, 514, 245, 209), (308, 514, 245, 209), (40, 298, 155, 180), (218, 298, 155, 180), (398, 298, 155, 180)]
    for (p, name), box in zip(NAMES.items(), positions):
        picture(c, f'inventory-{p}', box, records)
        text(c, box[0] + 6, box[1] - 9, f'{p}   1 ×', 11, True)
        text(c, box[0] + 6, box[1] - 27, name, 10)
    for name, x, label in [('rear-screw', 44, '6 × M3 × 12'), ('nut', 223, '4 × M3 mutter'), ('lens-screw', 402, '3 × M2,5 × 8')]:
        picture(c, f'hardware-{name}', (x, 159, 150, 88), records)
        text(c, x + 3, 146, label, 11, True)
    text(c, 46, 115, 'Verktøy: unbrakonøklar som passar dei faktiske skruane.', 10)
    paragraph(c, 46, 88, 'Maskinvara er nominell og ikkje stadfesta på utstyrslista. Fire M3-skruar lukkar huset; to held fjøra. Gjenger er utelatne i bileta.', 502, 9, 14)
    c.showPage()

    page(c, 4, 'Monteringsoversikt')
    p = picture(c, 'exploded', (18, 171, 559, 565), records)
    for label, point in {'P01': (155, 300), 'P02': (460, 220), 'P03': (49, 525), 'P04': (364, 697), 'P05': (475, 605)}.items():
        callout(c, label, point, p[label], 12)
    paragraph(c, 46, 136, 'Knapp og fjør blir monterte frå den opne baksida. Linseinnsatsen blir sett inn framme. Mutrane skal på plass før bakdekselet.', 502, 11, 17)
    c.showPage()

    page(c, 5, 'Før inn knappen', 2)
    text(c, 46, 715, 'P01 + P04', 12, True)
    p = picture(c, 'button', (18, 250, 559, 455), records)
    arrow(c, [p['start'], p['corner'], p['end']])
    callout(c, 'P04', (80, 650), p['button'])
    paragraph(c, 46, 206, 'Hald knappen 46 mm lågare enn sluttstillinga. Skyv han inn frå baksida. Før han så 46 mm rett opp gjennom knappeholet.', 502, 12, 18)
    paragraph(c, 46, 133, 'Den breie foten blir verande inne i huset. Før rørsla roleg gjennom heile den L-forma vegen.', 502, 11, 17)
    c.showPage()

    page(c, 6, 'Fest prøvefjøra', 3)
    text(c, 46, 715, 'P05 + 2 × M3 × 12', 12, True)
    p = picture(c, 'spring', (18, 335, 559, 365), records)
    arrow(c, [p['start'], p['end']])
    d = picture(c, 'spring-detail', (330, 99, 215, 215), records)
    callout(c, '2 × M3', (345, 300), d['s1'])
    callout(c, 'P05', (465, 126), d['tip'])
    paragraph(c, 46, 282, 'Skyv fjøra inn frå baksida. Legg den tynne tunga under knappefoten.', 263, 11, 17)
    paragraph(c, 46, 199, 'Set dei to skruane inn horisontalt frå baksida. Stram varsamt i dei printa pilotane.', 263, 11, 17)
    paragraph(c, 46, 111, 'Prøv knappen medan huset er ope. Han skal gli ned og gå tilbake.', 263, 11, 17)
    c.showPage()

    page(c, 7, 'Fest linseinnsatsen', 4)
    text(c, 46, 715, 'P03 + 3 × M2,5 × 8', 12, True)
    p = picture(c, 'lens', (18, 242, 559, 455), records)
    arrow(c, [p['start'], p['end']])
    callout(c, 'P03', (440, 650), p['ring'])
    paragraph(c, 46, 199, 'Før hylsa rett inn i linseholet. Drei innsatsen til dei tre skruehola står over pilotane.', 502, 12, 18)
    paragraph(c, 46, 126, 'Set inn tre M2,5-skruar frå framsida og stram jamt. Ø32 mm fri opning er eit mekanisk grensesnitt, ikkje ei ferdig optisk løysing.', 502, 11, 17)
    c.showPage()

    page(c, 8, 'Legg inn mutrane', 5)
    text(c, 46, 715, '4 × M3 mutter', 12, True)
    p = picture(c, 'nuts', (18, 232, 559, 465), records)
    for i, label_point in enumerate([(73, 361), (457, 361), (74, 636), (458, 636)], 1):
        callout(c, str(i), label_point, p[f'n{i}'], 12)
    paragraph(c, 46, 195, 'Press éin mutter inn i kvar sekskantlomme frå baksida. Kontroller at alle fire ligg heilt inne før dekselet blir sett på.', 502, 12, 18)
    paragraph(c, 46, 121, 'Bruk prøvebiten dersom mutrane er for tronge. Ikkje tving dei inn i huset.', 502, 11, 17)
    c.showPage()

    page(c, 9, 'Lukk bakdekselet', 6)
    text(c, 46, 715, 'P02 + 4 × M3 × 12', 12, True)
    p = picture(c, 'back', (18, 241, 559, 455), records)
    arrow(c, [p['start'], p['end']])
    callout(c, 'Styrepinnar på innsida', (64, 294), p['pin1'], dashed=True)
    paragraph(c, 46, 203, 'Rett inn dei to styrepinnane. Før bakdekselet rett fram mot huset. Set inn fire skruar frå baksida.', 502, 12, 18)
    paragraph(c, 46, 128, 'Stram litt om gongen, diagonalt. Fuga skal vere jamn. Opne ved å løyse dei fire skruane og trekkje dekselet rett bakover.', 502, 11, 17)
    c.showPage()

    page(c, 10, 'Prøv det ferdige huset')
    p = picture(c, 'finished', (18, 344, 559, 375), records)
    arrow(c, [p['press-start'], p['press-end']])
    text(c, p['press-start'][0] + 12, p['press-start'][1] - 10, '1,2 mm', 11, True)
    y = 318
    for value in ['Knappen rører seg fritt og går tilbake utan å kile.', 'Fjør, linseinnsats og bakdeksel sit fast utan sprekk.', 'Bakdekselet kan opnast og monterast på nytt.']:
        y = check(c, 46, y, value) - 13
    paragraph(c, 46, 171, 'Dette er ein digitalt konstruert mekanisk prototype. Fjørdeformasjon er ikkje fysisk prøvd. Maskinvare, veggtjukkleik og støtter må kontrollerast mot kontrollrapporten før utskrift.', 502, 10, 15)
    paragraph(c, 46, 104, 'P1S-slicing og fysisk prøvepass står att. USB-opninga er førebels. Modell og rettleiing dokumenterer ikkje fungerande elektronikk eller lading.', 502, 10, 15)
    c.save()
    (REVIEW / 'manual-manifest.json').write_text(json.dumps({'revision': 'R01', 'pdf': output.name, 'page_count': 10, 'figures': list(records), 'source': 'actual CAD meshes and deterministic projection', 'status': 'mechanical prototype; unsliced; physically untested'}, ensure_ascii=False, indent=2))
    print(output, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--force', action='store_true')
    parser.add_argument('--layout-only', action='store_true')
    args = parser.parse_args()
    records = {name: json.loads((FIGURES / f'{name}.render.json').read_text()) for name in scenes()} if args.layout_only else make_figures(args.force)
    build(records)
