KAMERA MED BOGE - DOKUMENT M06 / CAD R01

M06 er ny layout i stilen til monteringsreferansane (referansar/ikea-monteringsstil i formnerd-repoet):
sideramme, nummer i sirkel med mengd (1 x1), beslagkolonne med bokstav og mengd, hole piler mellom tilstandar,
forstørringsbobler, stipla innføringsliner med "Ax2", store multiplikatorar og nesten ordlause stegsider.
R01-geometrien er uendra. 14 sider.

Bygg PDF-en frå dei vedlagde vektorfigurane (krev berre reportlab og numpy):
    python source/manual_v6.py
Resultat: review/manual-v3/Kamera-boge-M06.pdf

Strek: figurane blir teikna direkte frå SVG-banene med strekvekt per linjetype i pt (WEIGHTS i manual_v6.py):
kontur 1,45, detalj 0,62, organisk kontur 0,72, organisk dal 0,5, beslag 1,0/0,45, snittskravur 0,28.
Målt med verktoy/ikea/maal.py: effektiv strekvekt 0,76-1,11 pt (stegsider snitt 0,99), mot 0,83-1,2 pt i referansen.

Nye figurar i M06 (byggjast med source/manual_v6_scenes.py og source/organic_figure.py, krev R01-pakken, vtk og Chrome/Playwright):
    coupon-test-a, coupon-test-b  T01 med P04, mutter og skruar over dei gradvise hola (16,0/16,4/16,8, AF 5,7/5,9/6,1, 2,0/2,5/3,4)
    tool-hex-key                  unbrakonøkkel (nominell AF2,5-modell, brukt som piktogram for 2,5 og 2)
    button-context                P01 bakfrå med P04 i startposisjon og L-ruta inn og opp
    button-test                   P01 med P04, P05 og fjørskruar montert, for funksjonsprøva
hardware-lens-screw er rendra på nytt frå motsett side slik at hovudet vender mot lesaren, som på A.

Skrift: Liberation Sans (SIL OFL 1.1, sjå assets/fonts/LICENSE-LiberationSans.txt).
M03-M05 er eldre revisjonar av same rettleiing; manual_v3.py/v4/v5 ligg ved som historikk.
