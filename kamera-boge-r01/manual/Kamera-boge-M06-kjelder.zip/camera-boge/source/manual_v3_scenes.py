import copy
import json
from pathlib import Path

import numpy as np

import manual as original

ROOT = Path(__file__).resolve().parents[1]
SCENES = ROOT / 'source' / 'scenes-v3'
FIGURES = ROOT / 'review' / 'manual-v3' / 'figures'
NAMES = original.NAMES
part = original.part
hardware = original.hardware


def base(parts, direction, width=499, anchors=None, size=(1600, 1400), target=None, scale=None):
    value = original.scene(parts, direction, anchors, size=size, target=target, scale=scale)
    value.update({'figure_width_pt': width, 'outer_width_pt': .8, 'detail_width_pt': .4, 'simplify_tolerance_pt': .08})
    value.pop('mode', None)
    value.pop('supersample', None)
    return value


def fixed_pair(values, width=425, height=245):
    from vector_illustration import mesh
    from vtk.util.numpy_support import vtk_to_numpy
    camera = values[0]['camera']
    forward = np.array(camera['direction'], float)
    forward /= np.linalg.norm(forward)
    right = np.cross(camera['up'], forward)
    right /= np.linalg.norm(right)
    up = np.cross(forward, right)
    basis = np.stack((right, up, forward))
    target = np.array(camera.get('target', [0, 0, 0]), float)
    points = np.concatenate([vtk_to_numpy(mesh(p)[0].GetPoints().GetData()) for s in values for p in s['parts']])
    projected = (points - target) @ basis.T
    lo, hi = projected[:, :2].min(0) - 3, projected[:, :2].max(0) + 3
    center, span = (lo + hi) / 2, hi - lo
    target += right * center[0] + up * center[1]
    dimensions = np.ceil(span * 12).astype(int)
    for value in values:
        value['size'] = dimensions.tolist()
        value['figure_width_pt'] = float(min(width, height * dimensions[0] / dimensions[1]))
        value['camera'].update({'target': target.tolist(), 'scale': float(span[1])})
    return values


def lid_hole_mouths():
    from vector_illustration import mesh
    from vtk.util.numpy_support import vtk_to_numpy
    points = vtk_to_numpy(mesh(part('P02'))[0].GetPoints().GetData())
    mouths = []
    for x in (-20, 20):
        radius = np.sqrt((points[:, 0] - x) ** 2 + (points[:, 2] - 12) ** 2)
        rim = points[(np.abs(radius - 1.7) < .002) & (points[:, 1] < -33)]
        mouths.append([x, float(rim[:, 1].mean()) - 35, 12])
    return mouths


def scenes():
    product = [part(p) for p in NAMES]
    fasteners = hardware('rear-screw', 4) + hardware('nut', 4) + hardware('spring-screw', 2) + hardware('lens-screw', 3)
    out = {'cover': base(product + fasteners, original.FRONT, size=(1800, 1500))}
    for p in NAMES:
        out[f'inventory-{p}'] = base([part(p)], original.REAR if p in ('P02', 'P05') else original.FRONT, width=237 if p in ('P01', 'P02') else 149, size=(1000, 800))
    for name in ('inventory-P01', 'inventory-P02'):
        out[name]['projection_sampling'] = 2
    for kind in ('rear-screw', 'nut', 'lens-screw'):
        out[f'hardware-{kind}'] = base(hardware(kind, 1), [1, -2, 1], width=135, size=(700, 400))
    out['coupon'] = base([{'file': 'print/T01.stl'}], [.4, -.7, 1.3], width=499, anchors={'button': [35, 17.5, 4], 'nuts': [30, 30, 4], 'pilots': [23, 5, 4]})
    out['exploded'] = base([part('P01'), part('P02', [0, -55, 0]), part('P03', [0, 35, 0]), part('P04', [0, -55, -46]), part('P05', [0, -27, 0])] + hardware('rear-screw', 4, [0, -65, 0]) + hardware('nut', 4, [0, -18, 0]) + hardware('spring-screw', 2, [0, -45, 0]) + hardware('lens-screw', 3, [0, 48, 0]), [-1, -1, .7], width=511, size=(1800, 1600), anchors={'P01': [0, 15, 50], 'P02': [0, -94, 44], 'P03': [-38, 67.5, 64.5], 'P04': [48, -45, 42.5], 'P05': [46, -48, 73], 'route-start': [48, -45, 42.5], 'route-corner': [48, 10, 42.5], 'route-end': [48, 10, 88.5]})
    for name, offset in [('spring-insert-before', -30), ('spring-insert-after', 0)]:
        out[name] = base([part('P04'), part('P05', [0, offset, 0])], [1, -1, .4], anchors={'start': [46, -19 + offset, 72], 'end': [46, -19, 72]})
    fixed_pair([out['spring-insert-before'], out['spring-insert-after']])
    installed = [part(p) for p in ('P01', 'P04', 'P05')] + hardware('spring-screw', 2)
    out['lens-insert'] = base(installed + [part('P03', [0, 29, 0])], original.FRONT, anchors={'lens': [-38, 69, 64], 'start': [-38, 69, 41.5], 'end': [-38, 40, 41.5]})
    for name, offset in [('lens-fasten-before', 29), ('lens-fasten-after', 0)]:
        out[name] = base([part('P03')] + hardware('lens-screw', 3, [0, offset, 0]), original.FRONT, anchors={f's{i}': [x, 43 + offset, z] for i, (x, z) in enumerate([(-38 + 22 * np.cos(np.radians(a)), 41.5 + 22 * np.sin(np.radians(a))) for a in (90, 210, 330)], 1)})
    fixed_pair([out['lens-fasten-before'], out['lens-fasten-after']])
    installed += [part('P03')] + hardware('lens-screw', 3)
    out['nuts-insert'] = base(installed + hardware('nut', 4, [0, -14, 0]), [.7, -1, .4], anchors={f'n{i}': [x, -41.2, z] for i, (x, z) in enumerate([(-48, 18), (48, 18), (-48, 62), (48, 62)], 1)})
    for i, (x, z) in enumerate([(-48, 18), (48, 18), (-48, 62), (48, 62)], 1):
        out['nuts-insert']['anchors'][f'n{i}-seat'] = [x, -27.2, z]
    installed += hardware('nut', 4)
    out['lid-insert'] = base(installed + [part('P02', [0, -35, 0])], [.7, -1, .4], anchors={'start': [0, -72, 42], 'end': [0, -37, 42], 'pin1': [-20, -34.6, 12], 'pin2': [20, -34.6, 12], 'hole1': [-20, -67, 12], 'hole2': [20, -67, 12]})
    for index, mouth in enumerate(lid_hole_mouths(), 1):
        out['lid-insert']['anchors'][f'hole{index}'] = mouth
    out['lid-fasten'] = base(installed + [part('P02')] + hardware('rear-screw', 4, [0, -30, 0]), [.7, -1, .4], anchors={f's{i}': [x, -70.7, z] for i, (x, z) in enumerate([(-48, 18), (48, 18), (-48, 62), (48, 62)], 1)})
    out['finished-rear'] = base(installed + [part('P02')] + hardware('rear-screw', 4), [.7, -1, .4], width=220)
    lookup = json.loads((ROOT / 'source' / 'm03-contour-policy.json').read_text())
    for name, value in out.items():
        if name in ('lens-insert', 'nuts-insert', 'lid-insert', 'lid-fasten', 'finished-rear'):
            value['projection_sampling'] = 2
        value['tangent_boundary_clearance_px'] = 2
        for item in value['parts']:
            source = lookup.get(Path(item['file']).stem, {})
            for key in ('edge_omissions', 'tangent_regions', 'tangent_boundary_clearance_px'):
                if key in source:
                    item[key] = copy.deepcopy(source[key])
    return out


def write_scenes(selected=None):
    SCENES.mkdir(parents=True, exist_ok=True)
    out = scenes()
    for name, value in out.items():
        if selected and name not in selected:
            continue
        (SCENES / f'{name}.json').write_text(json.dumps(value, ensure_ascii=False, indent=2))
    return out


def render_selected(selected=None, force=False):
    from vector_illustration import illustrate
    FIGURES.mkdir(parents=True, exist_ok=True)
    values = write_scenes(selected)
    for name in selected or values:
        value = values[name]
        output = FIGURES / name
        if not force and output.with_suffix('.svg').exists() and output.with_suffix('.render.json').exists():
            continue
        print(name, flush=True)
        illustrate(value, output)


if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--write-only', action='store_true')
    parser.add_argument('--only', nargs='*')
    parser.add_argument('--force', action='store_true')
    args = parser.parse_args()
    if args.write_only:
        write_scenes()
    else:
        render_selected(args.only, args.force)
