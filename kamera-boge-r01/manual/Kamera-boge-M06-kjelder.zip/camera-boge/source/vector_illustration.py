import argparse
import hashlib
import json
from pathlib import Path
from xml.sax.saxutils import escape

import numpy as np
from PIL import Image, ImageDraw
import vtk
from vtk.util.numpy_support import numpy_to_vtk, vtk_to_numpy

ROOT = Path(__file__).resolve().parents[1]


def mesh(part):
    path = Path(part['file'])
    path = path if path.is_absolute() else ROOT / path
    source = vtk.vtkSTLReader()
    source.SetFileName(str(path))
    source.Update()
    matrix = np.asarray(part.get('matrix', np.eye(4)), float).reshape(4, 4).copy()
    matrix[:3, 3] += np.asarray(part.get('translate', [0, 0, 0]))
    transform = vtk.vtkTransform()
    transform.SetMatrix(matrix.ravel())
    moved = vtk.vtkTransformPolyDataFilter()
    moved.SetInputConnection(source.GetOutputPort())
    moved.SetTransform(transform)
    clean = vtk.vtkCleanPolyData()
    clean.SetInputConnection(moved.GetOutputPort())
    clean.SetToleranceIsAbsolute(True)
    clean.SetAbsoluteTolerance(1e-7)
    clean.Update()
    result = vtk.vtkPolyData()
    result.DeepCopy(clean.GetOutput())
    return result, path


def paths(poly, direction, organic):
    silhouette = vtk.vtkPolyDataSilhouette()
    silhouette.SetInputData(poly)
    silhouette.SetDirectionToSpecifiedVector()
    silhouette.SetVector(direction)
    silhouette.SetEnableFeatureAngle(False)
    silhouette.BorderEdgesOn()
    sharp = vtk.vtkFeatureEdges()
    sharp.SetInputData(poly)
    sharp.SetFeatureAngle(70 if organic else 35)
    sharp.BoundaryEdgesOn()
    sharp.FeatureEdgesOn()
    sharp.ManifoldEdgesOff()
    sharp.NonManifoldEdgesOff()
    result = []
    for kind, source in (('contour', silhouette), ('detail', sharp)):
        stripper = vtk.vtkStripper()
        stripper.SetInputConnection(source.GetOutputPort())
        stripper.SetMaximumLength(1000000)
        stripper.JoinContiguousSegmentsOn()
        stripper.Update()
        output = stripper.GetOutput()
        if not output.GetNumberOfPoints():
            continue
        points = vtk_to_numpy(output.GetPoints().GetData())
        cells = output.GetLines()
        indices = vtk.vtkIdList()
        cells.InitTraversal()
        while cells.GetNextCell(indices):
            result.append((kind, points[[indices.GetId(i) for i in range(indices.GetNumberOfIds())]].astype(float)))
    return result


def densify(points, projected, step):
    lengths = np.linalg.norm(np.diff(projected[:, :2], axis=0), axis=1)
    counts = np.maximum(1, np.ceil(lengths / step).astype(int))
    k = np.repeat(np.arange(len(counts)), counts)
    local = np.arange(counts.sum()) - np.repeat(np.cumsum(counts) - counts, counts)
    t = local / counts[k]
    return np.vstack((points[k] + np.diff(points, axis=0)[k] * t[:, None], points[-1]))


def simplify(points, tolerance):
    keep = {0, len(points) - 1}
    stack = [(0, len(points) - 1)]
    while stack:
        a, b = stack.pop()
        if b <= a + 1:
            continue
        delta = points[b] - points[a]
        factor = np.clip((points[a + 1:b] - points[a]) @ delta / max(np.dot(delta, delta), 1e-20), 0, 1)
        distance = np.linalg.norm(points[a + 1:b] - points[a] - factor[:, None] * delta, axis=1)
        i = int(np.argmax(distance))
        if distance[i] > tolerance:
            pivot = a + i + 1
            keep.add(pivot)
            stack.extend(((a, pivot), (pivot, b)))
    return points[sorted(keep)]


def deviation(source, simplified):
    maximum = 0.0
    for first in range(0, len(source), 500):
        points = source[first:first + 500]
        start, delta = simplified[:-1], np.diff(simplified, axis=0)
        difference = points[:, None] - start
        factor = np.clip(np.sum(difference * delta, axis=2) / np.maximum(np.sum(delta * delta, axis=1), 1e-20), 0, 1)
        distance = np.linalg.norm(difference - factor[:, :, None] * delta, axis=2)
        maximum = max(maximum, float(distance.min(axis=1).max()))
    return maximum


def organic_projection(loaded, project, basis, size, sampling):
    from render import rasterize
    width, height = size
    depth = np.full((height * sampling, width * sampling), -np.inf, np.float32)
    normals = np.lib.stride_tricks.as_strided(np.zeros(3, np.float32), shape=(*depth.shape, 3), strides=(0, 0, 4), writeable=True)
    ids = np.zeros(depth.shape, np.uint16)
    for index, (poly, path) in enumerate(loaded, 1):
        print('project', path.stem, poly.GetNumberOfCells(), flush=True)
        vertices = vtk_to_numpy(poly.GetPoints().GetData())
        faces = vtk_to_numpy(poly.GetPolys().GetData()).reshape(-1, 4)[:, 1:]
        screen = np.column_stack((project(vertices) * sampling, vertices @ basis[2]))
        rasterize(screen, faces, np.zeros_like(vertices), index, depth, normals, ids, True)
    result = {}
    for index, (_, path) in enumerate(loaded, 1):
        if path.stem not in ('P01', 'P02'):
            continue
        print('trace-boundary', path.stem, flush=True)
        image = vtk.vtkImageData()
        image.SetDimensions(width * sampling, height * sampling, 1)
        image.GetPointData().SetScalars(numpy_to_vtk((ids == index).ravel().astype(np.uint8), deep=True))
        contours = vtk.vtkContourFilter()
        contours.SetInputData(image)
        contours.SetValue(0, .5)
        stripper = vtk.vtkStripper()
        stripper.SetInputConnection(contours.GetOutputPort())
        stripper.SetMaximumLength(1000000)
        stripper.JoinContiguousSegmentsOn()
        stripper.Update()
        data = stripper.GetOutput()
        points = vtk_to_numpy(data.GetPoints().GetData())[:, :2] / sampling
        lines = data.GetLines()
        indices = vtk.vtkIdList()
        lines.InitTraversal()
        paths = []
        while lines.GetNextCell(indices):
            paths.append(points[[indices.GetId(i) for i in range(indices.GetNumberOfIds())]])
        result[path.stem] = paths
    return result


def illustrate(scene, output):
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    width, height = scene.get('size', [1800, 1500])
    loaded = [mesh(part) for part in scene['parts']]
    vertices = [vtk_to_numpy(poly.GetPoints().GetData()) for poly, _ in loaded]
    low, high = np.min([v.min(0) for v in vertices], axis=0), np.max([v.max(0) for v in vertices], axis=0)
    camera = scene.get('camera', {})
    target = np.asarray(camera.get('target', (low + high) / 2), float)
    direction = np.asarray(camera.get('direction', [1, -1, .65]), float)
    direction /= np.linalg.norm(direction)
    up = np.asarray(camera.get('up', [0, 0, 1]), float)
    right = np.cross(up, direction)
    right /= np.linalg.norm(right)
    up = np.cross(direction, right)
    basis = np.stack((right, up, direction))
    projected = np.concatenate([(v - target) @ basis.T for v in vertices])
    scale = float(camera.get('scale', max(np.abs(projected[:, 1]).max() * 2, np.abs(projected[:, 0]).max() * 2 * height / width) * camera.get('padding', 1.14)))
    ppu = height / scale
    def project(points):
        p = (np.asarray(points) - target) @ basis.T
        return np.column_stack((width / 2 + p[:, 0] * ppu, height / 2 - p[:, 1] * ppu))
    assembly = vtk.vtkAppendPolyData()
    for poly, _ in loaded:
        assembly.AddInputData(poly)
    assembly.Update()
    locator = vtk.vtkStaticCellLocator()
    locator.SetDataSet(assembly.GetOutput())
    locator.BuildLocator()
    extent = np.linalg.norm(high - low) * 3
    visibility_tolerance = float(scene.get('visibility_tolerance_mm', .02))
    t, subid, cellid = vtk.mutable(0.), vtk.mutable(0), vtk.mutable(0)
    hit, coordinates, cell = [0., 0., 0.], [0., 0., 0.], vtk.vtkGenericCell()
    ray_count = 0
    def first_hit(point):
        nonlocal ray_count
        ray_count += 1
        result = locator.IntersectWithLine(point + direction * extent, point - direction * extent, 1e-7, t, hit, coordinates, subid, cellid, cell)
        return np.asarray(hit).copy() if result else None
    def visible(point):
        result = first_hit(point)
        return result is None or np.dot(result - point, direction) <= visibility_tolerance
    figure_width = float(scene.get('figure_width_pt', 403.2))
    tolerance = float(scene.get('simplify_tolerance_pt', .12)) * width / figure_width
    drawing, reports = [], []
    model_reference = []
    projection_sampling = int(scene.get('projection_sampling', 3))
    file_digests = [hashlib.sha256(path.read_bytes()).hexdigest() for _, path in loaded]
    geometry_key = hashlib.sha256(json.dumps({'parts': [{'sha256': digest, 'matrix': part.get('matrix'), 'translate': part.get('translate')} for digest, part in zip(file_digests, scene['parts'])], 'size': [width, height], 'target': target.tolist(), 'direction': direction.tolist(), 'up': up.tolist(), 'scale': scale, 'sampling': projection_sampling}, sort_keys=True).encode()).hexdigest()
    projected_boundaries = {}
    projection_cache = output.with_suffix('.projection.npz')
    if any(path.stem in ('P01', 'P02') for _, path in loaded):
        print('projection-begin', width, height, projection_sampling, flush=True)
        if projection_cache.exists():
            cache = np.load(projection_cache)
            if str(cache['key']) == geometry_key:
                for name, a, b in zip(cache['names'], cache['offsets'][:-1], cache['offsets'][1:]):
                    projected_boundaries.setdefault(str(name), []).append(cache['points'][a:b])
        if not projected_boundaries:
            projected_boundaries = organic_projection(loaded, project, basis, [width, height], projection_sampling)
            entries = [(name, points) for name, curves in projected_boundaries.items() for points in curves]
            if entries:
                offsets = np.r_[0, np.cumsum([len(points) for _, points in entries])]
                np.savez_compressed(projection_cache, key=geometry_key, names=np.array([name for name, _ in entries]), offsets=offsets, points=np.vstack([points for _, points in entries]))
        print('projection-ready', flush=True)
    for index, ((poly, path), part) in enumerate(zip(loaded, scene['parts'])):
        organic = path.stem in ('P01', 'P02')
        candidates = paths(poly, direction, organic)
        model_reference.extend(densify(project(source), project(source), .1) for _, source in candidates)
        kept = 0
        omitted_surface_samples = 0
        boundary_tree = None
        if organic:
            if part.get('tangent_regions'):
                from scipy.spatial import cKDTree
                boundary_samples = [densify(curve, curve, .25) for curve in projected_boundaries[path.stem] if len(curve) > 1]
                boundary_tree = cKDTree(np.vstack(boundary_samples)) if boundary_samples else None
            for reference in projected_boundaries[path.stem]:
                if len(reference) < 3 or np.linalg.norm(np.diff(reference, axis=0), axis=1).sum() < 2:
                    continue
                simple = simplify(reference, min(tolerance, .06 * width / figure_width))
                drawing.append({'part': path.stem, 'kind': 'contour', 'points': simple, 'error_px': deviation(reference, simple), 'reference_vertices': len(reference)})
                kept += 1
        for kind, source in candidates:
            tangency = organic and kind == 'contour'
            regions = part.get('tangent_regions', []) if tangency else []
            if tangency and not regions:
                omitted_surface_samples += len(source)
                continue
            points = densify(source, project(source), .45)
            selected = np.ones(len(points), bool)
            minimum_lengths = np.full(len(points), np.inf)
            if tangency:
                selected[:] = False
                for region in regions:
                    bounds = np.asarray(region['bounds'], float)
                    inside = np.all((points >= bounds[0]) & (points <= bounds[1]), axis=1)
                    selected |= inside
                    minimum_lengths[inside] = np.minimum(minimum_lengths[inside], float(region.get('minimum_projected_length_mm', 3)))
                if boundary_tree is not None:
                    selected &= boundary_tree.query(project(points))[0] > float(scene.get('tangent_boundary_clearance_px', 2))
                omitted_surface_samples += int(np.count_nonzero(~selected))
            visibility = np.array([visible(point) if use else False for point, use in zip(points, selected)], bool)
            if kind == 'detail':
                for omission in part.get('edge_omissions', []):
                    bounds = np.asarray(omission['bounds'], float)
                    selected = np.all((points >= bounds[0]) & (points <= bounds[1]), axis=1)
                    omitted_surface_samples += int(np.count_nonzero(visibility & selected))
                    visibility &= ~selected
            boundaries = np.flatnonzero(np.diff(np.r_[False, visibility, False])).reshape(-1, 2)
            for first, end in boundaries:
                fragment = points[first:end].copy()
                if first:
                    a, b = points[first - 1].copy(), points[first].copy()
                    for _ in range(8):
                        mid = (a + b) / 2
                        if visible(mid):
                            b = mid
                        else:
                            a = mid
                    fragment = np.vstack((b, fragment))
                if end < len(points):
                    a, b = points[end - 1].copy(), points[end].copy()
                    for _ in range(8):
                        mid = (a + b) / 2
                        if visible(mid):
                            a = mid
                        else:
                            b = mid
                    fragment = np.vstack((fragment, a))
                reference = project(fragment)
                minimum = float(scene.get('minimum_organic_curve_pt', 1.2)) * width / figure_width if organic else .2
                if tangency:
                    minimum = float(minimum_lengths[first:end].min()) * ppu
                if len(reference) < 2 or np.linalg.norm(np.diff(reference, axis=0), axis=1).sum() < minimum:
                    continue
                simple = simplify(reference, tolerance)
                error = deviation(reference, simple)
                drawing.append({'part': path.stem, 'kind': 'detail' if tangency else kind, 'points': simple, 'error_px': error, 'reference_vertices': len(reference)})
                kept += 1
        reports.append({'part': path.stem, 'candidates': len(candidates), 'visible_paths': kept, 'omitted_organic_surface_samples': omitted_surface_samples, 'explicit_edge_omissions': part.get('edge_omissions', []), 'explicit_tangent_regions': part.get('tangent_regions', []), 'source_reference': part.get('source_reference'), 'triangles': poly.GetNumberOfCells(), 'sha256': file_digests[index]})
        print(path.stem, len(candidates), kept, 'rays', ray_count, flush=True)
    outer = float(scene.get('outer_width_pt', .8)) * width / figure_width
    detail = float(scene.get('detail_width_pt', .45)) * width / figure_width
    svg = [f'<svg xmlns="http://www.w3.org/2000/svg" width="{figure_width}pt" height="{height * figure_width / width}pt" viewBox="0 0 {width} {height}">', '<rect width="100%" height="100%" fill="white"/>', '<g fill="none" stroke="#111" stroke-linejoin="round" stroke-linecap="round">']
    preview_scale = 4
    image = Image.new('RGB', (width * preview_scale, height * preview_scale), 'white')
    draw = ImageDraw.Draw(image)
    for item in sorted(drawing, key=lambda item: item['kind'] == 'contour'):
        p = item['points']
        weight = outer if item['kind'] == 'contour' else detail
        data = 'M ' + ' L '.join(f'{x:.4f},{y:.4f}' for x, y in p)
        svg.append(f'<path data-part="{escape(item["part"])}" data-kind="{item["kind"]}" stroke-width="{weight:.4f}" d="{data}"/>')
        xy = [tuple(point * preview_scale) for point in p]
        stroke = max(1, round(weight * preview_scale))
        draw.line(xy, fill='#111', width=stroke, joint='curve')
        radius = stroke / 2
        for x, y in (xy[0], xy[-1]):
            draw.ellipse((x - radius, y - radius, x + radius, y + radius), fill='#111')
    svg.extend(('</g>', '</svg>'))
    output.with_suffix('.svg').write_text('\n'.join(svg))
    image.resize((width, height), Image.Resampling.LANCZOS).save(output.with_suffix('.png'))
    max_error = max((item['error_px'] for item in drawing), default=0)
    anchors = {name: project([point])[0].round(4).tolist() for name, point in scene.get('anchors', {}).items()}
    result = {'image': str(output.with_suffix('.png')), 'svg': str(output.with_suffix('.svg')), 'size': [width, height], 'camera': {'target': target.tolist(), 'direction': direction.tolist(), 'up': up.tolist(), 'scale': scale}, 'anchors': anchors, 'parts': reports, 'paths': len(drawing), 'ray_count': ray_count, 'visibility_tolerance_mm': visibility_tolerance, 'simplification_tolerance_pt': scene.get('simplify_tolerance_pt', .12), 'max_source_to_vector_error_px': max_error, 'max_source_to_vector_error_pt': max_error * figure_width / width, 'max_source_to_vector_error_projected_mm': max_error / ppu, 'normal_ridges': False, 'geometry_modified': False, 'vector_vertices': sum(len(item['points']) for item in drawing), 'organic_policy': {'keep': 'external boundaries, openings, part boundaries, depth discontinuities, sharp mechanical edges', 'omit': 'normal ridges, shallow same-part tangencies, organic fragments shorter than minimum length', 'boundary_probe_mm': scene.get('boundary_probe_mm', .15), 'depth_step_mm': scene.get('organic_depth_step_mm', 3), 'minimum_curve_pt': scene.get('minimum_organic_curve_pt', 1.2)}}
    result['organic_policy'] = {'keep': 'visible projected part boundaries and sharp edges', 'omit': 'same-part internal tangencies, normal ridges, organic fragments shorter than minimum length', 'projection_sampling': projection_sampling, 'projection_grid_deviation_bound_px': float(np.sqrt(2) / (2 * projection_sampling)), 'projection_trace_tolerance_pt': .06, 'minimum_curve_pt': scene.get('minimum_organic_curve_pt', 1.2)}
    result['trace_reference'] = 'Exact projected model edges for mechanical parts; sampled orthographic CAD projection boundary for organic parts'
    result['illustration_notes'] = scene.get('illustration_notes', [])
    result['geometry_key'] = geometry_key
    if model_reference and drawing:
        from scipy.spatial import cKDTree
        reference_tree = cKDTree(np.vstack(model_reference))
        distances = {}
        for item in drawing:
            p = item['points']
            distance = float(reference_tree.query(densify(p, p, .1))[0].max())
            distances[item['part']] = max(distances.get(item['part'], 0), distance)
        maximum = max(distances.values())
        result['measurement'] = {'metric': 'one-way SVG to nearest exact projected model contour; internal organic contours are intentionally omitted', 'svg_sample_spacing_px': .1, 'model_sample_spacing_px': .1, 'max_sample_distance_px': maximum, 'continuous_svg_to_model_distance_upper_bound_px': maximum + .05, 'continuous_svg_to_model_distance_upper_bound_pt': (maximum + .05) * figure_width / width, 'continuous_svg_to_model_distance_upper_bound_projected_mm': (maximum + .05) / ppu, 'per_part_max_sample_distance_px': distances, 'geometry_reconstructed': False}
    output.with_suffix('.render.json').write_text(json.dumps(result, indent=2))
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('scene')
    parser.add_argument('output')
    args = parser.parse_args()
    print(json.dumps(illustrate(json.loads(Path(args.scene).read_text()), args.output)))
