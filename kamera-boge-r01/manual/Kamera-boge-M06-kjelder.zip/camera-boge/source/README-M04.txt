KAMERA MED BOGE - DOKUMENT M04 / CAD R01

M04 = M03 pluss ei ny side 3 «Prent for P1S» med dei tre slica platene, og feilsøking på side 16.
R01-geometrien er uendra. Sidetalet er 16.

Bygg layouten frå dei vedlagde vektorfigurane (krev reportlab, svglib, pypdf, numpy):
    python source/manual_v4.py --layout-only
Resultat: review/manual-v3/Kamera-boge-M04.pdf

Platefigurane (figures/plate-00, plate-01, plate-02) er bygde slik:
    python source/bambu3mf.py print/bambu/<plate>.gcode.3mf   (gir faktisk plassering)
    -> plates/<nn>/<del>.stl (P01 som 400 000-trekantars visingsavleiing), plates/plate.stl (256 x 256 mm)
    python source/vector_illustration.py source/scenes-v3/plate-<nn>.json review/manual-v3/figures/plate-<nn>
Tida og vekta på side 3 ligg i source/print-m04.json og kjem frå print/bambu/*.json i R01-pakken.
