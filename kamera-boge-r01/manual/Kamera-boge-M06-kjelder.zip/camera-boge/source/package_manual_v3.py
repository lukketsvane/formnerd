import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT.parent / 'Kamera-boge-M03-kjelder.zip'


def selected_files():
    source_names = ['manual.py', 'manual_v2.py', 'manual_v3.py', 'manual_v3_scenes.py', 'manual_v3_details.py', 'render.py', 'line_art.py', 'vector_illustration.py', 'requirements.txt', 'm03-contour-policy.json', 'manual-v3-plan.json', 'package_manual_v3.py']
    files = [ROOT / 'README.txt'] + [ROOT / 'source' / name for name in source_names]
    files += list((ROOT / 'source' / 'assets' / 'fonts').glob('*'))
    files += list((ROOT / 'source' / 'scenes-v3').glob('*.json'))
    for folder in ['figures', 'details', 'proofs', 'fixtures', 'style-drafts']:
        files += [p for p in (ROOT / 'review' / 'manual-v3' / folder).rglob('*') if p.is_file() and not (folder == 'figures' and p.suffix == '.png')]
    files += [p for p in (ROOT / 'review' / 'manual-v3' / 'qa-drafts').glob('*.png') if p.is_file()]
    files += [p for p in (ROOT / 'review' / 'manual-v3').glob('*.json')]
    files += [ROOT / 'review' / 'manual-v3' / name for name in ['Kamera-boge-M03-proof-fjor.pdf', 'Kamera-boge-M03-proof-fjor.png', 'README-rebuild.txt']]
    files += [ROOT / 'verification' / name for name in ['manual-m03-cad-integrity.json', 'manual-m03.json', 'manual-v3-readtest.json', 'manual-v3-readtest-before-final-locator-cleanup.json']]
    return sorted(set(p for p in files if p.is_file()))


def main():
    files = selected_files()
    records = [{'path': str(p.relative_to(ROOT)), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest(), 'bytes': p.stat().st_size} for p in files]
    manifest = {'document_revision': 'M03', 'geometry_revision': 'R01', 'purpose': 'portable cached-vector PDF rebuild; original full R01 CAD package remains separate', 'files': records}
    with zipfile.ZipFile(OUT, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as package:
        for p in files:
            package.write(p, 'camera-boge/' + str(p.relative_to(ROOT)))
        package.writestr('camera-boge/package-manifest.json', json.dumps(manifest, ensure_ascii=False, indent=2))
    if OUT.stat().st_size >= 10 * 1024 * 1024:
        raise ValueError(f'Package too large: {OUT.stat().st_size}')
    print(json.dumps({'zip': str(OUT), 'bytes': OUT.stat().st_size, 'files': len(files), 'sha256': hashlib.sha256(OUT.read_bytes()).hexdigest()}), flush=True)


if __name__ == '__main__':
    main()
